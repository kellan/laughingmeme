---
id: 1938
title: Mail-Thread-Arc-0.10
date: '2003-12-11T15:55:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1938'
permalink: /2003/12/11/mail-thread-arc-010/
typo_id:
    - '1936'
mt_id:
    - '1536'
link_related:
    - 'http://search.cpan.org/~rclamp/Mail-Thread-Arc-0.10/'
raw_content:
    - 'A \''thread arc\'' is a visual tool for understanding conversations, as described by remail'
categories:
    - Aside
---

A ‘thread arc’ is a visual tool for understanding conversations, as described by remail