---
id: 3741
title: 'apophenia: algorithms for dumb security questions'
date: '2007-12-19T10:20:13+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/12/19/apophenia-algorithms-for-dumb-security-questions/'
permalink: /2007/12/19/apophenia-algorithms-for-dumb-security-questions/
link_related:
    - 'http://www.zephoria.org/thoughts/archives/2007/11/15/algorithms_for.html'
categories:
    - Aside
    - Uncategorized
tags:
    - 'life hack'
    - memory
    - questions
    - 'secret words'
    - security
---

AwesomeLifeHack SecurityQuestions Booyah