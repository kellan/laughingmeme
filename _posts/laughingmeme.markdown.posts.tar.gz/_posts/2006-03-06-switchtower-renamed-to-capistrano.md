---
id: 3273
title: 'SwitchTower renamed to Capistrano'
date: '2006-03-06T08:29:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3273'
permalink: /2006/03/06/switchtower-renamed-to-capistrano/
typo_id:
    - '3271'
mt_id:
    - ''
link_related:
    - 'http://jamis.jamisbuck.org/articles/2006/03/06/switchtower-renamed'
raw_content:
    - 'Thank goodness someone in this industry has a sense of poetry, I\''m really worried about people who are excited by \"Reploy\"'
categories:
    - Aside
tags:
    - aesthetics
    - poetry
    - rails
---

Thank goodness someone in this industry has a sense of poetry, I’m really worried about people who are excited by “Reploy”