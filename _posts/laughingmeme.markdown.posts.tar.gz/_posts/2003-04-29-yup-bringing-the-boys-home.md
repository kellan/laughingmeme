---
id: 1402
title: 'Yup, bringing the boys home'
date: '2003-04-29T10:18:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1402'
permalink: /2003/04/29/yup-bringing-the-boys-home/
typo_id:
    - '1400'
mt_id:
    - '688'
link_related:
    - 'http://counterpunch.org/nimmo04282003.html'
raw_content:
    - 'Except perhaps from a few small Middle Eastern and Central Asian countries, but stop being such a downer'
categories:
    - Aside
---

Except perhaps from a few small Middle Eastern and Central Asian countries, but stop being such a downer