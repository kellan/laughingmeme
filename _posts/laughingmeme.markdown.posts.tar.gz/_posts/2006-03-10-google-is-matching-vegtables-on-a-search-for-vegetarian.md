---
id: 3289
title: 'Google is matching &#8216;vegtables&#8217; on a search for &#8216;vegetarian&#8217;'
date: '2006-03-10T14:54:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3289'
permalink: /2006/03/10/google-is-matching-vegtables-on-a-search-for-vegetarian/
typo_id:
    - '3287'
mt_id:
    - ''
link_related:
    - 'http://www.google.com/search?hs=79m&hl=en&lr=&c2coff=1&client=firefox-a&rls=org.mozilla%3Aen-US%3Aofficial&q=vegetarian good left overs&btnG=Search'
raw_content:
    - 'The problems with stemming.  Results start with \''Simply dice the meat and vegetables...\'''
categories:
    - Aside
tags:
    - google
    - language
    - nlp
    - search
    - stemming
---

The problems with stemming. Results start with ‘Simply dice the meat and vegetables…’