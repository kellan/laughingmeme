---
id: 670
title: 'Perl Advent Calendar'
date: '2003-12-01T08:46:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=670'
permalink: /2003/12/01/perl-advent-calendar/
typo_id:
    - '668'
mt_id:
    - '1486'
link_related:
    - ''
raw_content:
    - "<p>\nIt\\'s December again, which means it is once again time for the <a href=\\\"http://www.perladvent.org/2003/\\\">Perl Advent Calendar</a>.\n</p>\n<p>\nThe first featured module is <a href=\\\"http://www.perladvent.org/2003/1st/\\\">CGI::Untaint</a>\n<blockquote>\n CGI::Untaint allows you to utilise collections of predefined regular expressions to pull things out of the cgi parameters instead.\n</blockquote>\nAnd it was suggested that it would integrate nicely with <a href=\\\"http://laughingmeme.org/archives/001475.html#001475\\\">OO::Form</a>.\n</p>"
---

It’s December again, which means it is once again time for the [Perl Advent Calendar](http://www.perladvent.org/2003/).

The first featured module is [CGI::Untaint](http://www.perladvent.org/2003/1st/)

> CGI::Untaint allows you to utilise collections of predefined regular expressions to pull things out of the cgi parameters instead.

And it was suggested that it would integrate nicely with [OO::Form](http://laughingmeme.org/archives/001475.html#001475). 