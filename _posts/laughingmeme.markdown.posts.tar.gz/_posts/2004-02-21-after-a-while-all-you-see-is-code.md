---
id: 741
title: 'After a while, all you see is code'
date: '2004-02-21T10:42:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=741'
permalink: /2004/02/21/after-a-while-all-you-see-is-code/
typo_id:
    - '739'
mt_id:
    - '1767'
link_related:
    - ''
raw_content:
    - "Do you ever have to resist the siren call of coding?  Often it seems the prefect escape.  An obliteration of self, and worries; thought processes repurposed to an obscure but engaging pursuit.  Language skills recycled into generic symbolic processors of a more orderly kind.  Problem solving turned to logical, self contained problems.  Solutions, satisfyingly difficult but never hopelessly outside of your power to effect change.  And the illusion of progress and accomplishment missing from other obliterations of self like reading.  I imagine other people find this zone in other places.  \n\nSitting here this morning, faced with a mounting, overwhelming set of problems, first of which where I\\'m going to be living a week from Monday, all I want to do is write code.  Dangerous.  I think I need to go back to some other less addictive career."
---

Do you ever have to resist the siren call of coding? Often it seems the prefect escape. An obliteration of self, and worries; thought processes repurposed to an obscure but engaging pursuit. Language skills recycled into generic symbolic processors of a more orderly kind. Problem solving turned to logical, self contained problems. Solutions, satisfyingly difficult but never hopelessly outside of your power to effect change. And the illusion of progress and accomplishment missing from other obliterations of self like reading. I imagine other people find this zone in other places.

Sitting here this morning, faced with a mounting, overwhelming set of problems, first of which where I’m going to be living a week from Monday, all I want to do is write code. Dangerous. I think I need to go back to some other less addictive career.