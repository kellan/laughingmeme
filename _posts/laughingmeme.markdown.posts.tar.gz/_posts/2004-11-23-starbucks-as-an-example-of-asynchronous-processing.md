---
id: 2664
title: 'Starbucks as an example of asynchronous processing'
date: '2004-11-23T12:54:05+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2664'
permalink: /2004/11/23/starbucks-as-an-example-of-asynchronous-processing/
typo_id:
    - '2662'
mt_id:
    - '2572'
link_related:
    - 'http://www.eaipatterns.com/ramblings/18_starbucks.html'
raw_content:
    - 'The interaction between two parties (customer and coffee shop) consists of a short synchronous interaction (ordering and paying) and a longer, asynchronous interaction (making and receiving the drink).'
categories:
    - Aside
tags:
    - async
    - coffee
    - programming
    - starbucks
---

The interaction between two parties (customer and coffee shop) consists of a short synchronous interaction (ordering and paying) and a longer, asynchronous interaction (making and receiving the drink).