---
id: 3372
title: 'Eugene has an interesting review up of &#8220;An Inconvient Truth&#8221;'
date: '2006-06-06T12:24:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3372'
permalink: /2006/06/06/eugene-has-an-interesting-review-up-of-an-inconvient-truth/
typo_id:
    - '3371'
mt_id:
    - ''
link_related:
    - 'http://www.eekim.com/blog/2006/06/05/aninconvenienttruth'
raw_content:
    - 'I was supposed to go with them, but I bailed for a weekend of digging through dusty boxes.  Hmmmm.   When [Blaine](http://romeda.org/) gets back from Spain must ask him about the grocery delivery place in Vancouver that included the carbon cost info with their products.'
categories:
    - Aside
tags:
    - environment
    - personal
---

I was supposed to go with them, but I bailed for a weekend of digging through dusty boxes. Hmmmm. When \[Blaine\](http://romeda.org/) gets back from Spain must ask him about the grocery delivery place in Vancouver that included the carbon cost info with their products.