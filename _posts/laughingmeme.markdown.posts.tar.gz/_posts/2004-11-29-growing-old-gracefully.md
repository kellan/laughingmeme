---
id: 962
title: 'Growing old gracefully'
date: '2004-11-29T19:25:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=962'
permalink: /2004/11/29/growing-old-gracefully/
typo_id:
    - '960'
mt_id:
    - '2580'
link_related:
    - ''
raw_content:
    - "<a href=\\\"http://www.penpixel.com/\\\">Phil Klein</a> asked an interesting question on the <a href=\\\"http://npogroups.org/lists/info/riders-talk\\\">Riders list</a> today.\n\n<blockquote>\nWhat are your ideas about how to plan for long life and best futures for\nyour work? Do you use or know of any methodologies that help you shepherd\nprojects into longer life?\n</blockquote>\n\nIn particular has anyone done any work on how you manage wikis and other sorts collaborative spaces (open publishing newswires perhaps) over long life cycles with various levels of engagement (initial, active, ongoing, or archival)"
tags:
    - collaboration
    - process
    - time
---

[Phil Klein](http://www.penpixel.com/) asked an interesting question on the [Riders list](http://npogroups.org/lists/info/riders-talk) today.

> What are your ideas about how to plan for long life and best futures for your work? Do you use or know of any methodologies that help you shepherd projects into longer life?

In particular has anyone done any work on how you manage wikis and other sorts collaborative spaces (open publishing newswires perhaps) over long life cycles with various levels of engagement (initial, active, ongoing, or archival)