---
id: 1857
title: 'Listening to NPR is socio-sexual signalling.'
date: '2003-11-14T13:11:02+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1857'
permalink: /2003/11/14/listening-to-npr-is-socio-sexual-signalling/
typo_id:
    - '1855'
mt_id:
    - '1426'
link_related:
    - 'http://www.gawker.com/archives/010232.php'
raw_content:
    - 'I\''m glad that is cleared up.  Because it sure as hell isn\''t the progressive public media it was supposed to be, and I was wondering what it was.'
categories:
    - Aside
tags:
    - culture
    - media
    - sex
---

I’m glad that is cleared up. Because it sure as hell isn’t the progressive public media it was supposed to be, and I was wondering what it was.