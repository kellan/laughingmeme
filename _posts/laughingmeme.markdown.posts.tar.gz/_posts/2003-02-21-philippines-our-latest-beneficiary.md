---
id: 1236
title: 'Philippines, our  latest beneficiary'
date: '2003-02-21T00:58:18+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1236'
permalink: /2003/02/21/philippines-our-latest-beneficiary/
typo_id:
    - '1234'
mt_id:
    - '429'
link_related:
    - 'http://news.bbc.co.uk/1/hi/world/asia-pacific/2786109.stm'
raw_content:
    - 'Never thought I\''d see the Crusades revived in my lifetime'
categories:
    - Aside
---

Never thought I’d see the Crusades revived in my lifetime