---
id: 742
title: 'Prince Jeb'
date: '2004-02-21T12:34:18+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=742'
permalink: /2004/02/21/prince-jeb/
typo_id:
    - '740'
mt_id:
    - '1768'
link_related:
    - ''
raw_content:
    - "Will Giuliani be the new VP?  After all Cheney seems like <a title=\\\"Guardian Unlimited | US elections 2004 | Has Bush\\'s running mate gone lame?\\\" href=\\\"http://www.guardian.co.uk/uselections2004/story/0,13918,1152054,00.html?=rss\\\">more and more of a liability</a>  These days.  Apparently not says Thomas Schaller, a professor of political science.\n<blockquote>\n\\\"Replacing Cheney with someone like Frist or Giuliani would create an heir apparent. Replacing Cheney is no way to run a proper monarchy.\\\"\n</blockquote>"
---

Will Giuliani be the new VP? After all Cheney seems like [more and more of a liability](http://www.guardian.co.uk/uselections2004/story/0,13918,1152054,00.html?=rss "Guardian Unlimited | US elections 2004 | Has Bush's running mate gone lame?") These days. Apparently not says Thomas Schaller, a professor of political science.

> “Replacing Cheney with someone like Frist or Giuliani would create an heir apparent. Replacing Cheney is no way to run a proper monarchy.”