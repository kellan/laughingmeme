---
id: 1203
title: 'UK plagiarize Iraq dossier'
date: '2003-02-09T09:38:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1203'
permalink: /2003/02/09/uk-plagiarize-iraq-dossier/
typo_id:
    - '1201'
mt_id:
    - '375'
link_related:
    - 'http://www.guardian.co.uk/Iraq/Story/0,2763,890916,00.html'
raw_content:
    - 'Supposed intelligence sources actually old academic papers'
categories:
    - Aside
---

Supposed intelligence sources actually old academic papers