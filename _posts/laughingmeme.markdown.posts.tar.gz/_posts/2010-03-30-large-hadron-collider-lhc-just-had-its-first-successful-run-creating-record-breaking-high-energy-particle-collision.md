---
id: 4536
title: 'Large Hadron Collider (LHC) just had its first successful run, creating record-breaking high-energy particle collision'
date: '2010-03-30T08:55:32+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4536'
permalink: /2010/03/30/large-hadron-collider-lhc-just-had-its-first-successful-run-creating-record-breaking-high-energy-particle-collision/
link_related:
    - 'http://press.web.cern.ch/press/PressReleases/Releases2010/PR07.10E.html'
categories:
    - Aside
tags:
    - lhc
    - physics
---

“the hunt begins for dark matter, new forces, new dimensions and the Higgs boson” – awesome.