---
id: 276
title: 'Slouching towards release, part 1.'
date: '2003-01-20T10:44:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=276'
permalink: /2003/01/20/slouching-towards-release-part-1/
typo_id:
    - '274'
mt_id:
    - '284'
link_related:
    - ''
raw_content:
    - "<p>\r\n<a href=\\\"http://www.panix.com/~comdog/\\\">brian</a> is slowly herding <a\r\nhref=\\\"http://search.cpan.org/dist/XML-RSS/\\\">XML::RSS</a> (and us rss workers)\r\ntowards a new non-dev release.  Release \\\"Dev 0.98_4\\\" is out with the my content encoding,\r\nand attribute parsing patches, <a href=\\\"http://aaronland.info/\\\">Aaron\\'s</a>\r\nnifty test suite, and <a href=\\\"http://rc3.org/\\\">Rafe\\'s</a> RSS 2.0 generation\r\ncode.  We\\'ve had some back and forth about a <a href=\\\"http://rt.cpan.org/NoAuth/Bug.html?id=1795\\\">request from pudge</a>,\r\nbut I think we\\'ve straightened it out.\r\n</p>"
tags:
    - perl
    - rss
---

[brian](http://www.panix.com/~comdog/) is slowly herding [XML::RSS](http://search.cpan.org/dist/XML-RSS/) (and us rss workers) towards a new non-dev release. Release “Dev 0.98\_4” is out with the my content encoding, and attribute parsing patches, [Aaron’s](http://aaronland.info/)nifty test suite, and [Rafe’s](http://rc3.org/) RSS 2.0 generation code. We’ve had some back and forth about a [request from pudge](http://rt.cpan.org/NoAuth/Bug.html?id=1795), but I think we’ve straightened it out.