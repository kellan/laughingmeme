---
id: 3827
title: 'Better Javadoc results using &#8220;SearchMonkey&#8221;'
date: '2008-05-21T07:19:24+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=3827'
permalink: /2008/05/21/better-javadoc-results-using-searchmonkey/
link_related:
    - 'http://www.javarants.com/2008/05/19/better-javadoc-results-using-searchmonkey/'
categories:
    - Aside
tags:
    - javadocs
    - php
    - regex
    - 'search monkey'
    - semweb
    - yahoo
---

The docs on I found on \[Yahoo’s SearchMonkey\](http://developer.yahoo.com/searchmonkey/) were all arcane XSLT, and strange feed formats ne’er before seen on the Web. But this example from Sam shows how easy it can be – a couple of regexes, and a couple of lines of PHP.