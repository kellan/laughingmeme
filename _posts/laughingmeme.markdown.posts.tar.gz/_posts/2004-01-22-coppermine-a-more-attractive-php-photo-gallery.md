---
id: 2022
title: 'Coppermine  &#8211; A More Attractive PHP Photo Gallery'
date: '2004-01-22T02:43:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2022'
permalink: /2004/01/22/coppermine-a-more-attractive-php-photo-gallery/
typo_id:
    - '2020'
mt_id:
    - '1667'
link_related:
    - 'http://coppermine.sourceforge.net/'
raw_content:
    - 'Seems to suffer from the same security problems as all PHP galleries.  But it produces RSS (which is how I found out about it)'
categories:
    - Aside
---

Seems to suffer from the same security problems as all PHP galleries. But it produces RSS (which is how I found out about it)