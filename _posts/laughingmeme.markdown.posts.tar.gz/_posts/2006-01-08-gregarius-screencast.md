---
id: 3180
title: 'Gregarius Screencast'
date: '2006-01-08T19:05:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3180'
permalink: /2006/01/08/gregarius-screencast/
typo_id:
    - '3178'
mt_id:
    - ''
link_related:
    - 'http://www.tokash.org/gregarius/gregariusScreencast.htm'
raw_content:
    - 'a screencast showing off some features of [Gregarius](http://gregarius.net/), the open source, extensible, online feed aggregator of choice. (uses Magpie)'
categories:
    - Aside
tags:
    - atom
    - magpie
    - php
    - rss
    - syndication
---

a screencast showing off some features of \[Gregarius\](http://gregarius.net/), the open source, extensible, online feed aggregator of choice. (uses Magpie)