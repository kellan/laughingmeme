---
id: 3105
title: 'Paul has relaunched mediageek on WP'
date: '2005-11-14T10:48:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3105'
permalink: /2005/11/14/paul-has-relaunched-mediageek-on-wp/
typo_id:
    - '3103'
mt_id:
    - ''
link_related:
    - 'http://www.mediageek.net/'
raw_content:
    - 'Heart warming to see more cool, radical folks moving to free codebases.'
categories:
    - Aside
tags:
    - opensource
    - wordpress
---

Heart warming to see more cool, radical folks moving to free codebases.