---
id: 1150
title: 'Libya appointed to UN Human Rights comission'
date: '2003-01-27T11:21:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1150'
permalink: /2003/01/27/libya-appointed-to-un-human-rights-comission/
typo_id:
    - '1148'
mt_id:
    - '309'
link_related:
    - 'http://news.bbc.co.uk/2/hi/africa/2672029.stm'
raw_content:
    - 'yes, that is the body the US was recently kicked off'
categories:
    - Aside
---

yes, that is the body the US was recently kicked off