---
id: 2476
title: 'Douglas Hofstadter &#8211; Person Paper on Purity in Language'
date: '2004-08-21T11:27:09+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2476'
permalink: /2004/08/21/douglas-hofstadter-person-paper-on-purity-in-language/
typo_id:
    - '2474'
mt_id:
    - '2308'
link_related:
    - 'http://www.cs.virginia.edu/~evans/cs655/readings/purity.html'
raw_content:
    - 'On the silly modern clamoring for race neutral pronouns.'
categories:
    - Aside
tags:
    - alternatehistory
    - gender
    - race
    - writing
---

On the silly modern clamoring for race neutral pronouns.