---
id: 1190
title: 'picky eating, and nuts'
date: '2003-02-04T10:59:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1190'
permalink: /2003/02/04/picky-eating-and-nuts/
typo_id:
    - '1188'
mt_id:
    - '357'
link_related:
    - 'http://www.cardhouse.com/a/nuts.htm'
raw_content:
    - 'stress resistance between nut and cake too high'
categories:
    - Aside
---

stress resistance between nut and cake too high