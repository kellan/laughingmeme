---
id: 1703
title: 'Howard Dean supporter and geek I just met at Zeitgeist'
date: '2003-09-07T16:14:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1703'
permalink: /2003/09/07/howard-dean-supporter-and-geek-i-just-met-at-zeitgeist/
typo_id:
    - '1701'
mt_id:
    - '1170'
link_related:
    - 'http://www.8bitjoystick.com/groundzero/'
raw_content:
    - 'Who says life doesn\''t come with trackback URLs?'
categories:
    - Aside
---

Who says life doesn’t come with trackback URLs?