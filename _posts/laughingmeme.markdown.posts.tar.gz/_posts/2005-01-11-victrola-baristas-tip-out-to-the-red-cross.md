---
id: 2756
title: 'Victrola baristas tip out to the Red Cross'
date: '2005-01-11T11:46:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2756'
permalink: /2005/01/11/victrola-baristas-tip-out-to-the-red-cross/
typo_id:
    - '2754'
mt_id:
    - '2703'
link_related:
    - 'http://tonx.org/index.php/archives/victrola-redcross/'
raw_content:
    - 'Good work'
categories:
    - Aside
tags:
    - coffee
    - redcross
    - relief
    - seattle
    - tsunami
---

Good work