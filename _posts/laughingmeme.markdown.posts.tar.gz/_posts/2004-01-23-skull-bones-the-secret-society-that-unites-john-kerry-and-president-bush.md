---
id: 2025
title: 'Skull &#038; Bones: The Secret Society That Unites John Kerry and President Bush'
date: '2004-01-23T01:58:58+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2025'
permalink: /2004/01/23/skull-bones-the-secret-society-that-unites-john-kerry-and-president-bush/
typo_id:
    - '2023'
mt_id:
    - '1671'
link_related:
    - 'http://www.democracynow.org/article.pl?sid=04/01/23/0445212'
raw_content:
    - 'Not that Kerry has a chance of making believable play as anything but the ultimate political insider.'
categories:
    - Aside
---

Not that Kerry has a chance of making believable play as anything but the ultimate political insider.