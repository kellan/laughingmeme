---
id: 584
title: 'Stockpiling Against the Coming Disaster'
date: '2003-09-15T23:45:24+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=584'
permalink: /2003/09/15/stockpiling-against-the-coming-disaster/
typo_id:
    - '582'
mt_id:
    - '1200'
link_related:
    - ''
raw_content:
    - "<p>\nTomorrow Seattle voters decide on the bitterly argued \\\"espresso tax\\\", which proposes to add 10-cent tax on espresso drinks to pay for child care related city programs.  Being something of a coffee shop barfly I\\'ve spent the last few weeks bombarded by <a href=\\\"http://www.noespressotax.org/\\\">Yes on child care, No on I-77</a> signs and propaganda.  And I\\'m sympathetic to the arguments that its a poorly written law that adds a significant burden to the small coffee shop.  However Starbucks has fronted much of the money for the opposition campaign which is at least one reason to vote for the initiative. (I support the more progressive $1 tax per item sold at Starbucks)\n</p>\n<p>\nYou could argue that this is an \\\"only in Seattle\\\" phenomena, but the real only in Seattle phenomena is when my house mate came home tonight and reported that the local bulk food retailer was out of the espresso beans, the 50 gallon drum had been picked clean, and they had nothing left in back.  A run on espresso beans?  That is an only in Seattle.\n</p>"
---

Tomorrow Seattle voters decide on the bitterly argued “espresso tax”, which proposes to add 10-cent tax on espresso drinks to pay for child care related city programs. Being something of a coffee shop barfly I’ve spent the last few weeks bombarded by [Yes on child care, No on I-77](http://www.noespressotax.org/) signs and propaganda. And I’m sympathetic to the arguments that its a poorly written law that adds a significant burden to the small coffee shop. However Starbucks has fronted much of the money for the opposition campaign which is at least one reason to vote for the initiative. (I support the more progressive $1 tax per item sold at Starbucks)

You could argue that this is an “only in Seattle” phenomena, but the real only in Seattle phenomena is when my house mate came home tonight and reported that the local bulk food retailer was out of the espresso beans, the 50 gallon drum had been picked clean, and they had nothing left in back. A run on espresso beans? That is an only in Seattle.