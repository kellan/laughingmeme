---
id: 3345
title: 'Blue Bottle Coffee just hit Cool Hunting.'
date: '2006-05-01T17:36:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3345'
permalink: /2006/05/01/blue-bottle-coffee-just-hit-cool-hunting/
typo_id:
    - '3344'
mt_id:
    - ''
link_related:
    - 'http://www.coolhunting.com/archives/2006/05/blue_bottle_cof.php'
raw_content:
    - 'Of course I used to listen to them before they got popular, and [Steve](http://flickr.com/photos/dogmilque/) was still the front man'
categories:
    - Aside
tags:
    - bluebottle
    - coffee
    - sanfran
---

Of course I used to listen to them before they got popular, and \[Steve\](http://flickr.com/photos/dogmilque/) was still the front man