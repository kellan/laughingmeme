---
id: 1378
title: 'Quantitative modelling of bickering couples'
date: '2003-04-24T16:06:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1378'
permalink: /2003/04/24/quantitative-modelling-of-bickering-couples/
typo_id:
    - '1376'
mt_id:
    - '653'
link_related:
    - 'http://chronicle.com/free/v49/i33/33a01401.htm'
raw_content:
    - 'Every Unhappy Family Has Its Own Bilinear Influence Function'
categories:
    - Aside
---

Every Unhappy Family Has Its Own Bilinear Influence Function