---
id: 2403
title: 'First Monday: Manifesto for the Reputation Society'
date: '2004-07-20T00:57:37+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2403'
permalink: /2004/07/20/first-monday-manifesto-for-the-reputation-society/
typo_id:
    - '2401'
mt_id:
    - '2210'
link_related:
    - 'http://www.firstmonday.org/issues/issue9_7/masum/index.html'
raw_content:
    - 'Excellent introduction to the issues.'
categories:
    - Aside
tags:
    - collaboration
    - reputation
---

Excellent introduction to the issues.