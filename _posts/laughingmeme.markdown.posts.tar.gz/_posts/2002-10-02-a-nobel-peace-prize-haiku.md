---
id: 172
title: 'A Nobel Peace Prize Haiku'
date: '2002-10-02T19:02:50+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=172'
permalink: /2002/10/02/a-nobel-peace-prize-haiku/
typo_id:
    - '170'
mt_id:
    - '180'
link_related:
    - ''
raw_content:
    - "<pre>\r\n<a href=\\\"http://haiku.fuzrocks.com\\\">\r\n        My strategery:\r\nNuke the motherfuck out of\r\n        Henry Kissinger.\r\n</a>\r\n</pre>\r\nby <a href=\\\"http://gus.protest.net\\\">gus</a>"
---

```

<a href="http://haiku.fuzrocks.com">
        My strategery:
Nuke the motherfuck out of
        Henry Kissinger.
</a>
```

by [gus](http://gus.protest.net)