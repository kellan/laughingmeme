---
id: 1891
title: 'Top Ten Open Source Campaign Apps'
date: '2003-11-24T14:20:24+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1891'
permalink: /2003/11/24/top-ten-open-source-campaign-apps/
typo_id:
    - '1889'
mt_id:
    - '1477'
link_related:
    - 'http://blogs.onenw.org/jon/archives/001033.html'
raw_content:
    - 'Having contributed to 5 of the mentioned codebases, I should probably write something more about this.'
categories:
    - Aside
---

Having contributed to 5 of the mentioned codebases, I should probably write something more about this.