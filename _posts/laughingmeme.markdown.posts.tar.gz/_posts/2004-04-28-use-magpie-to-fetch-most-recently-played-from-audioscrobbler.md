---
id: 2232
title: 'Use Magpie to fetch most recently played from Audioscrobbler'
date: '2004-04-28T17:55:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2232'
permalink: /2004/04/28/use-magpie-to-fetch-most-recently-played-from-audioscrobbler/
typo_id:
    - '2230'
mt_id:
    - '1980'
link_related:
    - 'http://fuddland.org.uk/archives/2004/04/27/audioscrobbler.php'
raw_content:
    - 'Cool, even if haven\''t had much luck getting the Audioscrobbler plugin to work :-/'
categories:
    - Aside
tags:
    - magpie
    - mp3
    - rss
---

Cool, even if haven’t had much luck getting the Audioscrobbler plugin to work :-/