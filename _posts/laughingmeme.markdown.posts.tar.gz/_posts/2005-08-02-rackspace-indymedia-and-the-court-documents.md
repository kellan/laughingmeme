---
id: 1108
title: 'Rackspace, Indymedia, and the Court Documents'
date: '2005-08-02T08:13:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1108'
permalink: /2005/08/02/rackspace-indymedia-and-the-court-documents/
typo_id:
    - '1106'
mt_id:
    - '3033'
link_related:
    - ''
raw_content:
    - "We may never know what the Rackspace was thinking, but at least due to the diligent work of the EFF we know that Rackspace responded irresponsibly, dishonestly, and disproportionately when they yanked 20 IMCs (and the BLAG Linux project) offline last Fall, and then continued to lie about and cover up the facts of the case.\n\nSee the [EFF\\'s ongoing coverage](http://www.eff.org/Censorship/Indymedia/), [Jebba\\'s photo response](http://jebba.blagblagblag.org/?p=174), and [Evan\\'s sum up](http://anarchogeek.com/articles/2005/08/01/ahimsa-indymedia-documents-unsealed).\n\nThe short version:  Don\\'t use [Rackspace](http://www.rackspace.com) or [ServerBeach](http://serverbeach.com/) if you value your data, your time, or your hardware."
---

We may never know what the Rackspace was thinking, but at least due to the diligent work of the EFF we know that Rackspace responded irresponsibly, dishonestly, and disproportionately when they yanked 20 IMCs (and the BLAG Linux project) offline last Fall, and then continued to lie about and cover up the facts of the case.

See the \[EFF’s ongoing coverage\](http://www.eff.org/Censorship/Indymedia/), \[Jebba’s photo response\](http://jebba.blagblagblag.org/?p=174), and \[Evan’s sum up\](http://anarchogeek.com/articles/2005/08/01/ahimsa-indymedia-documents-unsealed).

The short version: Don’t use \[Rackspace\](http://www.rackspace.com) or \[ServerBeach\](http://serverbeach.com/) if you value your data, your time, or your hardware.