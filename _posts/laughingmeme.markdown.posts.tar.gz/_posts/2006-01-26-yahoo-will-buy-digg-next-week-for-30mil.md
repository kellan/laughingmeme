---
id: 3222
title: 'Yahoo Will Buy Digg Next Week for $30mil?'
date: '2006-01-26T11:52:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3222'
permalink: /2006/01/26/yahoo-will-buy-digg-next-week-for-30mil/
typo_id:
    - '3220'
mt_id:
    - ''
link_related:
    - 'http://www.feedblog.org/2006/01/yahoo_will_buy_.html'
raw_content:
    - 'Dear god it can\''t be worth that much.  Somehow Digg has always seemed soooo boring, traffic numbers aside. [Or not](http://thomashawk.com/2006/01/yahoo-buying-digg-not-anytime-soon.html)'
categories:
    - Aside
tags:
    - acquisition
    - digg
    - web2.0
    - yahoo
---

Dear god it can’t be worth that much. Somehow Digg has always seemed soooo boring, traffic numbers aside. \[Or not\](http://thomashawk.com/2006/01/yahoo-buying-digg-not-anytime-soon.html)