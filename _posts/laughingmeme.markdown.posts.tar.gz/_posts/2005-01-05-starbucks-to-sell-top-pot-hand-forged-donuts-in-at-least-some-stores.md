---
id: 2742
title: 'Starbucks to sell Top Pot &#8220;Hand Forged&#8221; Donuts in at least some stores'
date: '2005-01-05T11:46:18+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2742'
permalink: /2005/01/05/starbucks-to-sell-top-pot-hand-forged-donuts-in-at-least-some-stores/
typo_id:
    - '2740'
mt_id:
    - '2684'
link_related:
    - 'http://starbucksgossip.typepad.com/_/2005/01/report_starbuck.html'
raw_content:
    - 'Interesting to see how the independents respond'
categories:
    - Aside
tags:
    - coffee
    - seattle
---

Interesting to see how the independents respond