---
id: 1403
title: 'Thou shalt not use threads to serve dynamic content'
date: '2003-04-29T20:39:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1403'
permalink: /2003/04/29/thou-shalt-not-use-threads-to-serve-dynamic-content/
typo_id:
    - '1401'
mt_id:
    - '690'
link_related:
    - 'http://www.edwardbear.org/blog/archives/000168.html'
raw_content:
    - 'Methinks he doth overstate the case'
categories:
    - Aside
---

Methinks he doth overstate the case