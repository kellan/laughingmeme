---
id: 5212
title: 'Going on a honeymoon, be back soon'
date: '2013-03-04T19:40:30+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=5212'
permalink: /2013/03/04/going-on-a-honeymoon-be-back-soon/
categories:
    - Uncategorized
---

[![Happy](http://farm9.staticflickr.com/8243/8523678022_5ebb0781f5_c.jpg)](http://www.flickr.com/photos/curlyjazz/8523678022/ "Happy by curlyjazz, on Flickr")