---
id: 3703
title: 'MadCat Picks'
date: '2007-09-10T21:53:17+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/09/10/madcat-picks/'
permalink: /2007/09/10/madcat-picks/
categories:
    - Uncategorized
tags:
    - art
    - events
    - film
    - local
    - sf
---

![](http://www.madcatfilmfestival.org/images/fest07/MC11.jpg)

\[At the Margins\](http://www.madcatfilmfestival.org/programs.html#prog3), Fri Sept 14th, ATA, 7:30pm. Shorts. “Golden Kitchen” sounds particuarily intriguing to me.

\[Close to Home\](http://www.madcatfilmfestival.org/programs.html#prog7), Fri Fri Sept 14th, ATA, 8:30pm. In particular “Un Hombre Tranquilo”.

\[ID Docs\](http://www.madcatfilmfestival.org/programs.html#prog4), Tue Sept 18th, 6:30pm for free BBQ. El Rio.