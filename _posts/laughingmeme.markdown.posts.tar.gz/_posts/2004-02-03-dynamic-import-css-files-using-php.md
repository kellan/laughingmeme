---
id: 2054
title: 'Dynamic @import CSS files using PHP'
date: '2004-02-03T13:46:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2054'
permalink: /2004/02/03/dynamic-import-css-files-using-php/
typo_id:
    - '2052'
mt_id:
    - '1716'
link_related:
    - 'http://www.1976design.com/blog/archive/2004/02/03/php-dynamic-css/'
raw_content:
    - 'The weather banner just keeps getting better.'
categories:
    - Aside
---

The weather banner just keeps getting better.