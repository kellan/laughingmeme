---
id: 1676
title: 'The flying great white shark'
date: '2003-08-24T04:08:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1676'
permalink: /2003/08/24/the-flying-great-white-shark/
typo_id:
    - '1674'
mt_id:
    - '1130'
link_related:
    - 'http://www.apexpredators.com/store/showCategoriesProducts.asp?categoryID=6'
raw_content:
    - 'A regrettable, if understandable innovation on the classic.'
categories:
    - Aside
---

A regrettable, if understandable innovation on the classic.