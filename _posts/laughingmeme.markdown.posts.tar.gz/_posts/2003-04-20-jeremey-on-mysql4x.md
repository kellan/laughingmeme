---
id: 1367
title: 'Jeremey on MySQL4.x'
date: '2003-04-20T12:07:11+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1367'
permalink: /2003/04/20/jeremey-on-mysql4x/
typo_id:
    - '1365'
mt_id:
    - '637'
link_related:
    - 'http://www.linux-mag.com/2003-01/mysql_01.html'
raw_content:
    - 'good overview, plus tips'
categories:
    - Aside
---

good overview, plus tips