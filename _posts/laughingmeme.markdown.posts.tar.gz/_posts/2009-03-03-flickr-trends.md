---
id: 4180
title: 'Flickr Trends'
date: '2009-03-03T07:54:29+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4180'
permalink: /2009/03/03/flickr-trends/
categories:
    - Uncategorized
tags:
    - appengine
    - flickr
    - hacking
---

[![snow vs flowers](http://farm4.static.flickr.com/3538/3325192577_eb3b6fc1a9.jpg)](http://www.flickr.com/photos/kellan/3325192577/ "snow vs flowers by kellan, on Flickr")

Based on Derek’s [NYT Trender](http://tyn-search.appspot.com/?query1=twitter&query2=facebook&Trend=Trend) and some APIs we haven’t gotten around to releasing, I spent 20 minutes whipping up [Flickr Trends](http://flickrtrends.appspot.com/?query1=snow&query2=flowers&Trend=Trend) yesterday morning.

App Engine is awesome for this kind of stuff.

Favorite’s I’ve found so far:

- [snow vs flowers](http://flickrtrends.appspot.com/?query1=snow&query2=flowers&Trend=Trend)
- [party vs wedding](http://flickrtrends.appspot.com/?query1=party&query2=wedding&Trend=Trend)
- [jumping vs hdr](http://flickrtrends.appspot.com/?query1=jumping&query2=hdr&Trend=Trend) (oooh, [365 vs hdr](http://flickrtrends.appspot.com/?query1=365&query2=hdr&Trend=Trend) is more fun.)