---
id: 2186
title: 'Did Fallujah sound familiar to you as well?'
date: '2004-04-05T11:58:02+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2186'
permalink: /2004/04/05/did-fallujah-sound-familiar-to-you-as-well/
typo_id:
    - '2184'
mt_id:
    - '1918'
link_related:
    - 'http://dominionpaper.ca/weblog/2004/04/sounds_familiar.html'
raw_content:
    - 'It\''s where US soldiers fired on an anti-occupation protest in April, killing 17 people and wounding more than 70.'
categories:
    - Aside
---

It’s where US soldiers fired on an anti-occupation protest in April, killing 17 people and wounding more than 70.