---
id: 1771
title: 'Javascript client side date parsing'
date: '2003-10-06T19:26:13+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1771'
permalink: /2003/10/06/javascript-client-side-date-parsing/
typo_id:
    - '1769'
mt_id:
    - '1288'
link_related:
    - 'http://simon.incutio.com/archive/2003/10/06/betterDateInput'
raw_content:
    - 'Proposed replacement for the calendar style javascript date pickers.  Interesting.'
categories:
    - Aside
---

Proposed replacement for the calendar style javascript date pickers. Interesting.