---
id: 3328
title: '&#8220;If I want to beat Google? I would throw everything I have got at an AdSense killer.&#8221;'
date: '2006-04-17T10:57:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3328'
permalink: /2006/04/17/if-i-want-to-beat-google-i-would-throw-everything-i-have-got-at-an-adsense-killer/
typo_id:
    - '3327'
mt_id:
    - ''
link_related:
    - 'http://glinden.blogspot.com/2006/04/kill-google-vol-3.html'
raw_content:
    - 'Short, interesting take on how to build a better AdSense'
categories:
    - Aside
tags:
    - google
    - microsoft
    - money
    - search
---

Short, interesting take on how to build a better AdSense