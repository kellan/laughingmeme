---
id: 2660
title: 'Their certainly stretching the defintion of an &#8220;all volunteer army&#8221;.'
date: '2004-11-19T23:25:01+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2660'
permalink: /2004/11/19/their-certainly-stretching-the-defintion-of-an-all-volunteer-army/
typo_id:
    - '2658'
mt_id:
    - '2567'
link_related:
    - 'http://www.nytimes.com/2004/11/16/national/16reserves.html?pagewanted=1&ex=1258347600'
raw_content:
    - 'Former G.I.\''s, Ordered to War, Fight Not to Go'
categories:
    - Aside
tags:
    - politics
    - war
---

Former G.I.’s, Ordered to War, Fight Not to Go