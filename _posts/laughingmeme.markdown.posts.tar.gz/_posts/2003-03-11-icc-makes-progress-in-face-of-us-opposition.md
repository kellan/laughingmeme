---
id: 1292
title: 'ICC makes progress in face of US opposition'
date: '2003-03-11T09:22:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1292'
permalink: /2003/03/11/icc-makes-progress-in-face-of-us-opposition/
typo_id:
    - '1290'
mt_id:
    - '511'
link_related:
    - 'http://news.bbc.co.uk/1/hi/world/europe/2838491.stm'
raw_content:
    - 'Its been a long, hard road, but someday we might have an International Criminal Court'
categories:
    - Aside
---

Its been a long, hard road, but someday we might have an International Criminal Court