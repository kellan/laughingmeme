---
id: 2973
title: 'Public Screening of &#8220;Blogumentary&#8221;, 7pm, at the Berkman'
date: '2005-08-02T14:32:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2973'
permalink: /2005/08/02/public-screening-of-blogumentary-7pm-at-the-berkman/
typo_id:
    - '2971'
mt_id:
    - '3034'
link_related:
    - 'http://cyber.law.harvard.edu/home/home?wid=10&func=viewSubmission&sid=789'
raw_content:
    - Attending.
categories:
    - Aside
tags:
    - berkman
    - blogging
    - boston
    - documentary
    - events
    - film
---

Attending.