---
id: 941
title: 'Truth and Cupcakes'
date: '2004-10-24T10:37:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=941'
permalink: /2004/10/24/truth-and-cupcakes/
typo_id:
    - '939'
mt_id:
    - '2487'
link_related:
    - ''
raw_content:
    - 'I\''ve always been inclined to treat the cupcake bakeries as more novelty then specialty, and the near universal reports of long lines, and disappointment surrounding the much hyped <a href=\"http://www.nyceats.net/photos/eats/magnolia02.html\">Magnolia</a> do nothing to disuade me on this point.  That said you\''ve got to respect <a href=\"http://www.veritecoffee.com/\">Verite Coffee</a>/<a href=\"http://cupcakeroyale.com/\">Cupcake Royale</a> [flash] for opening a large, gleaming new location in downtown Ballard, smack in the face of Tully\''s and Starbucks.  Ballard aesthetic is out in force, with paint on plywood faux movie star posters of (famous? imaginary?) drag queens, Coffee Verite branded hoodies, and yes, a truckers cap or two.  The coffee however is good, the space airy and well lit, the cupcakes are certainly no worse then home made, the sound track is Air, power outlets are plentiful if clumpily distributed, and, of course, the <a href=\"http://seattle.wifimug.org/index.cgi?VeriteCoffeeBallard\">wireless is free.</a>'
tags:
    - nyc
    - seattle
---

I’ve always been inclined to treat the cupcake bakeries as more novelty then specialty, and the near universal reports of long lines, and disappointment surrounding the much hyped [Magnolia](http://www.nyceats.net/photos/eats/magnolia02.html) do nothing to disuade me on this point. That said you’ve got to respect [Verite Coffee](http://www.veritecoffee.com/)/[Cupcake Royale](http://cupcakeroyale.com/) \[flash\] for opening a large, gleaming new location in downtown Ballard, smack in the face of Tully’s and Starbucks. Ballard aesthetic is out in force, with paint on plywood faux movie star posters of (famous? imaginary?) drag queens, Coffee Verite branded hoodies, and yes, a truckers cap or two. The coffee however is good, the space airy and well lit, the cupcakes are certainly no worse then home made, the sound track is Air, power outlets are plentiful if clumpily distributed, and, of course, the [wireless is free.](http://seattle.wifimug.org/index.cgi?VeriteCoffeeBallard)