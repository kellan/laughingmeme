---
id: 2762
title: 'On code libraries and databases'
date: '2005-01-15T12:26:25+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2762'
permalink: /2005/01/15/on-code-libraries-and-databases/
typo_id:
    - '2760'
mt_id:
    - '2711'
link_related:
    - 'http://alec.bohemiandrive.com/perm/2005/01/15/on-code-libraries'
raw_content:
    - 'On the need to develop a pattern in PHP for swapping DBO layers'
categories:
    - Aside
tags:
    - oo
    - orm
    - php
    - programming
---

On the need to develop a pattern in PHP for swapping DBO layers