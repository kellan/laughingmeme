---
id: 1181
title: 'majority of Americans support bombing Saskatchewan'
date: '2003-01-31T19:34:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1181'
permalink: /2003/01/31/majority-of-americans-support-bombing-saskatchewan/
typo_id:
    - '1179'
mt_id:
    - '345'
link_related:
    - 'http://www.advogato.org/person/MichaelCrawford/diary.html?start=59'
raw_content:
    - 'it would be boring and cliche if it wasn\''t so important and painful'
categories:
    - Aside
---

it would be boring and cliche if it wasn’t so important and painful