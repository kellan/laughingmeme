---
id: 2014
title: 'Trackback -> Delicious'
date: '2004-01-19T02:54:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2014'
permalink: /2004/01/19/trackback-delicious/
typo_id:
    - '2012'
mt_id:
    - '1654'
link_related:
    - 'http://hacker.unixpunx.org/mutiny/log/archives/000005.html'
raw_content:
    - 'Post to del.icio.us from within MT'
categories:
    - Aside
---

Post to del.icio.us from within MT