---
id: 1980
title: 'Postfix: The Definitive Guide'
date: '2004-01-03T16:13:02+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1980'
permalink: /2004/01/03/postfix-the-definitive-guide/
typo_id:
    - '1978'
mt_id:
    - '1601'
link_related:
    - 'http://www.oreilly.com/catalog/postfix/'
raw_content:
    - 'Of course Postfix, unlike Sendmail is usable without a tome at hand.'
categories:
    - Aside
---

Of course Postfix, unlike Sendmail is usable without a tome at hand.