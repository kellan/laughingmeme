---
id: 423
title: '1yr anniversary'
date: '2003-05-03T06:54:54+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=423'
permalink: /2003/05/03/1yr-anniversary/
typo_id:
    - '421'
mt_id:
    - '703'
link_related:
    - ''
raw_content:
    - 'With all these people celebrating their blog birthdays I thought I would check back and see when mine was.  I missed it.   My first post was a <a href=\"http://laughingmeme.org/archives/000002.html\">year ago, April 10th</a>.'
---

With all these people celebrating their blog birthdays I thought I would check back and see when mine was. I missed it. My first post was a [year ago, April 10th](http://laughingmeme.org/archives/000002.html).