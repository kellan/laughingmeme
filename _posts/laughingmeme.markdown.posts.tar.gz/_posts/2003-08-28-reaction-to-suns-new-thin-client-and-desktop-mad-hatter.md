---
id: 1693
title: 'Reaction to Sun&#8217;s new thin client, and desktop, Mad Hatter.'
date: '2003-08-28T22:11:17+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1693'
permalink: /2003/08/28/reaction-to-suns-new-thin-client-and-desktop-mad-hatter/
typo_id:
    - '1691'
mt_id:
    - '1155'
link_related:
    - 'http://asiatica.org/~ludo/'
raw_content:
    - 'I\''d use it just for the name.  Hell I\''d buy a WindowsOS codenamed Chesire.'
categories:
    - Aside
---

I’d use it just for the name. Hell I’d buy a WindowsOS codenamed Chesire.