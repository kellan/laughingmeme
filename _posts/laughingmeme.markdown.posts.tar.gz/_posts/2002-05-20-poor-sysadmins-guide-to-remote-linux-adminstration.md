---
id: 30
title: 'Poor Sysadmin&#8217;s Guide to Remote Linux Adminstration'
date: '2002-05-20T11:13:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=30'
permalink: /2002/05/20/poor-sysadmins-guide-to-remote-linux-adminstration/
typo_id:
    - '28'
mt_id:
    - '26'
link_related:
    - ''
raw_content:
    - '<a href=\"http://monkeyfist.com\">Kendall</a> at O\''ReillyNet: <a href=\"http://linux.oreillynet.com/lpt/a//linux/2002/05/09/sysadminguide.html\">Poor Sysadmin\''s Guide to Remote Linux Adminstration</a> <br> Very useful, and insightful look at choosing a daemon monitoring tool.  Hopefully first in a series.'
---

[Kendall](http://monkeyfist.com) at O’ReillyNet: [Poor Sysadmin’s Guide to Remote Linux Adminstration](http://linux.oreillynet.com/lpt/a//linux/2002/05/09/sysadminguide.html)   
 Very useful, and insightful look at choosing a daemon monitoring tool. Hopefully first in a series.