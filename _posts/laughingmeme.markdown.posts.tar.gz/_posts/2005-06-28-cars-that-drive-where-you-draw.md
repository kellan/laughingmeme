---
id: 2958
title: 'Cars that drive where you draw'
date: '2005-06-28T08:56:48+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2958'
permalink: /2005/06/28/cars-that-drive-where-you-draw/
typo_id:
    - '2956'
mt_id:
    - '3011'
link_related:
    - 'http://www.we-make-money-not-art.com/archives/006304.php'
raw_content:
    - 'Been a long time since I saw a toy car I wanted, but I love the idea of a written/annotated interface'
categories:
    - Aside
tags:
    - annotation
    - car
    - inspiration
    - interface
    - st
    - toy
    - wishlist
---

Been a long time since I saw a toy car I wanted, but I love the idea of a written/annotated interface