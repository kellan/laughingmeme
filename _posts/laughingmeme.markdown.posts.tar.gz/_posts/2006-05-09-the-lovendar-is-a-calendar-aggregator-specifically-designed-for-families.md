---
id: 3354
title: '&#8220;The Lovendar is a calendar aggregator specifically designed for families.'
date: '2006-05-09T16:54:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3354'
permalink: /2006/05/09/the-lovendar-is-a-calendar-aggregator-specifically-designed-for-families/
typo_id:
    - '3353'
mt_id:
    - ''
link_related:
    - 'http://mashpit.pbwiki.com/TheLovendar'
raw_content:
    - 'It includes the stuff you don\''t normally put into your calendar, but you really should.\"  Nice!'
categories:
    - Aside
tags:
    - calendaring
    - creative
    - mashup
---

It includes the stuff you don’t normally put into your calendar, but you really should.” Nice!