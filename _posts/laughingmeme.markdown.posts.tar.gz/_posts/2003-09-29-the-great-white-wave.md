---
id: 607
title: 'The Great White Wave'
date: '2003-09-29T00:13:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=607'
permalink: /2003/09/29/the-great-white-wave/
typo_id:
    - '605'
mt_id:
    - '1253'
link_related:
    - ''
raw_content:
    - "<p>\nAs far as I\\'m concerned the soy milk wars are over; White Wave\\'s Silk won.  The only soy milk I choose in preference to milk (except the raw, sweet, creamy milk from my great uncle\\'s dairy, but that is another story) due to its taste, and not due to the fact that it doesn\\'t leave my with an upset stomach.  It doesn\\'t come cheap, but Silk tastes great, comes in a nice, familiar milk-like container, GMO free and organic, and over the last year or two has become increasingly accessible, even in the most main-stream food outlets.  And its made by two funky, ex-traveler types, who used to <a href=\\\"http://www.whitewave.com/index.php?id=27&#38;bid=1\\\">make tofu in a bucket and delivering it to local stores in a little red wagon.</a>  Well, once upon a time, actually these days its <a href=\\\"http://www.vegparadise.com/news20.html\\\">a wholly-owned subsidiary</a> of <a href=\\\"http://www.deanfoods.com/\\\">Dean Foods Company</a>, the largest dairy company in the U.S.\n</p>\n<p>\n<h3>Starbucks\\' Exclusive Provider</h3>\nIt was drawn to my attention today (probably by the new, very prominent advertising campaign) that White Wave is now even easier to find -- as the <a href=\\\"http://www.whitewave.com/index.php?id=108&#38;pid=26\\\">exclusive provider of soymilk to Starbucks</a>, who has been offering a \\\"special formula\\\" of Silk to \\\"complement their hand-crafted beverages using Starbucks signature espresso roast and Tazo(R) Chai\\\" (you did know Tazo was Starbucks, right?)  since February.  Ugh.  \n</p>\n<p>\nI\\'d like to think this is where capitalism would kick in and work for me, my product having gone from a specialty item, to a mass produced, mass consumed product of some evil corporation, and now the price would go down.  I\\'m not getting my hopes too high though.\n</p>"
---

As far as I’m concerned the soy milk wars are over; White Wave’s Silk won. The only soy milk I choose in preference to milk (except the raw, sweet, creamy milk from my great uncle’s dairy, but that is another story) due to its taste, and not due to the fact that it doesn’t leave my with an upset stomach. It doesn’t come cheap, but Silk tastes great, comes in a nice, familiar milk-like container, GMO free and organic, and over the last year or two has become increasingly accessible, even in the most main-stream food outlets. And its made by two funky, ex-traveler types, who used to [make tofu in a bucket and delivering it to local stores in a little red wagon.](http://www.whitewave.com/index.php?id=27&bid=1) Well, once upon a time, actually these days its [a wholly-owned subsidiary](http://www.vegparadise.com/news20.html) of [Dean Foods Company](http://www.deanfoods.com/), the largest dairy company in the U.S.

### Starbucks’ Exclusive Provider

It was drawn to my attention today (probably by the new, very prominent advertising campaign) that White Wave is now even easier to find — as the [exclusive provider of soymilk to Starbucks](http://www.whitewave.com/index.php?id=108&pid=26), who has been offering a “special formula” of Silk to “complement their hand-crafted beverages using Starbucks signature espresso roast and Tazo(R) Chai” (you did know Tazo was Starbucks, right?) since February. Ugh.  
I’d like to think this is where capitalism would kick in and work for me, my product having gone from a specialty item, to a mass produced, mass consumed product of some evil corporation, and now the price would go down. I’m not getting my hopes too high though.