---
id: 3670
title: 'treetop: packrat parsing in Ruby'
date: '2007-06-29T00:38:23+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/06/29/treetop-packrat-parsing-in-ruby/'
permalink: /2007/06/29/treetop-packrat-parsing-in-ruby/
link_related:
    - 'http://rubyforge.org/projects/treetop/'
categories:
    - Aside
    - Uncategorized
tags:
    - compiler
    - parsing
    - ruby
---

Perfect timing, been meaning to revisit PEGs since \[the other week\](http://twitter.com/stevej/statuses/119364052). Nice DSL for grammar specification.