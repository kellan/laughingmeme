---
id: 3063
title: 'Windows Calendar in Windows Vista Build 5231'
date: '2005-10-26T18:30:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3063'
permalink: /2005/10/26/windows-calendar-in-windows-vista-build-5231/
typo_id:
    - '3061'
mt_id:
    - ''
link_related:
    - 'http://www.longhornblogs.com/bleblanc/archive/2005/10/19/15005.aspx'
raw_content:
    - 'Wow, they\''ll almost replicate all the features of Apple\''s intentionally crippled calendaring toy'
categories:
    - Aside
tags:
    - calendaring
    - ical
    - microsoft
---

Wow, they’ll almost replicate all the features of Apple’s intentionally crippled calendaring toy