---
id: 1280
title: 'New IMC:  Indymedia TK'
date: '2003-03-04T22:37:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1280'
permalink: /2003/03/04/new-imc-indymedia-tk/
typo_id:
    - '1278'
mt_id:
    - '495'
link_related:
    - 'http://www.indymedia.tk/'
raw_content:
    - 'Disclaimer: Any possible simularities with real existing worlds are purely coincidental...'
categories:
    - Aside
---

Disclaimer: Any possible simularities with real existing worlds are purely coincidental…