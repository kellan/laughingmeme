---
id: 3637
title: 'SANTA CLARA, Calif. &#8212; March 28, 2000: &#8220;Smile, You&#8217;re On Yahoo! Photos&#8221;'
date: '2007-05-03T23:46:12+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/05/03/santa-clara-calif-march-28-2000-smile-youre-on-yahoo-photos/'
permalink: /2007/05/03/santa-clara-calif-march-28-2000-smile-youre-on-yahoo-photos/
link_related:
    - 'http://docs.yahoo.com/docs/pr/release497.html'
categories:
    - Aside
    - Uncategorized
tags:
    - flickr
    - history
    - photos
    - yahoo
    - 'yahoo photos'
---

Initial press release.