---
id: 1575
title: 'SQLite Performance Tip'
date: '2003-07-02T14:12:21+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1575'
permalink: /2003/07/02/sqlite-performance-tip/
typo_id:
    - '1573'
mt_id:
    - '950'
link_related:
    - 'http://www.edwardbear.org/blog/archives/000211.html'
raw_content:
    - 'SQLite seems to be thriving as the new PHP DB of choice'
categories:
    - Aside
---

SQLite seems to be thriving as the new PHP DB of choice