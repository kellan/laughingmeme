---
id: 1342
title: 'How the British bombed Iraq in the 1920s'
date: '2003-04-01T23:03:18+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1342'
permalink: /2003/04/01/how-the-british-bombed-iraq-in-the-1920s/
typo_id:
    - '1340'
mt_id:
    - '594'
link_related:
    - 'http://wsws.org/articles/2003/apr2003/1920-a01.shtml'
raw_content:
    - 'History has a way of repeating itself'
categories:
    - Aside
---

History has a way of repeating itself