---
id: 2408
title: 'Charlie Stross:  A brief rant about ebooks.'
date: '2004-07-27T17:45:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2408'
permalink: /2004/07/27/charlie-stross-a-brief-rant-about-ebooks/
typo_id:
    - '2406'
mt_id:
    - '2220'
link_related:
    - 'http://www.antipope.org/charlie/blosxom.cgi/2004/Jul/27#ebook-1'
raw_content:
    - 'Examines the tech, business, and contract issues of ebooks'
categories:
    - Aside
tags:
    - books
    - ebooks
---

Examines the tech, business, and contract issues of ebooks