---
id: 1603
title: 'Unit testing is interactive development for compiled languages'
date: '2003-07-17T12:54:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1603'
permalink: /2003/07/17/unit-testing-is-interactive-development-for-compiled-languages/
typo_id:
    - '1601'
mt_id:
    - '988'
link_related:
    - 'http://patricklogan.blogspot.com/archives/2003_07_13_patricklogan_archive.html#105828211797061535'
raw_content:
    - 'Command line development for Java, etc.'
categories:
    - Aside
---

Command line development for Java, etc.