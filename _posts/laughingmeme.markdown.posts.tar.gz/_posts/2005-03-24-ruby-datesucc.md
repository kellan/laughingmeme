---
id: 2878
title: 'Ruby Date#succ'
date: '2005-03-24T20:15:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2878'
permalink: /2005/03/24/ruby-datesucc/
typo_id:
    - '2876'
mt_id:
    - '2874'
link_related:
    - 'http://redhanded.hobix.com/inspect/methodCheckDateSucc.html'
raw_content:
    - 'On Duck Hunting and Date manip in Ruby. (still ain\''t as nice as Perl\''s DateTime)'
categories:
    - Aside
tags:
    - calendaring
    - ruby
---

On Duck Hunting and Date manip in Ruby. (still ain’t as nice as Perl’s DateTime)