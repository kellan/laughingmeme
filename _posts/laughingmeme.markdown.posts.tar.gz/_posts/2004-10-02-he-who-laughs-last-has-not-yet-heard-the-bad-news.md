---
id: 924
title: 'He who laughs last has not yet heard the bad news'
date: '2004-10-02T21:13:53+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=924'
permalink: /2004/10/02/he-who-laughs-last-has-not-yet-heard-the-bad-news/
typo_id:
    - '922'
mt_id:
    - '2444'
link_related:
    - ''
raw_content:
    - "I don\\'t remember what I went in looking for, but I came out of <a href=\\\"http://www.sonicboomrecords.com/\\\">Sonic Boom</a> with the eponymous <a href=\\\"http://www.dresdendolls.com/\\\">The Dresden Dolls</a> largely on the basis of mentions by <a href=\\\"http://whump.com/moreLikeThis\\\">Bill</a>, and <a href=\\\"http://jwz.livejournal.com/\\\">JWZ</a>, their <a href=\\\"http://www.dresdendolls.com/\\\">lovely website</a> (turn on the sound for the splash screen), the delightful conceit of a self described \\\"Brechtian punk band\\\".\n\nI\\'m still working through the sound, but their persona kind of reminds me of a more romantic <a href=\\\"http://www.bindlestiff.org/\\\">Bindlestiff Family Circus</a> (also with Massachusetts roots), though I suppose they both trace their roots back to the same cabaret aesthetic.\n\nThey seem like they would be great to see live.  Of course playing Seattle, the <a href=\\\"http://laughingmeme.org/archives/002388.html\\\"><b>same damn night</b></a> as <a href=\\\"http://www.houseoftomorrow.com/index.php\\\">Magnetic Fields</a>.  Maybe Portland, Nov 15th?  (they are also playing Boston for Halloween, but I\\'ve got previous, long standing, annual Halloween plans)"
tags:
    - boston
---

I don’t remember what I went in looking for, but I came out of [Sonic Boom](http://www.sonicboomrecords.com/) with the eponymous [The Dresden Dolls](http://www.dresdendolls.com/) largely on the basis of mentions by [Bill](http://whump.com/moreLikeThis), and [JWZ](http://jwz.livejournal.com/), their [lovely website](http://www.dresdendolls.com/) (turn on the sound for the splash screen), the delightful conceit of a self described “Brechtian punk band”.

I’m still working through the sound, but their persona kind of reminds me of a more romantic [Bindlestiff Family Circus](http://www.bindlestiff.org/) (also with Massachusetts roots), though I suppose they both trace their roots back to the same cabaret aesthetic.

They seem like they would be great to see live. Of course playing Seattle, the [**same damn night**](http://laughingmeme.org/archives/002388.html) as [Magnetic Fields](http://www.houseoftomorrow.com/index.php). Maybe Portland, Nov 15th? (they are also playing Boston for Halloween, but I’ve got previous, long standing, annual Halloween plans)