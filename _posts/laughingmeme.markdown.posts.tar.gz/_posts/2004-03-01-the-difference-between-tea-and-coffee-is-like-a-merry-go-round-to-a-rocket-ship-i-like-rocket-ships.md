---
id: 2109
title: 'The difference between tea and coffee is like a merry-go-round to a rocket ship! I like rocket ships!'
date: '2004-03-01T20:01:50+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2109'
permalink: /2004/03/01/the-difference-between-tea-and-coffee-is-like-a-merry-go-round-to-a-rocket-ship-i-like-rocket-ships/
typo_id:
    - '2107'
mt_id:
    - '1806'
link_related:
    - 'http://www.mcsweeneys.net/2004/2/19friedman.html'
raw_content:
    - 'McSweeney\''s Confessions of a New Coffee Drinker'
categories:
    - Aside
tags:
    - coffee
---

McSweeney’s Confessions of a New Coffee Drinker