---
id: 3177
title: 'January NY Tech Meetup'
date: '2006-01-02T21:34:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3177'
permalink: /2006/01/02/january-ny-tech-meetup/
typo_id:
    - '3175'
mt_id:
    - ''
link_related:
    - 'http://newtech.meetup.com/1/events/4811382/'
raw_content:
    - '7pm, at [Eyebeam](http://www.eyebeam.org/), see you there.'
categories:
    - Aside
tags:
    - eyebeam
    - meetup
    - nyc
    - tech
    - web
---

7pm, at \[Eyebeam\](http://www.eyebeam.org/), see you there.