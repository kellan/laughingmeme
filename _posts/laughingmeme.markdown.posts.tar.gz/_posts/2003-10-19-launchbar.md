---
id: 635
title: LaunchBar
date: '2003-10-19T22:48:44+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=635'
permalink: /2003/10/19/launchbar/
typo_id:
    - '633'
mt_id:
    - '1331'
link_related:
    - ''
raw_content:
    - "<p>\nLittle is as painful as finding out your friends are holding out on, so imagine my shock when I found out that everyone else was already using <a href=\\\"http://www.obdev.at/products/launchbar/\\\">LaunchBar</a>, and <b> hadn\\'t told me about it!</b>\n</p>\n<p>\n<a href=\\\"http://www.obdev.at/products/launchbar/\\\">LaunchBar</a> is amazing.  It is the perfect realization of Unix style tab completion, and the Bash interactive history search (C-r) as applied to a modern GUI.  The OS X of tab completion if you well.  At first I was a little unclear on how to start using it because there is so little to it, you expect configuration, or customization, or something.\n</p>\n<p>\nNo, you start <a href=\\\"http://www.obdev.at/products/launchbar/\\\">LaunchBar</a>, and it sits there waiting to be used, bring it to the forefront with Cmd-Space, and then start typing.  As you type the first few letters of whatever you\\'re looking for LaunchBar will quickly search through your Applications folder, documents, bookmarks (what people used to store links before blogs were invented), addressbook, and I\\'m sure other things, looking for matches.  Once you see the item you\\'re looking for, hit return to select it, launching it or opening it in the correct application as appropiate.  And it learns!  If you consistently choose Kung-Log when typing \\'K\\', then LaunchBar will stop prompting you to open \\'Kellan Elliott-McCrea\\' vCard.  Awesome.\n</p>"
---

Little is as painful as finding out your friends are holding out on, so imagine my shock when I found out that everyone else was already using [LaunchBar](http://www.obdev.at/products/launchbar/), and  **hadn’t told me about it!**

[LaunchBar](http://www.obdev.at/products/launchbar/) is amazing. It is the perfect realization of Unix style tab completion, and the Bash interactive history search (C-r) as applied to a modern GUI. The OS X of tab completion if you well. At first I was a little unclear on how to start using it because there is so little to it, you expect configuration, or customization, or something.

No, you start [LaunchBar](http://www.obdev.at/products/launchbar/), and it sits there waiting to be used, bring it to the forefront with Cmd-Space, and then start typing. As you type the first few letters of whatever you’re looking for LaunchBar will quickly search through your Applications folder, documents, bookmarks (what people used to store links before blogs were invented), addressbook, and I’m sure other things, looking for matches. Once you see the item you’re looking for, hit return to select it, launching it or opening it in the correct application as appropiate. And it learns! If you consistently choose Kung-Log when typing ‘K’, then LaunchBar will stop prompting you to open ‘Kellan Elliott-McCrea’ vCard. Awesome.