---
id: 2324
title: 'how to write better code (aka MVC is easy)'
date: '2004-06-12T01:21:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2324'
permalink: /2004/06/12/how-to-write-better-code-aka-mvc-is-easy/
typo_id:
    - '2322'
mt_id:
    - '2105'
link_related:
    - 'http://revjim.net/item/3956/'
raw_content:
    - 'a classic, but still excellent'
categories:
    - Aside
tags:
    - mvc
    - php
---

a classic, but still excellent