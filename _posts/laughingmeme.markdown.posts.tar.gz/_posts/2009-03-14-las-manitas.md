---
id: 4203
title: 'Las Manitas'
date: '2009-03-14T14:16:53+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4203'
permalink: /2009/03/14/las-manitas/
categories:
    - Uncategorized
tags:
    - austin
    - 'las manitas'
    - photos
    - place
    - sxsw
---

Las Manitas was one of my favorite things about Austin. I miss it. I took a photo of the [empty lot](http://www.flickr.com/photos/kellan/3353411827/) that used to be my favorite breakfast spot in the whole world.

The [Flickr nearby page](http://www.flickr.com/photos/kellan/3353411827/nearby?show=thumb&fromfilter=1&by=everyone&taken=alltime&sort=distance) is one of the best memorial to it I’ve seen.

[![Picture 31](http://farm4.static.flickr.com/3553/3353992101_2df316ce3a.jpg)](http://www.flickr.com/photos/kellan/3353411827/nearby?show=thumb&fromfilter=1&by=everyone&taken=alltime&sort=distance)