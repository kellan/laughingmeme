---
id: 5046
title: 'Austin plans, so far (SxSW 2012)'
date: '2012-03-05T19:59:55+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=5046'
permalink: /2012/03/05/austin-plans-so-far/
categories:
    - Uncategorized
---

[![Austin!](http://farm5.staticflickr.com/4026/4426160980_09f53caf2d.jpg)](http://www.flickr.com/photos/mroth/4426160980/ "Austin! by mroth, on Flickr")

I’m going to be at \[Kick\](http://dashes.com/kick/), Saturday morning, 9:30am

I’m going to be at \[Frank\](http://hotdogscoldbeer.com/), at 10am sharp Sunday morning as they don’t take brunch reservations

I’ll be at \[Made in NY\](http://madeinnyaustin.tumblr.com/), at the Cedar Room Sunday night, because Etsy’s presence at SxSW this year is low-key/unofficial like.

I’ll be at \[“New Aesthetic”\](http://austin2012.sched.org/event/2f15e62558314172fa7ea322a1a94d19) 9:30 Monday morning, because “Maps, Books, and Spimes” was one of my all time favorite SxSW talks, and this looks like it will be at least as much fun. And I want to see a drone.

I’ll be at \[World Changing 2.0\](http://austin2012.sched.org/event/09425d2f8ffcab9c6a10d92c4ab01fa1) at 12:30 on Tuesday because Cameron Sinclair’s “Open Architecture Challenge: Revisioning Decommisioned Military Facilities” was fucking awesome, and I’m looking forward to more.

I’ll be at Bruce Sterling 5pm Tuesday, because I once taught a class on global politics using the text of “Islands in the Net”, and it’s Bruce Sterling!

I’ll be **selling gold on black “Just Ship” shirts**, with any luck using a prototype Etsy mobile payment system. So if you’ve wanted a \[“Just Ship”\](http://www.etsy.com/transaction/58875129) shirt, this is your opportunity.

I might make a pilgrimage to Opal Divine’s as the thing I missed most bitterly at SxSW last year was the indie “Data Drinks”, and I strongly encourage people to organize and publicize “\[important technical topic here\] Drinks”, rather then trying to communicate then on a panel. (**e.g. y’all “Decentralized Web” and “SSO” folks ought to plan something, somewhere in the afternoon with “Mexican Martinis”**)

I’m hoping to have some success booking small to medium sized group meals, mixed results so far.

Beyond that I’ll be around hoping to meet great people.

What are your plans?