---
id: 2996
title: 'Upcoming.org: Unnamed Web 2.0 Meetup'
date: '2005-08-22T16:24:50+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2996'
permalink: /2005/08/22/upcomingorg-unnamed-web-20-meetup/
typo_id:
    - '2994'
mt_id:
    - '3062'
link_related:
    - 'http://upcoming.org/event/28835/'
raw_content:
    - 'At Tavern in the Square (Thursday, September 15, 2005)'
categories:
    - Aside
tags:
    - boston
    - cambridge
    - meetup
    - web2.0
---

At Tavern in the Square (Thursday, September 15, 2005)