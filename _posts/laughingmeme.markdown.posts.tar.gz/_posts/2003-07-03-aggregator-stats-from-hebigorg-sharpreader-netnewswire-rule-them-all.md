---
id: 1577
title: 'Aggregator stats from hebig.org: SharpReader, NetNewsWire rule them all'
date: '2003-07-03T11:46:44+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1577'
permalink: /2003/07/03/aggregator-stats-from-hebigorg-sharpreader-netnewswire-rule-them-all/
typo_id:
    - '1575'
mt_id:
    - '953'
link_related:
    - 'http://www.hebig.org/blogs/archives/main/001070.php'
raw_content:
    - '6 months of data, FoF is 1 month old, and its in 3rd place?  wow'
categories:
    - Aside
---

6 months of data, FoF is 1 month old, and its in 3rd place? wow