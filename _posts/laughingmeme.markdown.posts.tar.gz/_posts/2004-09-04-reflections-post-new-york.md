---
id: 902
title: 'Reflections, Post New York'
date: '2004-09-04T18:43:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=902'
permalink: /2004/09/04/reflections-post-new-york/
typo_id:
    - '900'
mt_id:
    - '2357'
link_related:
    - ''
raw_content:
    - "<p>\r\nEvan and Micah both have post NYC reflections.\r\n</p>\r\n<p>\r\n<a href=\\\"http://www.riseup.net/~micah/nerf/archives/000867.html\\\">Sustaining, Still Gaining</a> \r\n\r\n<blockquote>\r\nThe traffic analysis still has to be done, and it wont be accurate, but we had probably a week where we sustained between 9 and 20 megabits/second, thats a LOT of traffic, literally millions of hits per day (at one point we did some rough caluclations and came up with between 1 and 5 million a day). What was interesting was that even the fabled \\\"slashdot effect\\\" was hardly even a noticable bump in our traffic.\r\n</blockquote>\r\n\r\n<a href=\\\"http://www.anarchogeek.com/archives/000429.html\\\">Thoughts about the evolution of indymedia since 1999</a>\r\n<blockquote>\r\nThe Indymedia network has added a new local IMC every 11 days.\r\n</blockquote>\r\n\r\n<a href=\\\"http://www.anarchogeek.com/archives/000430.html\\\">The RNC Protests, Technology, and the infoline we setup</a>\r\n<blockquote>\r\nThere has been an escalating struggle between protesters and police over communications and coordination during protests involving mass direct action. Our task is to help facilitate horizontal communication and information distribution to all the activists in the streets.\r\n</blockquote>\r\n</p>"
tags:
    - imc
    - nyc
    - protest
    - rnc
---

Evan and Micah both have post NYC reflections.

[Sustaining, Still Gaining](http://www.riseup.net/~micah/nerf/archives/000867.html)

> The traffic analysis still has to be done, and it wont be accurate, but we had probably a week where we sustained between 9 and 20 megabits/second, thats a LOT of traffic, literally millions of hits per day (at one point we did some rough caluclations and came up with between 1 and 5 million a day). What was interesting was that even the fabled “slashdot effect” was hardly even a noticable bump in our traffic.

[Thoughts about the evolution of indymedia since 1999](http://www.anarchogeek.com/archives/000429.html)

> The Indymedia network has added a new local IMC every 11 days.

[The RNC Protests, Technology, and the infoline we setup](http://www.anarchogeek.com/archives/000430.html)

> There has been an escalating struggle between protesters and police over communications and coordination during protests involving mass direct action. Our task is to help facilitate horizontal communication and information distribution to all the activists in the streets.