---
id: 3253
title: 'guns don&#8217;t hurt people'
date: '2006-02-14T15:59:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3253'
permalink: /2006/02/14/guns-dont-hurt-people/
typo_id:
    - '3251'
mt_id:
    - ''
link_related:
    - 'http://www.spreadshirt.com/shop.php?sid=1030'
raw_content:
    - 'dick cheney hurts people'
categories:
    - Aside
tags:
    - cheney
    - guns
    - hunting
    - tshirt
    - wishlist
---

dick cheney hurts people