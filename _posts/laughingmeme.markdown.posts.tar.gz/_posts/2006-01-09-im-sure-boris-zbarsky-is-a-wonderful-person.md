---
id: 3182
title: 'I&#8217;m sure Boris Zbarsky is a wonderful person'
date: '2006-01-09T12:25:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3182'
permalink: /2006/01/09/im-sure-boris-zbarsky-is-a-wonderful-person/
typo_id:
    - '3180'
mt_id:
    - ''
link_related:
    - 'https://bugzilla.mozilla.org/show_bug.cgi?id=26179'
raw_content:
    - 'But could someone maybe distract him long enough (a night on the town?) to get the damn phantom text nodes in Firefox fixed?'
categories:
    - Aside
tags:
    - bug
    - dom
    - firefox
    - mozilla
    - opensource
---

But could someone maybe distract him long enough (a night on the town?) to get the damn phantom text nodes in Firefox fixed?