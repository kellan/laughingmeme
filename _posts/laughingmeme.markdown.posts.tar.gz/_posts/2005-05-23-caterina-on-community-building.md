---
id: 2940
title: 'Caterina  on Community Building'
date: '2005-05-23T13:14:48+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2940'
permalink: /2005/05/23/caterina-on-community-building/
typo_id:
    - '2938'
mt_id:
    - '2976'
link_related:
    - 'http://bizwerk.blogspot.com/2005/04/community-building.html'
raw_content:
    - 'Pynchon! Man, how can you read that stuff! DeLillo is 10X better'
categories:
    - Aside
tags:
    - collaboration
    - community
    - flickr
    - friendster
    - opensource
    - participation
    - voice
---

Pynchon! Man, how can you read that stuff! DeLillo is 10X better