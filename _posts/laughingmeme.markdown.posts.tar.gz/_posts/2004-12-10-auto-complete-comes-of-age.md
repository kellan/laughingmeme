---
id: 2707
title: 'Auto complete comes of age'
date: '2004-12-10T12:20:09+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2707'
permalink: /2004/12/10/auto-complete-comes-of-age/
typo_id:
    - '2705'
mt_id:
    - '2632'
link_related:
    - 'http://www.sitepoint.com/blog-post-view.php?id=216588'
raw_content:
    - 'Simon on the new Google auto-complete'
categories:
    - Aside
tags:
    - google
    - javascript
    - web2.0
---

Simon on the new Google auto-complete