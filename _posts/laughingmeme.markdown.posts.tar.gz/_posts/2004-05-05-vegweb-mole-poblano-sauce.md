---
id: 2256
title: 'VegWeb: Mole Poblano Sauce'
date: '2004-05-05T14:36:34+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2256'
permalink: /2004/05/05/vegweb-mole-poblano-sauce/
typo_id:
    - '2254'
mt_id:
    - '2011'
link_related:
    - 'http://vegweb.com/food/ethnic/5362.shtml'
raw_content:
    - 'Happy Cinco de Mayo!'
categories:
    - Aside
tags:
    - food
    - vegetarian
---

Happy Cinco de Mayo!