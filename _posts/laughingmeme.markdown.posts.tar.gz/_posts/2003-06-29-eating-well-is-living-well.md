---
id: 497
title: 'Eating Well is Living Well'
date: '2003-06-29T16:55:47+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=497'
permalink: /2003/06/29/eating-well-is-living-well/
typo_id:
    - '495'
mt_id:
    - '928'
link_related:
    - ''
raw_content:
    - "<p>\r\nThe only way to find really good produce in New England is to go down to the farm and pick it yourself.  Which is exactly what Jasmine and I did this weekend, spending the day at the beach, and washing up on the shores of a little, organic farm where a friend is apprenticing this Summer.  Its always interesting to get closer to the food production.  Three people, plus assorted enthusiasts, with 3 acres of land (about the size of a Home Deport parking lot) feed 50-60 people, feed them well, and do it in a sustainable manner.  And the food!  You make salads you don\\'t bother dressing, gently sauteed vegetable that you don\\'t mess up with seasoning (though we did toss \\\"garlic snaps\\\", the buds from the garlic plant which you snap off to encourage bulb growth, in with our red russian kale, for a sweet, garlicky, peppery dish that tasted like fine Tuscan cooking)\r\n</p>\r\n<p>\r\nSo if you grew up in an agricultural paradise like I did and felt like you had to give that up when you came East, or you simply have never experienced how good produce can be, you owe it to yourself to go to a farm, maybe join a CSA, and live better.  Supermarkets, Whole Food stores, and even most farmer\\'s markets are a poor substitute. \r\n</p>"
---

The only way to find really good produce in New England is to go down to the farm and pick it yourself. Which is exactly what Jasmine and I did this weekend, spending the day at the beach, and washing up on the shores of a little, organic farm where a friend is apprenticing this Summer. Its always interesting to get closer to the food production. Three people, plus assorted enthusiasts, with 3 acres of land (about the size of a Home Deport parking lot) feed 50-60 people, feed them well, and do it in a sustainable manner. And the food! You make salads you don’t bother dressing, gently sauteed vegetable that you don’t mess up with seasoning (though we did toss “garlic snaps”, the buds from the garlic plant which you snap off to encourage bulb growth, in with our red russian kale, for a sweet, garlicky, peppery dish that tasted like fine Tuscan cooking)

So if you grew up in an agricultural paradise like I did and felt like you had to give that up when you came East, or you simply have never experienced how good produce can be, you owe it to yourself to go to a farm, maybe join a CSA, and live better. Supermarkets, Whole Food stores, and even most farmer’s markets are a poor substitute.