---
id: 2865
title: 'Doug Cutting on configuring distributed Lucene for Technorati'
date: '2005-03-16T11:12:51+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2865'
permalink: /2005/03/16/doug-cutting-on-configuring-distributed-lucene-for-technorati/
typo_id:
    - '2863'
mt_id:
    - '2855'
link_related:
    - 'http://www.mail-archive.com/lucene-user@jakarta.apache.org/msg12709.html'
raw_content:
    - 'Why do I feel like shouting \''Bingo!\'''
categories:
    - Aside
tags:
    - distributed
    - java
    - lucene
    - search
    - technorati
---

Why do I feel like shouting ‘Bingo!’