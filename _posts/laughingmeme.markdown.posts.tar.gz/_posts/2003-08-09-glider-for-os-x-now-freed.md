---
id: 1645
title: 'Glider for OS X now freed!'
date: '2003-08-09T19:35:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1645'
permalink: /2003/08/09/glider-for-os-x-now-freed/
typo_id:
    - '1643'
mt_id:
    - '1068'
link_related:
    - 'http://homepage.mac.com/calhoun/'
raw_content:
    - 'One of the best games ever, now free after publisher folds'
categories:
    - Aside
---

One of the best games ever, now free after publisher folds