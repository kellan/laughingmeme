---
id: 1396
title: 'New Book:  Safe Food'
date: '2003-04-28T11:13:50+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1396'
permalink: /2003/04/28/new-book-safe-food/
typo_id:
    - '1394'
mt_id:
    - '679'
link_related:
    - 'http://www.nytimes.com/2003/04/23/dining/23WELL.html?ex=1051675200&en=5b98e47f5cb0309b&ei=5007&partner=USERLAND'
raw_content:
    - 'We\''re making slow progress'
categories:
    - Aside
---

We’re making slow progress