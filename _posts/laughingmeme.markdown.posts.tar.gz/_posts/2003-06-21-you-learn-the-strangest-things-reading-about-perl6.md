---
id: 1534
title: 'You learn the strangest things reading about Perl6'
date: '2003-06-21T17:52:19+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1534'
permalink: /2003/06/21/you-learn-the-strangest-things-reading-about-perl6/
typo_id:
    - '1532'
mt_id:
    - '890'
link_related:
    - 'http://www.sidhe.org/~dan/blog/archives/000207.html'
raw_content:
    - 'A crumb cake seascape and do it yourself decorating sugar'
categories:
    - Aside
---

A crumb cake seascape and do it yourself decorating sugar