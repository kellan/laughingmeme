---
id: 3584
title: 'Pipes: Webpage-to-RSS'
date: '2007-02-17T10:59:26+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/02/17/pipes-webpage-to-rss/'
permalink: /2007/02/17/pipes-webpage-to-rss/
link_related:
    - 'http://pipes.yahoo.com/pipes/NlNQKdO62xGAq1ZgZoQMOQ/'
categories:
    - Aside
    - Uncategorized
tags:
    - pipes
    - remix
    - syndication
---

Utilizes a data mining service Feedity to dynamically build the feeds for pages without. Yahoo couldn’t build this, but glad to see someone did.