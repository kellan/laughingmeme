---
id: 1751
title: 'Exploring Class::DBI, linking tables, and other issues'
date: '2003-09-29T18:46:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1751'
permalink: /2003/09/29/exploring-classdbi-linking-tables-and-other-issues/
typo_id:
    - '1749'
mt_id:
    - '1257'
link_related:
    - 'http://www.anarchogeek.com/archives/000233.html'
raw_content:
    - 'Hey!  He stole my \''needs a small book\'' line! :)'
categories:
    - Aside
---

Hey! He stole my ‘needs a small book’ line! ![:)](http://lm.local/wp-includes/images/smilies/simple-smile.png)