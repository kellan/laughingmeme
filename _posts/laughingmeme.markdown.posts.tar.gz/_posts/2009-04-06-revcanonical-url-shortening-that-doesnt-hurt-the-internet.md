---
id: 4219
title: 'rev=canonical: url shortening that doesn&#8217;t hurt the internet'
date: '2009-04-06T09:54:39+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4219'
permalink: /2009/04/06/revcanonical-url-shortening-that-doesnt-hurt-the-internet/
link_related:
    - 'http://revcanonical.appspot.com'
categories:
    - Aside
tags:
    - Code
    - 'cool uris don''t change'
    - gae
    - history
    - infrastructure
    - revcanonical
    - urls
    - web
---

A URL shortener that implements rev=”canonical”.