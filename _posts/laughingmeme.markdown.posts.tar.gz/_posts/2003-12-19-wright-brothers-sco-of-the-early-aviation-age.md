---
id: 1954
title: 'Wright Brothers &#8211; SCO of the early aviation age.'
date: '2003-12-19T14:05:35+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1954'
permalink: /2003/12/19/wright-brothers-sco-of-the-early-aviation-age/
typo_id:
    - '1952'
mt_id:
    - '1558'
link_related:
    - 'http://www.idlewords.com/weblog.12.2003.html#327'
raw_content:
    - 'Maciej does it again.'
categories:
    - Aside
---

Maciej does it again.