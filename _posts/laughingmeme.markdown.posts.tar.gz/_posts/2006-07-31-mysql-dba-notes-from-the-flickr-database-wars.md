---
id: 3417
title: 'MySQL DBA &#8211; notes from the flickr database wars'
date: '2006-07-31T19:48:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3417'
permalink: /2006/07/31/mysql-dba-notes-from-the-flickr-database-wars/
typo_id:
    - '3416'
mt_id:
    - ''
link_related:
    - 'http://mysqldba.blogspot.com/'
raw_content:
    - 'aka Dathan\''s blog'
categories:
    - Aside
tags:
    - flickr
    - mysql
---

aka Dathan’s blog