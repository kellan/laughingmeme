---
id: 3347
title: 'Rafe: Just hack'
date: '2006-05-03T16:45:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3347'
permalink: /2006/05/03/rafe-just-hack/
typo_id:
    - '3346'
mt_id:
    - ''
link_related:
    - 'http://rc3.org/2006/05/just_hack.php'
raw_content:
    - 'Truer words, and better advice never spoken.  But so damn hard to follow.'
categories:
    - Aside
tags:
    - architecture
    - productivity
    - programming
---

Truer words, and better advice never spoken. But so damn hard to follow.