---
id: 1768
title: 'Why does the Seattle Public Library website look like Amazon?'
date: '2003-10-05T15:50:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1768'
permalink: /2003/10/05/why-does-the-seattle-public-library-website-look-like-amazon/
typo_id:
    - '1766'
mt_id:
    - '1285'
link_related:
    - 'https://catalog.spl.org/ipac20/ipac.jsp?profile=dial&menu=search&aspect=basic_search&index=GW&term=21 dog years&x=0&y=0'
raw_content:
    - 'And why does the sign in front of Amazon\''s headquarters read \''Pacific Medical Center\''?'
categories:
    - Aside
---

And why does the sign in front of Amazon’s headquarters read ‘Pacific Medical Center’?