---
id: 835
title: 'Back at the Desk'
date: '2004-06-08T15:08:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=835'
permalink: /2004/06/08/back-at-the-desk/
typo_id:
    - '833'
mt_id:
    - '2089'
link_related:
    - ''
raw_content:
    - "Thanks to everyone who sent condolences.  It doesn\\'t currently look like insurance is going to cover any of it, but hope springs eternal.\r\n\r\nOther then a few rough spots it was a lovely week, kayaking around in the San Jauns was beautiful (I\\'ve got some pictures on my camera which wasn\\'t stolen, but will have to wait to be uploaded until I get a laptop to download then to), and Vancouver was interesting, much more urban, and diverse feeling then Seattle, and very lovely.  I have to say though just mentioning you\\'ve been robbed in Vancouver brings out a well of similar stories; the people behind us at the coffee shop had had their backpack stolen the night before, we\\'ve met a number of folks who\\'ve experience car breakins, etc..  \r\n\r\nI recommend Vancouver highly, but as an international traveller (rental car with foreign plates, or large backpack) I think I would recommend operating on developing nation travel rules, at least as regard to property.\r\n\r\nVoice mail is working again, but I still don\\'t have a new phone, email will reach me, but I\\'m digging out of a week backlog, and only at work.  If I haven\\'t replied yet, I will soon.\r\n\r\nFor the record we were parked in a busy part of Stanley Park, and we weren\\'t gone for long.  Also if you\\'re passport/birth certificate gets stolen, some sort of photo id, and your police filing number are recommended for getting back into the country."
categories:
    - Uncategorized
tags:
    - loss
    - personal
    - travel
    - vancouver
---

Thanks to everyone who sent condolences. It doesn’t currently look like insurance is going to cover any of it, but hope springs eternal.

Other then a few rough spots it was a lovely week, kayaking around in the San Jauns was beautiful (I’ve got some pictures on my camera which wasn’t stolen, but will have to wait to be uploaded until I get a laptop to download then to), and Vancouver was interesting, much more urban, and diverse feeling then Seattle, and very lovely. I have to say though just mentioning you’ve been robbed in Vancouver brings out a well of similar stories; the people behind us at the coffee shop had had their backpack stolen the night before, we’ve met a number of folks who’ve experience car breakins, etc..

I recommend Vancouver highly, but as an international traveller (rental car with foreign plates, or large backpack) I think I would recommend operating on developing nation travel rules, at least as regard to property.

Voice mail is working again, but I still don’t have a new phone, email will reach me, but I’m digging out of a week backlog, and only at work. If I haven’t replied yet, I will soon.

For the record we were parked in a busy part of Stanley Park, and we weren’t gone for long. Also if you’re passport/birth certificate gets stolen, some sort of photo id, and your police filing number are recommended for getting back into the country.