---
id: 2530
title: 'Deconstructing Candyland</a> (<a href="http://whump.com/moreLikeThis/">via'
date: '2004-09-14T14:09:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2530'
permalink: /2004/09/14/deconstructing-candyland-via/
typo_id:
    - '2528'
mt_id:
    - '2384'
link_related:
    - 'http://www.livejournal.com/users/yuki_onna/71310.html'
raw_content:
    - 'Weird, the Candyland I grew up with didn\''t have *any* of these people!  In fact I don\''t think there were any named characters at all.'
categories:
    - Aside
tags:
    - boardgames
    - childhood
    - deconstruction
    - gender
---

Weird, the Candyland I grew up with didn’t have *any* of these people! In fact I don’t think there were any named characters at all.