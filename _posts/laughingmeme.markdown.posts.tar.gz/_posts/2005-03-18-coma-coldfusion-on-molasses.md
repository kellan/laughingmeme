---
id: 2871
title: 'COMA: Coldfusion on Molasses'
date: '2005-03-18T23:27:58+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2871'
permalink: /2005/03/18/coma-coldfusion-on-molasses/
typo_id:
    - '2869'
mt_id:
    - '2863'
link_related:
    - 'http://a.wholelottanothing.org/2005/03/put_your_apps_i.html'
raw_content:
    - 'I wonder if I should put that on my resume?'
categories:
    - Aside
tags:
    - buzz
    - coldfusion
    - meme
    - rails
    - webdev
---

I wonder if I should put that on my resume?