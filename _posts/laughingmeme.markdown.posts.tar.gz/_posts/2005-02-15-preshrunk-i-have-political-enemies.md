---
id: 2822
title: 'Preshrunk: I Have Political Enemies'
date: '2005-02-15T16:43:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2822'
permalink: /2005/02/15/preshrunk-i-have-political-enemies/
typo_id:
    - '2820'
mt_id:
    - '2792'
link_related:
    - 'http://preshrunk.info/2005/02/i-have-political-enemies.php'
raw_content:
    - 'Now that is an awesome shirt.'
categories:
    - Aside
tags:
    - tshirt
---

Now that is an awesome shirt.