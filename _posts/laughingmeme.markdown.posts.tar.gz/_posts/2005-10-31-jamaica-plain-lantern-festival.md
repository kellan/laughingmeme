---
id: 3073
title: 'Jamaica Plain Lantern Festival'
date: '2005-10-31T08:58:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3073'
permalink: /2005/10/31/jamaica-plain-lantern-festival/
typo_id:
    - '3071'
mt_id:
    - ''
link_related:
    - ''
raw_content:
    - "Last night was the Jamaica Plain lantern festival, one of several pagan rituals which form the core of JP\\'s community identity.  We had a folks over for lantern making, followed by gorgeous stroll around the pond.\r\n<style>\r\n .jp-gallery { width: 240px; margin: 10 auto;}\r\n .jp-gallery img { border: 1px dotted #999; padding: 3px; margin: 3px; }\r\n .jp-gallery-caption { text-align: right; font-size: small; font-style: italic; }\r\n .jp-gallery-caption, .jp-gallery-caption a { color: #666; }\r\n</style>\r\n\r\n<div class=\\\"jp-gallery\\\">\r\n<div>\r\n<a href=\\\"http://flickr.com/photos/soulfish/57929685/\\\"><img src=\\\"http://static.flickr.com/28/57929685_b069ceb5f6_m.jpg\\\"></a>\r\n<div class=\\\"jp-gallery-caption\\\">\r\nby <a href=\\\"http://flickr.com/photos/soulfish/tags/lantern/\\\">soulfish</a>\r\n</div>\r\n</div>\r\n\r\n<div>\r\n<a href=\\\"http://flickr.com/photos/soulfish/57925178/\\\"><img src=\\\"http://static.flickr.com/33/57925178_4e1080950a_m.jpg\\\"></a>\r\n<div class=\\\"jp-gallery-caption\\\">\r\nby <a href=\\\"http://flickr.com/photos/soulfish/tags/lantern/\\\">soulfish</a>\r\n</div>\r\n</div>\r\n\r\n<div>\r\n<a href=\\\"http://flickr.com/photos/soulfish/57927824/\\\"><img src=\\\"http://static.flickr.com/31/57927824_45d6be6ba9_m.jpg\\\"></a>\r\n<div class=\\\"jp-gallery-caption\\\">\r\nby <a href=\\\"http://flickr.com/photos/soulfish/tags/lantern/\\\">soulfish</a>\r\n</div>\r\n</div>\r\n<div>and a couple from flickr</div>\r\n<div>\r\n<a href=\\\"http://flickr.com/photos/b-tal/57935921/\\\"><img src=\\\"http://static.flickr.com/24/57935921_36b7fa8d74_m.jpg\\\"></a>\r\n<div class=\\\"jp-gallery-caption\\\">\r\nby <a href=\\\"http://flickr.com/photos/b-tal/tags/lanternfestival/\\\">B Tal</a>\r\n</div>\r\n</div>\r\n\r\n<div>\r\n<a href=\\\"http://flickr.com/photos/abbyladybug/57790172/\\\"><img src=\\\"http://static.flickr.com/32/57790294_6f03b3863a_m.jpg\\\"></a>\r\n<div class=\\\"jp-gallery-caption\\\">\r\n<td style=\\\"text-align:left;\\\">\r\nby <a href=\\\"http://flickr.com/photos/abbyladybug/tags/lantern/\\\"> addyladybug </a>\r\n</div>\r\n</div>\r\n\r\n</div>"
tags:
    - festival
    - 'jamaica plain'
    - jp
    - party
    - personal
    - photos
    - st
---

Last night was the Jamaica Plain lantern festival, one of several pagan rituals which form the core of JP’s community identity. We had a folks over for lantern making, followed by gorgeous stroll around the pond. <style>
 .jp-gallery { width: 240px; margin: 10 auto;}
 .jp-gallery img { border: 1px dotted #999; padding: 3px; margin: 3px; }
 .jp-gallery-caption { text-align: right; font-size: small; font-style: italic; }
 .jp-gallery-caption, .jp-gallery-caption a { color: #666; }
</style>

<div class="jp-gallery"><div>[![](http://static.flickr.com/28/57929685_b069ceb5f6_m.jpg)](http://flickr.com/photos/soulfish/57929685/)<div class="jp-gallery-caption">by [soulfish](http://flickr.com/photos/soulfish/tags/lantern/)</div></div><div>[![](http://static.flickr.com/33/57925178_4e1080950a_m.jpg)](http://flickr.com/photos/soulfish/57925178/)<div class="jp-gallery-caption">by [soulfish](http://flickr.com/photos/soulfish/tags/lantern/)</div></div><div>[![](http://static.flickr.com/31/57927824_45d6be6ba9_m.jpg)](http://flickr.com/photos/soulfish/57927824/)<div class="jp-gallery-caption">by [soulfish](http://flickr.com/photos/soulfish/tags/lantern/)</div></div><div>[![](http://static.flickr.com/24/57935921_36b7fa8d74_m.jpg)](http://flickr.com/photos/b-tal/57935921/)<div class="jp-gallery-caption">by [B Tal](http://flickr.com/photos/b-tal/tags/lanternfestival/)</div></div><div>[![](http://static.flickr.com/32/57790294_6f03b3863a_m.jpg)](http://flickr.com/photos/abbyladybug/57790172/)<div class="jp-gallery-caption">| by [ addyladybug ](http://flickr.com/photos/abbyladybug/tags/lantern/) </div></div></div>