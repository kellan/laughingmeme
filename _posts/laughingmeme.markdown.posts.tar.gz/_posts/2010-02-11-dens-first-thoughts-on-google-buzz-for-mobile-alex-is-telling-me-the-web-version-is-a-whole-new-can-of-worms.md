---
id: 4490
title: 'Dens: First thoughts on Google Buzz for mobile (Alex is telling me the web version is a whole new can of worms)'
date: '2010-02-11T05:28:15+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4490'
permalink: /2010/02/11/dens-first-thoughts-on-google-buzz-for-mobile-alex-is-telling-me-the-web-version-is-a-whole-new-can-of-worms/
link_related:
    - 'http://www.flickr.com/photos/dpstyles/4346206432/'
categories:
    - Aside
tags:
    - dens
    - design
    - 'google buzz'
    - quotable
    - social
    - ux
---

“#3. Is Google Buzz the Facebook / Twitter / foursquare killer? No. Using Buzz requires more thought / more work than Facebook or Twitter and comes with less reward … For social apps the feature overlap is irrelevant – it’s about the motivation to use the product and the culture that drives participation.”