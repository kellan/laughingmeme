---
id: 1705
title: 'The Interactive Way To Go'
date: '2003-09-07T16:42:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1705'
permalink: /2003/09/07/the-interactive-way-to-go/
typo_id:
    - '1703'
mt_id:
    - '1172'
link_related:
    - 'http://www.whump.com/moreLikeThis/link/03632'
raw_content:
    - 'Go continues to escape me, despite my best intentions, and Jasmine\''s efforts to the contrary'
categories:
    - Aside
---

Go continues to escape me, despite my best intentions, and Jasmine’s efforts to the contrary