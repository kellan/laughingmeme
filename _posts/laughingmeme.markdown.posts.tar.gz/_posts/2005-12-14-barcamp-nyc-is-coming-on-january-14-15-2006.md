---
id: 3161
title: 'BarCamp NYC is coming on January 14-15, 2006'
date: '2005-12-14T10:17:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3161'
permalink: /2005/12/14/barcamp-nyc-is-coming-on-january-14-15-2006/
typo_id:
    - '3159'
mt_id:
    - ''
link_related:
    - 'http://amitgupta.com/blog/shoebox/2005/12/13/barcamp-nyc-is-coming-on-january-14-15-2006/'
raw_content:
    - 'Our first East Coast un-conference!'
categories:
    - Aside
tags:
    - barcamp
    - nyc
    - web
    - web2.0
---

Our first East Coast un-conference!