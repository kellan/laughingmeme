---
id: 2035
title: 'The rise of LAMP in the Public Sector'
date: '2004-01-27T00:16:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2035'
permalink: /2004/01/27/the-rise-of-lamp-in-the-public-sector/
typo_id:
    - '2033'
mt_id:
    - '1685'
link_related:
    - 'http://linuxjournal.com/article.php?sid=7131'
raw_content:
    - 'Always nice to playing for the winning side.'
categories:
    - Aside
---

Always nice to playing for the winning side.