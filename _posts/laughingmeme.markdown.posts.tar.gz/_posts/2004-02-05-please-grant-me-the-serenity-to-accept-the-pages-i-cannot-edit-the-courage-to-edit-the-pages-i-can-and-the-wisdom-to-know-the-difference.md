---
id: 2060
title: 'Please, grant me the serenity to accept the pages I cannot edit, the courage to edit the pages I can, and the wisdom to know the difference.'
date: '2004-02-05T00:12:49+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2060'
permalink: /2004/02/05/please-grant-me-the-serenity-to-accept-the-pages-i-cannot-edit-the-courage-to-edit-the-pages-i-can-and-the-wisdom-to-know-the-difference/
typo_id:
    - '2058'
mt_id:
    - '1723'
link_related:
    - 'http://en.wikipedia.org/wiki/Wikipediholic'
raw_content:
    - 'If there should be RecentChanges before I wake...'
categories:
    - Aside
---

If there should be RecentChanges before I wake…