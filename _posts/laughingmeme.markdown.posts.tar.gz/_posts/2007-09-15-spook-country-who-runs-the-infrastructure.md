---
id: 3707
title: 'Spook Country: Who Runs the Infrastructure?'
date: '2007-09-15T10:39:10+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/09/15/spook-country-who-runs-the-infrastructure/'
permalink: /2007/09/15/spook-country-who-runs-the-infrastructure/
categories:
    - Uncategorized
tags:
    - books
    - clouds
    - geo
    - gibson
---

![](http://g-ec2.images-amazon.com/images/I/41cUmZPl9aL._AA240_.jpg)

Am I the only person bothered while reading Spook Country with the question of who is running the servers?

Put on a VR helmet and you’re jacked into an imaginary world where artists have the sort of funding necessary to build out and run a shared platform for pushing richly textured 3D worlds over wifi.

And that server has some sort of totally smooth handshaking protocol for geolocating you, and streaming back the appropriate scene, and while everybody can publish to this unified virtual landscape, there is no hacking/jacking/spamming going on?

Or am I misreading the technology, and actually the landscapes are stored and served from hacked up WRT54Gs?