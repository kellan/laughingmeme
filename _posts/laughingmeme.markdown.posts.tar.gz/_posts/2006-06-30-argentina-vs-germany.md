---
id: 3390
title: 'Argentina vs. Germany'
date: '2006-06-30T01:21:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3390'
permalink: /2006/06/30/argentina-vs-germany/
typo_id:
    - '3389'
mt_id:
    - ''
link_related:
    - ''
raw_content:
    - 'Tomorrow morning, [Cafe International](http://www.yelp.com/biz/6iR0zBfiup79DErYKAXY0Q).  Sometime around 8am.  See you there?'
tags:
    - argentina
    - personal
    - sf
---

Tomorrow morning, \[Cafe International\](http://www.yelp.com/biz/6iR0zBfiup79DErYKAXY0Q). Sometime around 8am. See you there?