---
id: 2730
title: 'Congrats Aaron!'
date: '2004-12-28T14:35:10+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2730'
permalink: /2004/12/28/congrats-aaron/
typo_id:
    - '2728'
mt_id:
    - '2668'
link_related:
    - 'http://www.flickr.com/photos/caterina/2274839/in/set-57121/'
raw_content:
    - 'Aaron joins the Flickr team in Van.'
categories:
    - Aside
tags:
    - flickr
    - friends
    - photos
    - vancouver
---

Aaron joins the Flickr team in Van.