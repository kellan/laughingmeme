---
id: 2339
title: 'RSS-Feast &#8211; Simple RSS feed reader plugin for WordPress'
date: '2004-06-16T20:17:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2339'
permalink: /2004/06/16/rss-feast-simple-rss-feed-reader-plugin-for-wordpress/
typo_id:
    - '2337'
mt_id:
    - '2126'
link_related:
    - 'http://www.sakurakingdom.com/rss-feast/'
raw_content:
    - 'With MagpieRSS.'
categories:
    - Aside
tags:
    - magpie
    - rss
    - wordpress
---

With MagpieRSS.