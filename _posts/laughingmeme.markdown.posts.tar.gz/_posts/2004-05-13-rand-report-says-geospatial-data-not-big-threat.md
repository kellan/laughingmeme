---
id: 2274
title: 'RAND Report Says Geospatial Data Not Big Threat'
date: '2004-05-13T12:57:01+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2274'
permalink: /2004/05/13/rand-report-says-geospatial-data-not-big-threat/
typo_id:
    - '2272'
mt_id:
    - '2036'
link_related:
    - 'http://yro.slashdot.org/yro/04/05/13/023255.shtml?tid=126&tid=172&tid=95'
raw_content:
    - 'Does that mean I can carry my almanac again?'
categories:
    - Aside
tags:
    - gis
    - terrorism
---

Does that mean I can carry my almanac again?