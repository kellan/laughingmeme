---
id: 2953
title: 'Using MagpieRSS  and Feedburner &#8220;Feed Awareness API&#8221;'
date: '2005-06-17T20:34:24+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2953'
permalink: /2005/06/17/using-magpierss-and-feedburner-feed-awareness-api/
typo_id:
    - '2951'
mt_id:
    - '2999'
link_related:
    - 'http://vrypan.net/log/archives/2005/06/17/using-feedburner-awareness-api/'
raw_content:
    - ''
categories:
    - Aside
tags:
    - feedburner
    - magpie
    - php
    - rss
---

