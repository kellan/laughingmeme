---
id: 1604
title: 'Running an IRC Channel'
date: '2003-07-17T12:56:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1604'
permalink: /2003/07/17/running-an-irc-channel/
typo_id:
    - '1602'
mt_id:
    - '989'
link_related:
    - 'http://fishbowl.pastiche.org/archives/001387.html#001387'
raw_content:
    - 'the anarchist guide to'
categories:
    - Aside
---

the anarchist guide to