---
id: 2979
title: 'darkcloud: Do you remember when &#8220;to tag&#8221; meant something you might do with spray paint?'
date: '2005-08-12T16:44:58+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2979'
permalink: /2005/08/12/darkcloud-do-you-remember-when-to-tag-meant-something-you-might-do-with-spray-paint/
typo_id:
    - '2977'
mt_id:
    - '3043'
link_related:
    - 'http://interrupt.hampshire.edu/darkclouds/'
raw_content:
    - 'Interesting tag I\''ve seen around Boston.  Associated with my old alma mater'
categories:
    - Aside
tags:
    - art
    - boston
    - hampshire
    - tagging
---

Interesting tag I’ve seen around Boston. Associated with my old alma mater