---
id: 459
title: 'Laptop Died'
date: '2003-06-02T20:37:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=459'
permalink: /2003/06/02/laptop-died/
typo_id:
    - '457'
mt_id:
    - '822'
link_related:
    - ''
raw_content:
    - 'So my Vaio finally died.  It was starting to be flakey earlier last week, power turning off randomly, and now it simply won\''t turn on.  It was a refurbished, discontinued model when I bought it 3 years ago, and I can\''t see myself resucicating it.  Yet I am in shock.  It went yesterday, but I\''m just starting to believe it.  I\''ve spent a significant portion of my waking hours for the last 2 years with that machine, schelped it around with me everywhere I went.  I feel like somewhere between having lost a friend, and having my house burn down.  And staring at the bank account I\''m unclear how I\''m going to replace it this month which is probably the real root of my melodrama.  Still posting and development will be light for a while.'
---

So my Vaio finally died. It was starting to be flakey earlier last week, power turning off randomly, and now it simply won’t turn on. It was a refurbished, discontinued model when I bought it 3 years ago, and I can’t see myself resucicating it. Yet I am in shock. It went yesterday, but I’m just starting to believe it. I’ve spent a significant portion of my waking hours for the last 2 years with that machine, schelped it around with me everywhere I went. I feel like somewhere between having lost a friend, and having my house burn down. And staring at the bank account I’m unclear how I’m going to replace it this month which is probably the real root of my melodrama. Still posting and development will be light for a while.