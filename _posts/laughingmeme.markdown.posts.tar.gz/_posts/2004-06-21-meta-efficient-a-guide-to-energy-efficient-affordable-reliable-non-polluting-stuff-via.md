---
id: 2356
title: 'Meta-Efficient: A Guide To Energy Efficient, Affordable, Reliable, Non-polluting Stuff</a> (<a href="http://www.ambiguous.org/archive.php3/2004/06/21#quinn2004621.1">via'
date: '2004-06-21T14:19:46+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2356'
permalink: /2004/06/21/meta-efficient-a-guide-to-energy-efficient-affordable-reliable-non-polluting-stuff-via/
typo_id:
    - '2354'
mt_id:
    - '2146'
link_related:
    - 'http://www.reactual.com/'
raw_content:
    - 'Yay for informed consumerism!'
categories:
    - Aside
tags:
    - sustainable
---

Yay for informed consumerism!