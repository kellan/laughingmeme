---
id: 5117
title: 'A new (to me) spam type: the &#8220;let me write you a blog post&#8221;'
date: '2012-06-26T03:26:39+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=5117'
permalink: /2012/06/26/a-new-to-me-spam-type-the-let-me-write-you-a-blog-post/
categories:
    - Uncategorized
---

Something is going on here, but I’m not sure I can figure out what

> from: Sarah Thompson sarahjthompson5@gmail.com
> 
> An idea for a blog post: Science and Design Behind Music Production
> 
> Hi ,
> 
> I’m getting in touch with you because I’m interested in writing an article for your blog. I came across your blog post laughingmeme.org while writing for a website on music production. During my research, I’ve found an increasing focus in terms of design as the tools and technology available today improve our ability to customize how create music and collaborate as musicians
> 
> Please let me know if you’d be interested in an article this topic. Thanks, and I look forward to hearing from you soon.
> 
> Best,
> 
> Sarah

And then a bit earlier

> from: Brianna Meiers briannameiers8@gmail.com
> 
> An idea for a blog post: Aesthetics of Learning
> 
> Hi Kellan,
> 
> I found the information on your blog http://laughingmeme.org/ insightful as I was scouring the web for research on historical topics that are relevant to issues in higher education today. One of the biggest hurdles in completing an enriching and useful college degree (especially with different organizations such as online schools bombarding students with options) has been the lack of innovation in learning today. I believe that for students today to truly retain useful knowledge, it’s important to design curriculums keeping in mind aesthetics and learning theory.
> 
> I’d love to write a post for you that perhaps blends this topic with something deeper you are interested in for your blog. What do you think? Thanks, and I really look forward to hearing from you.
> 
> Best,
> 
> Brianna