---
id: 434
title: 'MagpieRSS 0.5:  Now with GZIP support'
date: '2003-05-12T19:21:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=434'
permalink: /2003/05/12/magpierss-05-now-with-gzip-support/
typo_id:
    - '432'
mt_id:
    - '742'
link_related:
    - ''
raw_content:
    - "<p>\r\n<a href=\\\"http://sourceforge.net/project/showfiles.php?group_id=55691&release_id=158897\\\">MagpieRSS 0.5</a> just hit Sourceforge.  This is not the promised 0.5 with its mythical new parser, this is a much more modest release that adds support for HTTP gzip encoding to get Magpie off <a href=\\\"http://www.syndic8.com/~wkearney/blogs/syndic8/\\\">Bill</a> and <a href=\\\"http://www.sauria.com/blog\\\">Ted</a>\\'s \r\n<a href=\\\"http://www.sauria.com/blog/2003/05/05#189\\\">bad aggregator list</a>.(flattering to make the short list really)\r\n</p>\r\n<p>\r\nAlso if you\\'re interested, a patch to <a href=\\\"http://snoopy.sf.net\\\">Snoopy</a> that gives it <a href=\\\"/snoopy_gzip.patch\\\">gzip encoding support</a>.\r\n</p>"
tags:
    - gzip
    - magpie
    - ted.leung
---

[MagpieRSS 0.5](http://sourceforge.net/project/showfiles.php?group_id=55691&release_id=158897) just hit Sourceforge. This is not the promised 0.5 with its mythical new parser, this is a much more modest release that adds support for HTTP gzip encoding to get Magpie off [Bill](http://www.syndic8.com/~wkearney/blogs/syndic8/) and [Ted](http://www.sauria.com/blog)‘s [bad aggregator list](http://www.sauria.com/blog/2003/05/05#189).(flattering to make the short list really)

Also if you’re interested, a patch to [Snoopy](http://snoopy.sf.net) that gives it [gzip encoding support](/snoopy_gzip.patch).