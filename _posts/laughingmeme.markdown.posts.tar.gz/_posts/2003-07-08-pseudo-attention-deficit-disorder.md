---
id: 1582
title: 'pseudo-attention deficit disorder'
date: '2003-07-08T13:39:10+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1582'
permalink: /2003/07/08/pseudo-attention-deficit-disorder/
typo_id:
    - '1580'
mt_id:
    - '959'
link_related:
    - 'http://www.sauria.com/blog/2003/07/07#332'
raw_content:
    - 'using always-on technology to induce neurological conditions :)'
categories:
    - Aside
---

using always-on technology to induce neurological conditions ![:)](http://lm.local/wp-includes/images/smilies/simple-smile.png)