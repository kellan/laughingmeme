---
id: 1307
title: 'Surveillance Nation&#8230;on Rt. 9'
date: '2003-03-19T10:58:17+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1307'
permalink: /2003/03/19/surveillance-nationon-rt-9/
typo_id:
    - '1305'
mt_id:
    - '535'
link_related:
    - 'http://techreview.com/articles/print_version/farmer0403.asp'
raw_content:
    - 'Yeh!  My old home town doing British style surveillance.  Now if they could just finish the fucking bridge...'
categories:
    - Aside
---

Yeh! My old home town doing British style surveillance. Now if they could just finish the fucking bridge…