---
id: 3187
title: 'Wish List: Ten Inventions, Some More Serious Than Others'
date: '2006-01-11T16:25:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3187'
permalink: /2006/01/11/wish-list-ten-inventions-some-more-serious-than-others/
typo_id:
    - '3185'
mt_id:
    - ''
link_related:
    - 'http://polaris.gseis.ucla.edu/pagre/wish-list.html'
raw_content:
    - 'Classic, excellent Phil Agre piece from 2001, including ideas on the intersection of user-submitted content, ubicomp, and the physical world.  Some day, some day.'
categories:
    - Aside
tags:
    - annotation
    - collaboration
    - data
    - geo
    - participation
    - travel
---

Classic, excellent Phil Agre piece from 2001, including ideas on the intersection of user-submitted content, ubicomp, and the physical world. Some day, some day.