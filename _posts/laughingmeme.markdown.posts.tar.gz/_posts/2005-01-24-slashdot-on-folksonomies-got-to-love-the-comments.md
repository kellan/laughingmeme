---
id: 2784
title: 'Slashdot on &#8220;folksonomies&#8221;.  Got to love the comments.'
date: '2005-01-24T13:07:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2784'
permalink: /2005/01/24/slashdot-on-folksonomies-got-to-love-the-comments/
typo_id:
    - '2782'
mt_id:
    - '2743'
link_related:
    - 'http://slashdot.org/article.pl?sid=05/01/04/0117245'
raw_content:
    - '\''Now I know what the [non-techie] in my life feels like when they read slashdot\'''
categories:
    - Aside
tags:
    - antifolksonomy
    - folksonomy
    - quotable
    - slashdot
---

‘Now I know what the \[non-techie\] in my life feels like when they read slashdot’