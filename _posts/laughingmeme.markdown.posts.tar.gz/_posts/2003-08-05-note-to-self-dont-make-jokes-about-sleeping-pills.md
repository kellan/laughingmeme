---
id: 1636
title: 'Note to self:  don&#8217;t make jokes about sleeping pills'
date: '2003-08-05T00:54:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1636'
permalink: /2003/08/05/note-to-self-dont-make-jokes-about-sleeping-pills/
typo_id:
    - '1634'
mt_id:
    - '1052'
link_related:
    - 'http://www.contraversion.com/index.php?p=blogarchive/2003_08_01_archive.php#105977212643758015'
raw_content:
    - 'But caffeine abuse is just fine, and should fit right in.'
categories:
    - Aside
---

But caffeine abuse is just fine, and should fit right in.