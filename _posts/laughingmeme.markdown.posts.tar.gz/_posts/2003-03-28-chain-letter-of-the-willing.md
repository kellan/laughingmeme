---
id: 1333
title: 'chain letter of the willing'
date: '2003-03-28T19:39:05+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1333'
permalink: /2003/03/28/chain-letter-of-the-willing/
typo_id:
    - '1331'
mt_id:
    - '582'
link_related:
    - 'http://www.whump.com/moreLikeThis/link/03400'
raw_content:
    - 'France failed to sign this letter and its sole contribution to Western Civilization was renamed \''Freedom Fries\'''
categories:
    - Aside
---

France failed to sign this letter and its sole contribution to Western Civilization was renamed ‘Freedom Fries’