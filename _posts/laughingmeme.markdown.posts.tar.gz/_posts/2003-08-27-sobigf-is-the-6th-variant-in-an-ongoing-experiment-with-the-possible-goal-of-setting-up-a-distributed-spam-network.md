---
id: 1686
title: 'SoBig.F is the 6th variant in an ongoing experiment with the possible goal of setting up a distributed spam network?'
date: '2003-08-27T02:02:28+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1686'
permalink: /2003/08/27/sobigf-is-the-6th-variant-in-an-ongoing-experiment-with-the-possible-goal-of-setting-up-a-distributed-spam-network/
typo_id:
    - '1684'
mt_id:
    - '1145'
link_related:
    - 'http://slashdot.org/articles/03/08/26/1638207.shtml?tid=111&tid=126&tid=172'
raw_content:
    - 'It will never be safe to send an email about movies again :('
categories:
    - Aside
---

It will never be safe to send an email about movies again ![:(](http://lm.local/wp-includes/images/smilies/frownie.png)