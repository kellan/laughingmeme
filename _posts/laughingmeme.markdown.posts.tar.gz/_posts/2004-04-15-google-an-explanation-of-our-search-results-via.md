---
id: 2209
title: 'Google: An explanation of our search results</a> (<a href="http://www.whump.com">via'
date: '2004-04-15T04:26:25+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2209'
permalink: /2004/04/15/google-an-explanation-of-our-search-results-via/
typo_id:
    - '2207'
mt_id:
    - '1947'
link_related:
    - 'http://www.google.com/explanation.html'
raw_content:
    - 'In response to the Jew Watch controversy.'
categories:
    - Aside
tags:
    - google
---

In response to the Jew Watch controversy.