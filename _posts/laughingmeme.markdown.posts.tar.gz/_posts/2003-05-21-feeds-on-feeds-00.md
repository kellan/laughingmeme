---
id: 1462
title: 'Feeds on Feeds 0.0'
date: '2003-05-21T14:20:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1462'
permalink: /2003/05/21/feeds-on-feeds-00/
typo_id:
    - '1460'
mt_id:
    - '779'
link_related:
    - 'http://minutillo.com/steve/weblog/?p=338'
raw_content:
    - 'A new PHP/MySQL RSS aggregator'
categories:
    - Aside
tags:
    - fof
    - magpie
    - php
    - rss
---

A new PHP/MySQL RSS aggregator