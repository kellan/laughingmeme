---
id: 2306
title: 'Aidan saw Aral and Cordelia at BayCon (Bujold at Baycon)'
date: '2004-05-30T21:03:23+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2306'
permalink: /2004/05/30/aidan-saw-aral-and-cordelia-at-baycon-bujold-at-baycon/
typo_id:
    - '2304'
mt_id:
    - '2081'
link_related:
    - 'http://www.livejournal.com/users/sedesdraconis/20624.html'
raw_content:
    - 'Before doing his David Bowie impression'
categories:
    - Aside
tags:
    - author/bujold/louis
    - sf
---

Before doing his David Bowie impression