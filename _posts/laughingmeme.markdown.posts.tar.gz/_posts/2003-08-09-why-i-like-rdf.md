---
id: 1642
title: 'Why I like RDF'
date: '2003-08-09T14:07:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1642'
permalink: /2003/08/09/why-i-like-rdf/
typo_id:
    - '1640'
mt_id:
    - '1064'
link_related:
    - 'http://usefulinc.com/edd/blog/2003/8/8#13:13'
raw_content:
    - 'by Edd Dumbill'
categories:
    - Aside
---

by Edd Dumbill