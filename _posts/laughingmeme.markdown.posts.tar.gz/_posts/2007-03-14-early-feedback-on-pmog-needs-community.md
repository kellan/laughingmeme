---
id: 3597
title: 'Early feedback on PMOG &#8211; Needs Community'
date: '2007-03-14T19:27:42+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/03/14/early-feedback-on-pmog-needs-community/'
permalink: /2007/03/14/early-feedback-on-pmog-needs-community/
categories:
    - Uncategorized
tags:
    - community
    - design
    - game
    - pmog
    - social
    - web2.0
---

[![](http://laughingmeme.org/img/pmog.jpg)](http://bud.com/members/Kellan)

Okay \[PMOG\](http://bud.com/) is **super** early in its life, but it intrigues me on a couple of levels (not the least of which is the \[engaging archetype art\](http://bud.com/images/promo/poster-lg.jpg)).

However there are some things about it which are broken. Not surprising in and of itself, but in the process of trying to report said broken-ness I ran into a larger problem.

No community space.

There is a Google Group but it’s a moderated announce only kind of thing (HINT: thats what you’re blog is for!) not a public discussion space. No message boards, no wiki (though presumably we could start one, \[Twitter Fan\](http://twitter.pbwiki.com/) style), no groups.

Someone needs to see \[Andy’s\](http://waxy.org) talk about group forming, social software, and out of band spaces.

Especially for a game, a social game, an experimental game.

**Uninstalled for now**, in an attempt to reduce unexplainable spinnies.