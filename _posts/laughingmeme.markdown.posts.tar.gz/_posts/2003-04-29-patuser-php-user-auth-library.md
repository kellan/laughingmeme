---
id: 1406
title: 'patUser: PHP user auth library'
date: '2003-04-29T21:53:35+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1406'
permalink: /2003/04/29/patuser-php-user-auth-library/
typo_id:
    - '1404'
mt_id:
    - '693'
link_related:
    - 'http://www.devshed.com/Server_Side/PHP/patUser/patUser1/print_html'
raw_content:
    - 'paradigm looks a little odd, but could definitely be useful'
categories:
    - Aside
---

paradigm looks a little odd, but could definitely be useful