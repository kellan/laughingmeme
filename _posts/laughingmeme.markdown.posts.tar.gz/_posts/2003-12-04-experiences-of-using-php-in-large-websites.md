---
id: 1918
title: 'Experiences of Using PHP in Large Websites'
date: '2003-12-04T17:59:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1918'
permalink: /2003/12/04/experiences-of-using-php-in-large-websites/
typo_id:
    - '1916'
mt_id:
    - '1510'
link_related:
    - 'http://www.ukuug.org/events/linux2002/papers/html/php/index.html'
raw_content:
    - 'Problematic for multi-developer sites, or sites that respond to changing needs.  Excellent.'
categories:
    - Aside
---

Problematic for multi-developer sites, or sites that respond to changing needs. Excellent.