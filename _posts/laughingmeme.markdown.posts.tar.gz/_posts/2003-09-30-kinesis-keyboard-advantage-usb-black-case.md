---
id: 1757
title: 'Kinesis  keyboard, Advantage USB, Black case'
date: '2003-09-30T21:10:37+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1757'
permalink: /2003/09/30/kinesis-keyboard-advantage-usb-black-case/
typo_id:
    - '1755'
mt_id:
    - '1266'
link_related:
    - 'http://www.kinesis-ergo.com/Merchant2/merchant.mv?Screen=PROD&Store_Code=KS&Product_Code=KB500USB-blk'
raw_content:
    - 'Wrist hurt.  Want ergo keyboard.  Ooooo, sexy, black, small, keyboard.'
categories:
    - Aside
---

Wrist hurt. Want ergo keyboard. Ooooo, sexy, black, small, keyboard.