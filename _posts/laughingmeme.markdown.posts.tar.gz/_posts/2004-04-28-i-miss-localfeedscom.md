---
id: 2233
title: 'I miss Localfeeds.com'
date: '2004-04-28T20:03:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2233'
permalink: /2004/04/28/i-miss-localfeedscom/
typo_id:
    - '2231'
mt_id:
    - '1981'
link_related:
    - 'http://localfeeds.com/'
raw_content:
    - 'Was a great resource for when you\''re new in town.'
categories:
    - Aside
tags:
    - blogs
---

Was a great resource for when you’re new in town.