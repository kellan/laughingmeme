---
id: 3128
title: 'Harvard Book Store&#8217;s Holiday Hundred is out. (20% one hundred selected titles)'
date: '2005-11-30T16:01:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3128'
permalink: /2005/11/30/harvard-book-stores-holiday-hundred-is-out-20-one-hundred-selected-titles/
typo_id:
    - '3126'
mt_id:
    - ''
link_related:
    - 'http://www.harvard.com/onourshelves/selectseventy.html'
raw_content:
    - 'Also [NYTimes 100 notable of 2005](http://www.nytimes.com/2005/12/04/books/review/notable-books2005.html?ei=5090&en=6ae392627118dab6&ex=1291352400&adxnnl=1&partner=rssuserland&emc=rss&pagewanted=all&adxnnlx=1133384816-L6BPmMLbe3gqUEXYsfPWeQ).  Now if people would offer these lists as [XOXO](http://microformats.org/wiki/xoxo), then you could build one-click add to [Lists of Bests](http://www.listsofbests.com/) or some such.'
categories:
    - Aside
tags:
    - books
    - holidays
    - microformats
---

Also \[NYTimes 100 notable of 2005\](http://www.nytimes.com/2005/12/04/books/review/notable-books2005.html?ei=5090&amp;en=6ae392627118dab6&amp;ex=1291352400&amp;adxnnl=1&amp;partner=rssuserland&amp;emc=rss&amp;pagewanted=all&amp;adxnnlx=1133384816-L6BPmMLbe3gqUEXYsfPWeQ). Now if people would offer these lists as \[XOXO\](http://microformats.org/wiki/xoxo), then you could build one-click add to \[Lists of Bests\](http://www.listsofbests.com/) or some such.