---
id: 3534
title: 'bdv: fire at one broadway'
date: '2006-12-09T13:24:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3534'
permalink: /2006/12/09/bdv-fire-at-one-broadway/
typo_id:
    - '3533'
mt_id:
    - ''
link_related:
    - 'http://hybernaut.com/fire-at-one-broadway'
raw_content:
    - 'Glad to hear you and Seth made it out safe.'
categories:
    - Aside
tags:
    - boston
    - fire
---

Glad to hear you and Seth made it out safe.