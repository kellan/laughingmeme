---
id: 2639
title: 'Upcoming.org: Science Lecture: Richard Dawkins at Town Hall (Wednesday, November 17, 2004)'
date: '2004-11-15T14:45:54+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2639'
permalink: /2004/11/15/upcomingorg-science-lecture-richard-dawkins-at-town-hall-wednesday-november-17-2004/
typo_id:
    - '2637'
mt_id:
    - '2544'
link_related:
    - 'http://upcoming.org/event/10262/'
raw_content:
    - 'He is a crank, but an interesting one, I\''ll probably go'
categories:
    - Aside
tags:
    - bio
    - dawkins
    - emergence
    - evolution
    - seattle
---

He is a crank, but an interesting one, I’ll probably go