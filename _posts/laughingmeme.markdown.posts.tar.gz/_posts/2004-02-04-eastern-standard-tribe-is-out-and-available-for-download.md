---
id: 2056
title: 'Eastern Standard Tribe is out! (and available for download)'
date: '2004-02-04T02:03:43+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2056'
permalink: /2004/02/04/eastern-standard-tribe-is-out-and-available-for-download/
typo_id:
    - '2054'
mt_id:
    - '1718'
link_related:
    - 'http://craphound.com/est/'
raw_content:
    - 'I have this fantasy about switching to EST, but right now I\''m operating more at GMT-10h'
categories:
    - Aside
---

I have this fantasy about switching to EST, but right now I’m operating more at GMT-10h