---
id: 1071
title: 'Boston Ruby Tonight at Tosci&#8217;s'
date: '2005-04-14T06:38:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1071'
permalink: /2005/04/14/boston-ruby-tonight-at-toscis/
typo_id:
    - '1069'
mt_id:
    - '2934'
link_related:
    - ''
raw_content:
    - "You\\'re still welcome to come even if you haven\\'t RSVP\\'ed yet.  Here is a note I sent out to the [Boston Ruby meetup](http://ruby.meetup.com/58/) list\r\n\r\n> Hi all,\r\n>  \r\n> So we\\'re on for meeting up this Thursday at [Toscanini\\'s in\r\n> Central Sq. at 7pm.][1]  I\\'ve received several out of band RSVPs\r\n> so currently I\\'m expecting 4-5 people (but it may be just me\r\n> and irb.rb for company).\r\n> \r\n> No firm agenda as yet for our inaugural meeting, except to get\r\n> a sense of community, interest level, and available resources.\r\n> I imagine as we get a sense of interest we\\'ll be able to plan a\r\n> bit more, maybe arrange for talks, etc.  Folks are encouraged\r\n> to bring questions, news, and show and tell.\r\n> \r\n> Oh, and I\\'ll be the guy with blond curly hair, and the [PickAxe]\r\n> [2] book out on the table.\r\n> \r\n> See you Thursday,\r\n> -kellan\r\n\r\n\r\n[1]: http://tinyurl.com/4gptl\r\n[2]: http://pragmaticprogrammer.com/titles/ruby/"
tags:
    - boston
    - ruby
---

You’re still welcome to come even if you haven’t RSVP’ed yet. Here is a note I sent out to the \[Boston Ruby meetup\](http://ruby.meetup.com/58/) list

> Hi all, So we’re on for meeting up this Thursday at \[Toscanini’s in Central Sq. at 7pm.\]\[1\] I’ve received several out of band RSVPs so currently I’m expecting 4-5 people (but it may be just me and irb.rb for company).
> 
> No firm agenda as yet for our inaugural meeting, except to get a sense of community, interest level, and available resources. I imagine as we get a sense of interest we’ll be able to plan a bit more, maybe arrange for talks, etc. Folks are encouraged to bring questions, news, and show and tell.
> 
> Oh, and I’ll be the guy with blond curly hair, and the \[PickAxe\] \[2\] book out on the table.
> 
> See you Thursday, -kellan