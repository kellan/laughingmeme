---
id: 1299
title: 'Recurrence tutorial'
date: '2003-03-12T18:19:05+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1299'
permalink: /2003/03/12/recurrence-tutorial/
typo_id:
    - '1297'
mt_id:
    - '523'
link_related:
    - 'http://tipi.sourceforge.net/doc/recur/'
raw_content:
    - 'On parsing Ical recurrences with Perl.  A work in progress'
categories:
    - Aside
---

On parsing Ical recurrences with Perl. A work in progress