---
id: 3430
title: 'Rails 1.1.6, backports, and full disclosure'
date: '2006-08-10T13:44:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3430'
permalink: /2006/08/10/rails-116-backports-and-full-disclosure/
typo_id:
    - '3429'
mt_id:
    - ''
link_related:
    - 'http://weblog.rubyonrails.com/2006/8/10/rails-1-1-6-backports-and-full-disclosure'
raw_content:
    - Ugh.
categories:
    - Aside
tags:
    - rails
---

Ugh.