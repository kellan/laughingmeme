---
id: 1855
title: 'Is it like not being able to dream in colour, or something?'
date: '2003-11-14T04:16:23+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1855'
permalink: /2003/11/14/is-it-like-not-being-able-to-dream-in-colour-or-something/
typo_id:
    - '1853'
mt_id:
    - '1424'
link_related:
    - 'http://aaronland.info/weblog/2003/11/13/5302/'
raw_content:
    - 'One of these days we\''re going to revoke Aaron\''s geek license on grounds of sedition.'
categories:
    - Aside
---

One of these days we’re going to revoke Aaron’s geek license on grounds of sedition.