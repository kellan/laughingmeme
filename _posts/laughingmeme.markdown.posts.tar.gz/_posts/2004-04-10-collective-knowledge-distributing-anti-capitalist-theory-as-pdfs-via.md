---
id: 2199
title: 'Collective Knowledge &#8211; distributing anti-capitalist theory as PDFs</a> (<a href="http://anarchogeek.com">via'
date: '2004-04-10T18:52:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2199'
permalink: /2004/04/10/collective-knowledge-distributing-anti-capitalist-theory-as-pdfs-via/
typo_id:
    - '2197'
mt_id:
    - '1935'
link_related:
    - 'http://redlibertad.crosswinds.net/collectiveknowledge/index.html'
raw_content:
    - 'We\''ll even forgive them their gratuitous not to mention silly use of javascript and iframe'
categories:
    - Aside
---

We’ll even forgive them their gratuitous not to mention silly use of javascript and iframe