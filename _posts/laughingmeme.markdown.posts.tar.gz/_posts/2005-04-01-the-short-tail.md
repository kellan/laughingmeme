---
id: 2896
title: 'the short tail'
date: '2005-04-01T17:30:47+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2896'
permalink: /2005/04/01/the-short-tail/
typo_id:
    - '2894'
mt_id:
    - '2902'
link_related:
    - 'http://www.gapingvoid.com/Moveable_Type/archives/001484.html'
raw_content:
    - 'the pile of bodies'
categories:
    - Aside
tags:
    - bubble
    - buzz
    - comic
    - web2.0
---

the pile of bodies