---
id: 3601
title: 'Book Pairings'
date: '2007-03-21T22:34:25+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/03/21/book-pairings/'
permalink: /2007/03/21/book-pairings/
categories:
    - Uncategorized
tags:
    - books
    - food
    - history
    - 'mike davis'
    - reading
---

Some books are just better read together (or serially if you don’t do the book rotation thing.) \[Ecology of Fear\](http://www.amazon.com/Ecology-Fear-Angeles-Imagination-Disaster/dp/0375706070) and \[Decoding Gender in Science Fiction\](http://www.amazon.com/Decoding-Gender-Science-Fiction-Attebery/dp/041593950X/ref=cm*lmf*tit\_6/103-6236904-0024607) is a favorite of mine, two totally different projects that happen to feature the same authors.

Picked up another Mike Davis at the \[Anarchist Bookfair\](http://sfbookfair.wordpress.com/) this weekend, the \[Late Victorian Holocaust\](http://www.amazon.com/Late-Victorian-Holocausts-Famines-Making/dp/1859843824/ref=pd*bbs*sr*1/103-6236904-0024607?ie=UTF8&amp;s=books&amp;qid=1174545143&amp;sr=1-1) (for $3!!!), and while its still early, I’m finding it to be an interesting foil to \[Omnivore’s Dilemma\](http://www.amazon.com/Omnivores-Dilemma-Natural-History-Meals/dp/1594200823/ref=pd*bbs*sr*1/103-6236904-0024607?ie=UTF8&amp;s=books&amp;qid=1174545182&amp;sr=1-1), focusing as they do on the beginning and the nadir of the global industrial food system.

Wondering if its something in particular about Mike Davis?

Do you have favorite pairings?