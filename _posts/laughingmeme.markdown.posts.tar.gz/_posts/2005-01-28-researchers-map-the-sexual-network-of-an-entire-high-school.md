---
id: 2789
title: 'Researchers Map The Sexual Network Of An Entire High School'
date: '2005-01-28T16:17:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2789'
permalink: /2005/01/28/researchers-map-the-sexual-network-of-an-entire-high-school/
typo_id:
    - '2787'
mt_id:
    - '2749'
link_related:
    - 'http://researchnews.osu.edu/archive/chainspix.htm'
raw_content:
    - 'Incredibly (as in I don\''t believe it) heteronormative.  Pretty pictures though.'
categories:
    - Aside
tags:
    - gender
    - ia
    - sex
    - visualization
---

Incredibly (as in I don’t believe it) heteronormative. Pretty pictures though.