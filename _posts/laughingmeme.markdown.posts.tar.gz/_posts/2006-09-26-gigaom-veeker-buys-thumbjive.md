---
id: 3481
title: 'GigaOM: Veeker Buys ThumbJive'
date: '2006-09-26T19:37:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3481'
permalink: /2006/09/26/gigaom-veeker-buys-thumbjive/
typo_id:
    - '3480'
mt_id:
    - ''
link_related:
    - 'http://mobile.gigaom.com/2006/09/25/veeker-thumbjive/'
raw_content:
    - 'Congrats [Joseph](http://joseph.elliott.name/) and Daniel!  See also [decentral.tv](http://decentral.tv/)'
categories:
    - Aside
    - mobile
tags:
    - family
    - startup
---

Congrats \[Joseph\](http://joseph.elliott.name/) and Daniel! See also \[decentral.tv\](http://decentral.tv/)