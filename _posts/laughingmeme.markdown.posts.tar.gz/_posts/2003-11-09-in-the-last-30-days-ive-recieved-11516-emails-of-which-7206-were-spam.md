---
id: 1838
title: 'In the last 30 days I&#8217;ve recieved 11,516 emails of which 7,206 were spam.'
date: '2003-11-09T21:28:41+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1838'
permalink: /2003/11/09/in-the-last-30-days-ive-recieved-11516-emails-of-which-7206-were-spam/
typo_id:
    - '1836'
mt_id:
    - '1402'
link_related:
    - 'http://annys.eines.info/cgi-bin/man/man2html?mailstat'
raw_content:
    - 'Man page of mailstat'
categories:
    - Aside
---

Man page of mailstat