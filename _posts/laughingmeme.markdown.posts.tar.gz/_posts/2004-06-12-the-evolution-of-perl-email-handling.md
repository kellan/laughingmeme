---
id: 2325
title: 'The Evolution of Perl Email Handling'
date: '2004-06-12T15:37:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2325'
permalink: /2004/06/12/the-evolution-of-perl-email-handling/
typo_id:
    - '2323'
mt_id:
    - '2106'
link_related:
    - 'http://www.perl.com/lpt/a/2004/06/10/email.html'
raw_content:
    - 'Not content to rest on its laurels, Perl continues to dominate the \''Language with the Best Libraries\'' category.'
categories:
    - Aside
tags:
    - email
    - perl
---

Not content to rest on its laurels, Perl continues to dominate the ‘Language with the Best Libraries’ category.