---
id: 1364
title: 'RSS via NNTP? Koolaid &#038; Counter-Koolaid'
date: '2003-04-18T12:08:12+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1364'
permalink: /2003/04/18/rss-via-nntp-koolaid-counter-koolaid/
typo_id:
    - '1362'
mt_id:
    - '633'
link_related:
    - 'http://www.advogato.org/article/651.html'
raw_content:
    - 'I found the con args interesting as people keep suggesting IMC move to using NNTP'
categories:
    - Aside
---

I found the con args interesting as people keep suggesting IMC move to using NNTP