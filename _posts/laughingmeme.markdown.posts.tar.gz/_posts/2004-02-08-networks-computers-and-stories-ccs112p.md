---
id: 2070
title: 'Networks, Computers, and Stories (CCS112p)'
date: '2004-02-08T14:53:27+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2070'
permalink: /2004/02/08/networks-computers-and-stories-ccs112p/
typo_id:
    - '2068'
mt_id:
    - '1736'
link_related:
    - 'http://alum.hampshire.edu/~mnbF94/CCS112p.html'
raw_content:
    - 'The class I learned HTML & CGI in.  Unearthed for a comment to Dancing Sausage.  I\''m shocked that this is still online.'
categories:
    - Aside
---

The class I learned HTML &amp; CGI in. Unearthed for a comment to Dancing Sausage. I’m shocked that this is still online.