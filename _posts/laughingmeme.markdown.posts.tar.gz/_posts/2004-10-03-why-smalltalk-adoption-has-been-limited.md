---
id: 2572
title: 'Why SmallTalk adoption has been limited'
date: '2004-10-03T00:24:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2572'
permalink: /2004/10/03/why-smalltalk-adoption-has-been-limited/
typo_id:
    - '2570'
mt_id:
    - '2445'
link_related:
    - 'http://www.approximity.com/cgi-bin/blogtariAgile/index.rb/Smalltalk/onSTL.rdoc'
raw_content:
    - 'Smalltalk can only be used by humans with a psi power greater than 17, with adjustments.'
categories:
    - Aside
tags:
    - funny
    - programming
---

Smalltalk can only be used by humans with a psi power greater than 17, with adjustments.