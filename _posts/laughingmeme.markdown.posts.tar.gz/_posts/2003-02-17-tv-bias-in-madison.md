---
id: 1223
title: 'TV bias in Madison'
date: '2003-02-17T17:03:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1223'
permalink: /2003/02/17/tv-bias-in-madison/
typo_id:
    - '1221'
mt_id:
    - '407'
link_related:
    - 'http://www.yarinareth.net/caveatlector/archive/week_2003_02_16.html#e001318'
raw_content:
    - 'I\''m NOT looking for this stuff, just clearing out my RSS aggregator inbox'
categories:
    - Aside
---

I’m NOT looking for this stuff, just clearing out my RSS aggregator inbox