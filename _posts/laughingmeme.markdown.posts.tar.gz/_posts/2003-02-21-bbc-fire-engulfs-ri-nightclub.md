---
id: 1237
title: 'BBC: &#8220;Fire engulfs RI nightclub&#8221;'
date: '2003-02-21T03:49:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1237'
permalink: /2003/02/21/bbc-fire-engulfs-ri-nightclub/
typo_id:
    - '1235'
mt_id:
    - '430'
link_related:
    - 'http://news.bbc.co.uk/1/hi/world/americas/2786331.stm'
raw_content:
    - 'I find it exceedingly strange I get my local news from the BBC'
categories:
    - Aside
tags:
    - bbc
    - providence
---

I find it exceedingly strange I get my local news from the BBC