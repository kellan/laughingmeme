---
id: 2361
title: 'Some advertisers are more equal than others.'
date: '2004-06-23T02:30:53+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2361'
permalink: /2004/06/23/some-advertisers-are-more-equal-than-others/
typo_id:
    - '2359'
mt_id:
    - '2152'
link_related:
    - 'http://www.perrspectives.com/articles/art_gagorder01.htm'
raw_content:
    - 'On Google\''s broken, sizeist ad policies.'
categories:
    - Aside
tags:
    - google
    - politics
---

On Google’s broken, sizeist ad policies.