---
id: 2890
title: '&#8220;Going to the good video store&#8221;'
date: '2005-03-30T11:52:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2890'
permalink: /2005/03/30/going-to-the-good-video-store/
typo_id:
    - '2888'
mt_id:
    - '2893'
link_related:
    - 'http://weblog.rubyonrails.com/archives/2005/03/30/going-to-the-good-video-store/'
raw_content:
    - 'Hey! There Josh goes slandering my luvly Riot::Core'
categories:
    - Aside
tags:
    - funny
    - perl
    - protest.net
    - quotable
    - rails
    - ruby
---

Hey! There Josh goes slandering my luvly Riot::Core