---
id: 1320
title: '&#8220;made the mistake today of looking at the newspaper&#8221;'
date: '2003-03-25T23:25:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1320'
permalink: /2003/03/25/made-the-mistake-today-of-looking-at-the-newspaper/
typo_id:
    - '1318'
mt_id:
    - '561'
link_related:
    - 'http://sedesdraconis.com/index.cgi?Features/News'
raw_content:
    - 'gets harder each day to want to know what is going on'
categories:
    - Aside
---

gets harder each day to want to know what is going on