---
id: 3706
title: 'Facebook Application Smashing'
date: '2007-09-12T12:24:07+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/09/12/facebook-application-smashing/'
permalink: /2007/09/12/facebook-application-smashing/
link_related:
    - 'http://defacebooked.blogspot.com/'
categories:
    - Aside
    - Uncategorized
tags:
    - blog
    - facebook
    - security
---

Blog chronicling the new field of exploiting 3rd party FB apps security vulnerabilities. (via \[aaron\](http://aaronland.info))