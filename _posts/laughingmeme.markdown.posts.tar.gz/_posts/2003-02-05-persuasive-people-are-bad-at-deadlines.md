---
id: 1200
title: 'Persuasive people are bad at deadlines'
date: '2003-02-05T20:25:37+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1200'
permalink: /2003/02/05/persuasive-people-are-bad-at-deadlines/
typo_id:
    - '1198'
mt_id:
    - '370'
link_related:
    - 'http://www.nickdenton.org/archives/003638.html'
raw_content:
    - 'this explains so many of my recent problems.  i need to work on being more persuasive.'
categories:
    - Aside
---

this explains so many of my recent problems. i need to work on being more persuasive.