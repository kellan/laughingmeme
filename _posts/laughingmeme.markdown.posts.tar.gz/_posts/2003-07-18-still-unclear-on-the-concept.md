---
id: 518
title: 'Still Unclear on the Concept'
date: '2003-07-18T14:20:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=518'
permalink: /2003/07/18/still-unclear-on-the-concept/
typo_id:
    - '516'
mt_id:
    - '995'
link_related:
    - ''
raw_content:
    - "<p>\r\nThe ownership of Userland\\'s RSS 2.0 has been <a href=\\\"http://blogs.law.harvard.edu/tech/announceRss2\\\">transfered to Dave\\'s new employer the Berkman Center</a>.  An advisory board of 3 people has been announced, Jon Udell, <a href=\\\"http://inessential.com/?comments=1&postid=2581\\\">Brent Simmons</a>, and of course Dave Winer.\r\n</p>\r\n<p>\r\nLooks more like 3 card monte then meaningful progress.\r\n</p>"
tags:
    - berkman
    - rss
    - rss2.0
    - winer
---

The ownership of Userland’s RSS 2.0 has been [transfered to Dave’s new employer the Berkman Center](http://blogs.law.harvard.edu/tech/announceRss2). An advisory board of 3 people has been announced, Jon Udell, [Brent Simmons](http://inessential.com/?comments=1&postid=2581), and of course Dave Winer.

Looks more like 3 card monte then meaningful progress.