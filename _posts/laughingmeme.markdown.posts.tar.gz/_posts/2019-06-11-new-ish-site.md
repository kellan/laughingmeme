---
id: 5395
title: 'New-ish site'
date: '2019-06-11T06:06:24+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=5395'
permalink: /2019/06/11/new-ish-site/
categories:
    - Uncategorized
---

Someone asked me the other day if I was going to keep writing as I hadn’t updated this site or Medium for a bit. This site isn’t totally deprecated but I do have a new site where I’ve been doing a bit more regular writing on engineering leadership topics, \[kellanem.com\](https://kellanem.com/) and in particular \[Notes on engineering leadership\](https://kellanem.com/notes/) if that’s your thing.