---
id: 2194
title: 'Black voodoo Python generator magic'
date: '2004-04-06T13:58:40+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2194'
permalink: /2004/04/06/black-voodoo-python-generator-magic/
typo_id:
    - '2192'
mt_id:
    - '1928'
link_related:
    - 'http://dealmeida.net/blosxom/en/Programming/Python/black_voodoo_magic.html'
raw_content:
    - 'Python has officially graduated from its simple, and easy to understand roots.'
categories:
    - Aside
tags:
    - programming
    - python
---

Python has officially graduated from its simple, and easy to understand roots.