---
id: 2438
title: 'New version of reBlog available'
date: '2004-08-04T13:27:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2438'
permalink: /2004/08/04/new-version-of-reblog-available/
typo_id:
    - '2436'
mt_id:
    - '2257'
link_related:
    - 'http://www.reblog.org/'
raw_content:
    - 'new version of FoF based republishing tool adds output to RSS'
categories:
    - Aside
tags:
    - fof
    - magpie
    - rss
---

new version of FoF based republishing tool adds output to RSS