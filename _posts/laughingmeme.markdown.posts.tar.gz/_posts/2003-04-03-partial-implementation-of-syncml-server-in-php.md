---
id: 1346
title: 'Partial implementation of SyncML server in PHP'
date: '2003-04-03T15:15:40+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1346'
permalink: /2003/04/03/partial-implementation-of-syncml-server-in-php/
typo_id:
    - '1344'
mt_id:
    - '600'
link_related:
    - 'http://rdfig.xmlhack.com/2003/04/02/2003-04-02.html'
raw_content:
    - 'hey, that was on my todo list!'
categories:
    - Aside
---

hey, that was on my todo list!