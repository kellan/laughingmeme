---
id: 3483
title: 'jargon watch: dog whistle politics'
date: '2006-09-28T12:31:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3483'
permalink: /2006/09/28/jargon-watch-dog-whistle-politics/
typo_id:
    - '3482'
mt_id:
    - ''
link_related:
    - 'http://agonist.org/ian_welsh/20060925/just_a_comma_dog_whistle_politics'
raw_content:
    - 'Why bother with Lakoffian framing when you\''ve got a secret language?'
categories:
    - Aside
tags:
    - language
    - politics
---

Why bother with Lakoffian framing when you’ve got a secret language?