---
id: 2376
title: 'PHP5 Exception Use Guidelines'
date: '2004-07-09T15:43:27+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2376'
permalink: /2004/07/09/php5-exception-use-guidelines/
typo_id:
    - '2374'
mt_id:
    - '2177'
link_related:
    - 'http://wiki.ciaweb.net/yawiki/?area=PEAR_Dev&page=RfcExceptionUse'
raw_content:
    - 'to read'
categories:
    - Aside
tags:
    - php
    - php5
---

to read