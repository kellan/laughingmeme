---
id: 467
title: 'Oral Surgery'
date: '2003-06-12T16:03:10+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=467'
permalink: /2003/06/12/oral-surgery/
typo_id:
    - '465'
mt_id:
    - '849'
link_related:
    - ''
raw_content:
    - "<p>\r\nThe worst part of getting 5 teeth removed (4 wisdom teeth + 1 other random tooth that my dentist wasn\\'t sure why it was there), is being off hot liquids for 48 hours. \r\n</p>\r\n<p>\r\nI\\'ve got a perscription for Vicodin but I don\\'t think it was for caffeine headaches.\r\n</p>\r\n<p>\r\nAnd a final tip, if you can dig up some rust brown pillow cases, and a water proof pillow you\\'ll save yourself a lot of scrubbing.\r\n</p>"
---

The worst part of getting 5 teeth removed (4 wisdom teeth + 1 other random tooth that my dentist wasn’t sure why it was there), is being off hot liquids for 48 hours.

I’ve got a perscription for Vicodin but I don’t think it was for caffeine headaches.

And a final tip, if you can dig up some rust brown pillow cases, and a water proof pillow you’ll save yourself a lot of scrubbing.