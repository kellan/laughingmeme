---
id: 2020
title: 'Defending web applications against dictionary attacks'
date: '2004-01-21T21:26:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2020'
permalink: /2004/01/21/defending-web-applications-against-dictionary-attacks/
typo_id:
    - '2018'
mt_id:
    - '1664'
link_related:
    - 'http://simon.incutio.com/archive/2004/01/22/defendingWebApplications'
raw_content:
    - 'Simon is just starting to explore the options.'
categories:
    - Aside
---

Simon is just starting to explore the options.