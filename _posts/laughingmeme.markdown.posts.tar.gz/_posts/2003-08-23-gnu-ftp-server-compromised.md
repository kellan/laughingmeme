---
id: 1674
title: 'GNU FTP server compromised'
date: '2003-08-23T17:22:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1674'
permalink: /2003/08/23/gnu-ftp-server-compromised/
typo_id:
    - '1672'
mt_id:
    - '1127'
link_related:
    - 'http://ftp.gnu.org/MISSING-FILES.README'
raw_content:
    - 'In other news, don\''t use FTP.'
categories:
    - Aside
---

In other news, don’t use FTP.