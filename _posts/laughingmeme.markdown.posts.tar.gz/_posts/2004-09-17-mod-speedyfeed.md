---
id: 2536
title: 'mod speedyfeed'
date: '2004-09-17T12:28:44+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2536'
permalink: /2004/09/17/mod-speedyfeed/
typo_id:
    - '2534'
mt_id:
    - '2392'
link_related:
    - 'http://www.intertwingly.net/blog/2004/09/17/mod-speedyfeed'
raw_content:
    - 'Interesting, tracking this for inclusion in Magpie.'
categories:
    - Aside
tags:
    - atom
    - http
    - magpie
    - rss
---

Interesting, tracking this for inclusion in Magpie.