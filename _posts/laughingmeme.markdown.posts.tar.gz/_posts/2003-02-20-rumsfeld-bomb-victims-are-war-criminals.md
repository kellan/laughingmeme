---
id: 327
title: 'Rumsfeld:  Bomb Victims are War Criminals'
date: '2003-02-20T06:57:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=327'
permalink: /2003/02/20/rumsfeld-bomb-victims-are-war-criminals/
typo_id:
    - '325'
mt_id:
    - '422'
link_related:
    - ''
raw_content:
    - "<p> \r\nBBC has a  <a\r\nhref=\\\"http://news.bbc.co.uk/1/hi/world/middle_east/2782955.stm\\\">fascinating\r\narticle about a US warning against \\\"human shields\\\"</a>.  It seems Rumsfeld\r\nacknowledges that its a war crime to bomb civilians, and is very\r\nupset that those horrible civilians would get in the way of his nice, well mannered bombs.\r\n</p> \r\n<p> Hint:  don\\'t bomb civilians targets. </p>"
---

 BBC has a [fascinating article about a US warning against “human shields”](http://news.bbc.co.uk/1/hi/world/middle_east/2782955.stm). It seems Rumsfeld acknowledges that its a war crime to bomb civilians, and is very upset that those horrible civilians would get in the way of his nice, well mannered bombs.

 Hint: don’t bomb civilians targets.