---
id: 3760
title: 'Flickr: The Commons'
date: '2008-01-16T12:01:35+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2008/01/16/flickr-the-commons/'
permalink: /2008/01/16/flickr-the-commons/
categories:
    - Uncategorized
tags:
    - 'collective wisdom'
    - commons
    - flickr
    - 'library of congress'
    - loc
    - photos
---

[![Woman aircraft worker, Vega Aircraft Corporation, Burbank, Calif. Shown checking electrical assemblies (LOC)](http://farm3.static.flickr.com/2293/2179930812_1c734d4726.jpg)](http://www.flickr.com/photos/library_of_congress/2179930812/ "Woman aircraft worker, Vega Aircraft Corporation, Burbank, Calif. Shown checking electrical assemblies (LOC) by The Library of Congress, on Flickr")

\[George\](http://abitofgeorge.com/) \[just announced\](http://blog.flickr.com/en/2008/01/16/many-hands-make-light-work/) about the coolest thing ever: \[the Commons\](http://flickr.com/commons). The \[Library of Congress\](http://www.loc.gov/blog/?p=233) has started sharing a fraction of their photo archive on Flickr under a special \[“no known restrictions”\](http://www.loc.gov/rr/print/195\_copr.html#noknown) license.

You can tag, comment on, fave, and share these historical photos just like any other photo on Flickr.

And the collective wisdom will hopefully bubble up some great photos and metadata.