---
id: 2552
title: '&#8216;The Take&#8217; gets relatively sympathetic treatment from NYTimes'
date: '2004-09-23T19:27:16+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2552'
permalink: /2004/09/23/the-take-gets-relatively-sympathetic-treatment-from-nytimes/
typo_id:
    - '2550'
mt_id:
    - '2417'
link_related:
    - 'http://www.nytimes.com/2004/09/22/movies/22take.html?ex=1253678400&#38;en=78c6b36e6e8fd456&#38;ei=5090&#38;partner=rssuserland'
raw_content:
    - 'Congrats to Naomi and Avi.  Any word on a distributor I wonder?'
categories:
    - Aside
tags:
    - activism
    - argentina
    - capitalism
    - documentary
    - movies
    - naomiklein
---

Congrats to Naomi and Avi. Any word on a distributor I wonder?