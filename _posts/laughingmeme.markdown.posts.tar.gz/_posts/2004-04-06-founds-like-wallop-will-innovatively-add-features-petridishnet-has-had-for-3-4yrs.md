---
id: 2193
title: 'Founds like Wallop will innovatively add features Petridish.net has had for 3-4yrs'
date: '2004-04-06T13:30:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2193'
permalink: /2004/04/06/founds-like-wallop-will-innovatively-add-features-petridishnet-has-had-for-3-4yrs/
typo_id:
    - '2191'
mt_id:
    - '1927'
link_related:
    - 'http://www.hyperorg.com/backissues/joho-mar26-04.html#friendster'
raw_content:
    - 'Fwiw, Friendster was not the first ASN'
categories:
    - Aside
---

Fwiw, Friendster was not the first ASN