---
id: 2859
title: 'Oooh, someone got a grant to write Ruby Lucene bindings.'
date: '2005-03-11T17:56:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2859'
permalink: /2005/03/11/oooh-someone-got-a-grant-to-write-ruby-lucene-bindings/
typo_id:
    - '2857'
mt_id:
    - '2844'
link_related:
    - 'http://groups-beta.google.com/group/comp.lang.ruby/browse_thread/thread/35c2f61d29e94550/28b32a50948920ba#28b32a50948920ba'
raw_content:
    - 'Via Swig and GCJ.  Too bad the CLucene library doesn\''t have more momentum.'
categories:
    - Aside
tags:
    - fulltext
    - java
    - lucene
    - ruby
    - search
---

Via Swig and GCJ. Too bad the CLucene library doesn’t have more momentum.