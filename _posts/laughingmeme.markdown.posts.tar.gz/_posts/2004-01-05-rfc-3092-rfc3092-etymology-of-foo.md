---
id: 1982
title: 'RFC 3092 (rfc3092) &#8211; Etymology of &#8220;Foo&#8221;'
date: '2004-01-05T12:09:46+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1982'
permalink: /2004/01/05/rfc-3092-rfc3092-etymology-of-foo/
typo_id:
    - '1980'
mt_id:
    - '1607'
link_related:
    - 'http://www.faqs.org/rfcs/rfc3092.html'
raw_content:
    - 'most famous of the metasyntactic variables'
categories:
    - Aside
---

most famous of the metasyntactic variables