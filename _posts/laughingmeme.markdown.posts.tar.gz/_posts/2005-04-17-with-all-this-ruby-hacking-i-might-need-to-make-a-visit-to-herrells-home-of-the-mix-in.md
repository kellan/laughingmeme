---
id: 2919
title: 'With all this Ruby hacking, I might need to make a visit to Herrell&#8217;s, home of the &#8220;Mix In&#8221;'
date: '2005-04-17T13:54:49+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2919'
permalink: /2005/04/17/with-all-this-ruby-hacking-i-might-need-to-make-a-visit-to-herrells-home-of-the-mix-in/
typo_id:
    - '2917'
mt_id:
    - '2944'
link_related:
    - 'http://c2.com/cgi/wiki?MixIn'
raw_content:
    - 'Of course JP licks is a lot closer, choices choices.'
categories:
    - Aside
tags:
    - boston
    - history
    - ice.cream
    - lisp
    - lore
    - programming
    - ruby
---

Of course JP licks is a lot closer, choices choices.