---
id: 2215
title: 'second-system syndrome <em>n.</em> &#8211; the ballooning complexity that occurs when designing the successor to a relatively small, elegant, and successful system.'
date: '2004-04-16T23:28:12+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2215'
permalink: /2004/04/16/second-system-syndrome-n-the-ballooning-complexity-that-occurs-when-designing-the-successor-to-a-relatively-small-elegant-and-successful-system/
typo_id:
    - '2213'
mt_id:
    - '1955'
link_related:
    - 'http://info.astrian.net/jargon/terms/s/second-system_effect.html'
raw_content:
    - 'Don\''t know about the elegant part, but the rest of if explains Protest.net V2 (codename Riot) perfectly.'
categories:
    - Aside
---

Don’t know about the elegant part, but the rest of if explains Protest.net V2 (codename Riot) perfectly.