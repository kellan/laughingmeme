---
id: 1358
title: Motivation
date: '2003-04-09T22:42:49+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1358'
permalink: /2003/04/09/motivation/
typo_id:
    - '1356'
mt_id:
    - '620'
link_related:
    - 'http://www.despair.com/motivation.html'
raw_content:
    - 'Best demotivator in years.  Was looking for \''Consulting\''.'
categories:
    - Aside
---

Best demotivator in years. Was looking for ‘Consulting’.