---
id: 1250
title: 'Gibson on Terrorism'
date: '2003-02-24T14:51:35+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1250'
permalink: /2003/02/24/gibson-on-terrorism/
typo_id:
    - '1248'
mt_id:
    - '449'
link_related:
    - 'http://ftrain.com/gibson_on_terrorism.html'
raw_content:
    - 'Paul tosses in tormet'
categories:
    - Aside
---

Paul tosses in tormet