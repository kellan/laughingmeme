---
id: 4334
title: 'A literary appreciation of the Olson/Zoneinfo/tz database'
date: '2009-10-25T15:28:08+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4334'
permalink: /2009/10/25/a-literary-appreciation-of-the-olsonzoneinfotz-database/
link_related:
    - 'http://blog.jonudell.net/2009/10/23/a-literary-appreciation-of-the-olsonzoneinfotz-database/'
categories:
    - Aside
tags:
    - calendaring
    - olson
    - timezone
    - udell
---

I’m a card carrying member of the Olson fan club, but it’s still great reading see Jon’s love note. <acronym title="Arthur David Olson">ADO</acronym> has a posse. (actually I only have 5 posts tagged \[olson\](http://laughingmeme.org/tag/olson/), while I have 7 posts tagged \[udell\](http://laughingmeme.org/tag/udell/) )