---
id: 1423
title: 'Why is a raven like a writing desk?'
date: '2003-05-07T19:16:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1423'
permalink: /2003/05/07/why-is-a-raven-like-a-writing-desk/
typo_id:
    - '1421'
mt_id:
    - '716'
link_related:
    - 'http://www.straightdope.com/classics/a5_266.html'
raw_content:
    - 'Cecil Adams attempts to answer (via seth)'
categories:
    - Aside
---

Cecil Adams attempts to answer (via seth)