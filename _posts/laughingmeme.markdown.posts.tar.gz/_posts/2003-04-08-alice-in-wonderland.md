---
id: 392
title: 'Alice in Wonderland'
date: '2003-04-08T08:42:18+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=392'
permalink: /2003/04/08/alice-in-wonderland/
typo_id:
    - '390'
mt_id:
    - '612'
link_related:
    - ''
raw_content:
    - "<p>\r\nVia <a href=\\\"http://boingboing.net/2003_04_01_archive.html#200109198\\\">BoingBoing</a>, \r\n<a href=\\\"http://allconsuming.net/item.cgi?isbn=155583745X\\\">Queens in the Kingdom</a> is a gay and lesbian guide to Disneyland and Walt Disney World.    I love what they have to say about my favorite of the Disney classics, Alice in Wonderland\r\n<blockquote>\r\n<p>\r\nFor our money the best of the dark rides, Alice takes guests through a Technicolor, kaleidoscopic Wonderland. But can we just point out that that girl Alice is a circuit queen fag hag? Look at the company she keeps: Tweedle Dee and Tweedle Dum? The Mad Hatter and the March Hare? A fastidious rabbit and a massive queen? Come on. And let\\'s not forget about the \\\"magic cookies\\\" and pieces of mushroom she ingests. Give that girl a glow stick and send her twirling.\r\n</p>\r\n<p>\r\nFairy Fact: Alice\\'s voice belongs to Kathryn Beaumont, who recorded the role first for the film in 1951, then for the ride in 1958, and again for the ride\\'s renovation in 1984. P.S. She\\'s also Wendy in Peter Pan. \r\n</p>\r\n</blockquote>\r\nI\\'m not sure which ride they\\'re discussing, maybe at Disney World?  At Disney Land the only nod I remember to Alice is the Tea Cups, the dark rides are Mister Toad, and Peter Pan.  But you\\'ve got to love their analysis.\r\n</p>\r\n<p>\r\nHmmmm, the longer I sit here straining to remember an Alice in Wonderland ride, the more I become convinced of remembering a giant Chesire Cat with whirling eyes, but I\\'m not sure that constitutes proof.\r\n</p>"
---

Via [BoingBoing](http://boingboing.net/2003_04_01_archive.html#200109198), [Queens in the Kingdom](http://allconsuming.net/item.cgi?isbn=155583745X) is a gay and lesbian guide to Disneyland and Walt Disney World. I love what they have to say about my favorite of the Disney classics, Alice in Wonderland

> For our money the best of the dark rides, Alice takes guests through a Technicolor, kaleidoscopic Wonderland. But can we just point out that that girl Alice is a circuit queen fag hag? Look at the company she keeps: Tweedle Dee and Tweedle Dum? The Mad Hatter and the March Hare? A fastidious rabbit and a massive queen? Come on. And let’s not forget about the “magic cookies” and pieces of mushroom she ingests. Give that girl a glow stick and send her twirling.
> 
> Fairy Fact: Alice’s voice belongs to Kathryn Beaumont, who recorded the role first for the film in 1951, then for the ride in 1958, and again for the ride’s renovation in 1984. P.S. She’s also Wendy in Peter Pan.

I’m not sure which ride they’re discussing, maybe at Disney World? At Disney Land the only nod I remember to Alice is the Tea Cups, the dark rides are Mister Toad, and Peter Pan. But you’ve got to love their analysis. Hmmmm, the longer I sit here straining to remember an Alice in Wonderland ride, the more I become convinced of remembering a giant Chesire Cat with whirling eyes, but I’m not sure that constitutes proof.