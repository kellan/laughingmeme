---
id: 1665
title: 'generating fractal images in PHP'
date: '2003-08-20T11:05:53+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1665'
permalink: /2003/08/20/generating-fractal-images-in-php/
typo_id:
    - '1663'
mt_id:
    - '1114'
link_related:
    - 'http://www.phppatterns.com/index.php/article/articleview/72/1/11/'
raw_content:
    - 'alas, the apocalypse is upon us!'
categories:
    - Aside
---

alas, the apocalypse is upon us!