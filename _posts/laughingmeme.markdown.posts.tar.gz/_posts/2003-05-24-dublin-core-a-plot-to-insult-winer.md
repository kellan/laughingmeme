---
id: 1472
title: 'Dublin Core a plot to insult Winer?'
date: '2003-05-24T09:30:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1472'
permalink: /2003/05/24/dublin-core-a-plot-to-insult-winer/
typo_id:
    - '1470'
mt_id:
    - '792'
link_related:
    - 'http://groups.yahoo.com/group/rss-dev/message/5578'
raw_content:
    - 'Largest, oldest web metadata standard actually a plot by those dastardly MT \''guys\'''
categories:
    - Aside
---

Largest, oldest web metadata standard actually a plot by those dastardly MT ‘guys’