---
id: 384
title: 'Matt&#8217;s Script Archive?'
date: '2003-04-01T05:04:22+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=384'
permalink: /2003/04/01/matts-script-archive/
typo_id:
    - '382'
mt_id:
    - '587'
link_related:
    - ''
raw_content:
    - "<p>\r\nOn my god, <a href=\\\"http://cpan.org\\\">what did they do to CPAN</a>?\r\n</p>\nAs much as I don\\'t like April 1st, that is relatively clever."
---

On my god, [what did they do to CPAN](http://cpan.org)?

As much as I don’t like April 1st, that is relatively clever.