---
id: 4502
title: 'OAuth Echo &#8211; delegation in identity verification &#8211; mehack'
date: '2010-02-11T10:35:11+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4502'
permalink: /2010/02/11/oauth-echo-delegation-in-identity-verification-mehack/
link_related:
    - 'http://mehack.com/oauth-echo-delegation-in-identity-verificatio'
categories:
    - Aside
tags:
    - delegation
    - oauth
    - twitter
---

Glad to see Raffi getting this stuff out. These “vouched for” experiences are going to be the next key pieces towards enabling decentralization and service re-composition.