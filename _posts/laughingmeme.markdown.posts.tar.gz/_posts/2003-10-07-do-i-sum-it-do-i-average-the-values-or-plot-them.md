---
id: 1776
title: 'Do I sum it, do I average the values, or plot them?'
date: '2003-10-07T11:46:25+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1776'
permalink: /2003/10/07/do-i-sum-it-do-i-average-the-values-or-plot-them/
typo_id:
    - '1774'
mt_id:
    - '1294'
link_related:
    - 'http://www.whump.com/moreLikeThis/link/03668'
raw_content:
    - 'MoreLikeThis on RSS/Data.  I like to saute them with red wine vinegar personally.'
categories:
    - Aside
---

MoreLikeThis on RSS/Data. I like to saute them with red wine vinegar personally.