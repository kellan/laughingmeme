---
id: 3766
title: 'Bobby Fischer, Chess Master, Dies at 64 &#8211; New York Times'
date: '2008-01-31T08:07:11+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2008/01/31/bobby-fischer-chess-master-dies-at-64-new-york-times/'
permalink: /2008/01/31/bobby-fischer-chess-master-dies-at-64-new-york-times/
link_related:
    - 'http://www.nytimes.com/2008/01/18/obituaries/18cnd-fischer.html'
categories:
    - Aside
    - Uncategorized
tags:
    - 'boddy fischer'
    - chess
    - obit
---

Missed this news until Jasmine told me yesterday. I obviously don’t remember his ’70 match, but I remember being intrigued and puzzled in ’92 about the circus around him, and powerfully moved in ’93 by \[Searching for Bobby Fischer\](http://www.imdb.com/title/tt0108065/). The canonical suffering genius. A light went out.