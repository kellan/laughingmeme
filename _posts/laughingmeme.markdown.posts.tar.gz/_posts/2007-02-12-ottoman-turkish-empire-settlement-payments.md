---
id: 3576
title: 'Ottoman Turkish Empire Settlement Payments?'
date: '2007-02-12T22:50:34+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/02/12/ottoman-turkish-empire-settlement-payments/'
permalink: /2007/02/12/ottoman-turkish-empire-settlement-payments/
categories:
    - Uncategorized
tags:
    - ca
    - history
    - surreal
    - taxes
---

TurboTax, as part of filing a California state tax return, just asked me if I was qualified for Ottoman Turkish Empire Settlement Payments? Umm, what are the odds that anyone who was re-settled from the Ottoman empire is still paying taxes in California? Is there a story here?