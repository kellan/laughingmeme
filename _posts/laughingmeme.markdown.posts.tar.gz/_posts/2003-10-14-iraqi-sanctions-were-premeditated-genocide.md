---
id: 1785
title: 'Iraqi sanctions were premeditated genocide.'
date: '2003-10-14T00:56:20+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1785'
permalink: /2003/10/14/iraqi-sanctions-were-premeditated-genocide/
typo_id:
    - '1783'
mt_id:
    - '1314'
link_related:
    - 'http://kenmacleod.blogspot.com/2003_10_01_kenmacleod_archive.html#106599990909473425'
raw_content:
    - 'Bad times when Ken MacLeod\''s truth is more alien then his fiction.'
categories:
    - Aside
tags:
    - ken
    - macleod
---

Bad times when Ken MacLeod’s truth is more alien then his fiction.