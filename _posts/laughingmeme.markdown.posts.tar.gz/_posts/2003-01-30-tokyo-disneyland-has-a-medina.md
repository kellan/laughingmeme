---
id: 1172
title: 'Tokyo Disneyland Has a Medina?'
date: '2003-01-30T22:47:21+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1172'
permalink: /2003/01/30/tokyo-disneyland-has-a-medina/
typo_id:
    - '1170'
mt_id:
    - '335'
link_related:
    - 'http://www.dollarshort.org/galleries/tokyo_disney_20030130/DSCN2408.html'
raw_content:
    - 'strange and immediately recognizable both as a medina, and as disneyland'
categories:
    - Aside
---

strange and immediately recognizable both as a medina, and as disneyland