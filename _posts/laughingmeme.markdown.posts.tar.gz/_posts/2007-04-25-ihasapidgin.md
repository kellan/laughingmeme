---
id: 3626
title: ihasapidgin
date: '2007-04-25T11:58:45+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/04/25/ihasapidgin/'
permalink: /2007/04/25/ihasapidgin/
categories:
    - Uncategorized
---

[![](http://farm1.static.flickr.com/225/472699541_f5d4768e44.jpg)](http://www.flickr.com/photos/kellan/472699541/ "photo sharing")   
 [ihasapidgin](http://www.flickr.com/photos/kellan/472699541/)   
With apologies to Anil’s [I has a pidgin](http://www.dashes.com/anil/2007/04/23/cats_can_has_gr) post.   
Original photo by [Sarah Cartwright](http://flickr.com/photos/80912889@N00/378665223/)  
Oh, \[Gaim has a Pidgin as well\](http://www.pidgin.im/index.php?id=177).