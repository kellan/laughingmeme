---
id: 1215
title: 'linux based wireless mesh repeater'
date: '2003-02-12T02:40:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1215'
permalink: /2003/02/12/linux-based-wireless-mesh-repeater/
typo_id:
    - '1213'
mt_id:
    - '395'
link_related:
    - 'http://www.linuxdevices.com/articles/AT5073214560.html'
raw_content:
    - 'not exactly free, but cheaper then an AT&T NOC'
categories:
    - Aside
---

not exactly free, but cheaper then an AT&amp;T NOC