---
id: 1473
title: 'my cousin jake now has a blog apparently'
date: '2003-05-25T02:20:43+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1473'
permalink: /2003/05/25/my-cousin-jake-now-has-a-blog-apparently/
typo_id:
    - '1471'
mt_id:
    - '794'
link_related:
    - 'http://www.neverkink.net/jake/'
raw_content:
    - 'on net art, music, and seattle.'
categories:
    - Aside
---

on net art, music, and seattle.