---
id: 2318
title: 'Of the world&#8217;s 100 largest economic entities, 51 are now corporations and 49 are countries (2000)'
date: '2004-06-10T17:14:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2318'
permalink: /2004/06/10/of-the-worlds-100-largest-economic-entities-51-are-now-corporations-and-49-are-countries-2000/
typo_id:
    - '2316'
mt_id:
    - '2099'
link_related:
    - 'http://www.corporations.org/system/top100.html'
raw_content:
    - 'With Denmark just nosing out Walmart you know this is a trend which will only accelerate.'
categories:
    - Aside
---

With Denmark just nosing out Walmart you know this is a trend which will only accelerate.