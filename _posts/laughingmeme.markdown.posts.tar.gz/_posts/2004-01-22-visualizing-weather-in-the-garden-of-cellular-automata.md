---
id: 2023
title: 'Visualizing weather in the garden of cellular automata'
date: '2004-01-22T15:05:54+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2023'
permalink: /2004/01/22/visualizing-weather-in-the-garden-of-cellular-automata/
typo_id:
    - '2021'
mt_id:
    - '1669'
link_related:
    - 'http://dealmeida.net/blosxom/en/Programming/a_garden_of_cellular_automata'
raw_content:
    - 'Attractive and fascinating.  What is weahter strange attraction?'
categories:
    - Aside
---

Attractive and fascinating. What is weahter strange attraction?