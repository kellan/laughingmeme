---
id: 2987
title: 'Stupidfool.org: The Folly of the Ping'
date: '2005-08-18T13:44:44+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2987'
permalink: /2005/08/18/stupidfoolorg-the-folly-of-the-ping/
typo_id:
    - '2985'
mt_id:
    - '3052'
link_related:
    - 'http://btrott.typepad.com/typepad/2005/08/the_folly_of_th.html'
raw_content:
    - 'Good to have Ben back blogging.  Streaming Atom is fascinating'
categories:
    - Aside
tags:
    - atom
    - syndication
---

Good to have Ben back blogging. Streaming Atom is fascinating