---
id: 3312
title: 'The beauty of the Boston esplanade'
date: '2006-04-03T19:12:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3312'
permalink: /2006/04/03/the-beauty-of-the-boston-esplanade/
typo_id:
    - '3311'
mt_id:
    - ''
link_related:
    - 'http://home.sergeant.org/D70/2006/04_Apr/01_Apr/DSC_6017.jpg?format=raw;size=800'
raw_content:
    - 'Nothing like a little pristine coastline'
categories:
    - Aside
tags:
    - boston
    - photos
---

Nothing like a little pristine coastline