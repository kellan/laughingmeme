---
id: 3300
title: '50 Most-linked Blogs in September 2000'
date: '2006-03-21T23:25:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3300'
permalink: /2006/03/21/50-most-linked-blogs-in-september-2000/
typo_id:
    - '3298'
mt_id:
    - ''
link_related:
    - 'http://beebo.org/metalog/'
raw_content:
    - 'Late 2000 is when I started reading blogs.  Then I read 17 blogs from the list, currently I read 4.  Of those gone defunct, I miss [Tomalak](http://www.tomalak.org/) the most.'
categories:
    - Aside
tags:
    - blogging
    - blogs
    - history
    - personal
    - weblogs
---

Late 2000 is when I started reading blogs. Then I read 17 blogs from the list, currently I read 4. Of those gone defunct, I miss \[Tomalak\](http://www.tomalak.org/) the most.