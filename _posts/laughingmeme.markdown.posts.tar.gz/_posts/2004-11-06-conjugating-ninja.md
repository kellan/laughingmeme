---
id: 2621
title: 'conjugating &#8216;ninja&#8217;'
date: '2004-11-06T12:36:55+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2621'
permalink: /2004/11/06/conjugating-ninja/
typo_id:
    - '2619'
mt_id:
    - '2521'
link_related:
    - 'http://www.livejournal.com/community/linguaphiles/1132587.html'
raw_content:
    - 'via lattice'
categories:
    - Aside
---

via lattice