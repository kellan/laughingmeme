---
id: 234
title: 'Few links, some interesting'
date: '2002-12-05T11:35:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=234'
permalink: /2002/12/05/few-links-some-interesting/
typo_id:
    - '232'
mt_id:
    - '242'
link_related:
    - ''
raw_content:
    - "<p>\r\n<a href=\\\"http://film.guardian.co.uk/lordoftherings/news/0,11016,852217,00.html\\\">\r\nThe Guardian</a> on the rumor that \r\n<a href=:http://us.imdb.com/Name?Best,+Ahmed\\\">Ahmed Best</a> will be leading the Uruks\r\n\r\n<blockquote>\r\nWhat with the dark skin, broad faces and dreadlocks, it\\'s a wonder Tolkien\r\ndidn\\'t give his baddies a natural sense of rhythm, says John Yatt\r\n</blockquote>\r\n</p>\r\n<p>\r\n<a href=\\\"http://www.salon.com/books/feature/2002/11/28/literary/print.html\\\">\r\nShort fiction on social software</a>, <b>this week only</b>, skim the parts on strong AI. \r\n\r\n<blockquote>\r\nHere was a true  Bakhtinian  carnival  landscape whose sole interest lay in\r\nkeeping itself in perpetual motion. The code for the alpha version of DIALOGOS\r\nwas still rough, unstable, and far from the finished product that Bart and his\r\nteam envisioned. But Bart asked if I\\'d like to help road test it. I wasn\\'t\r\ndoing anything but working on a novel. I said I\\'d be happy to.\r\n</blockquote>\r\n\r\n</p>\r\n<p>\r\n<h3>Towards a Modern Ecology</h3>\r\n<a\r\nhref=\\\"http://www.oreillynet.com/pub/a/oreilly/cprog/news/albatross_1202.html\\\">Oreilly</a>\r\non computers for albatross.\r\n<br />\r\n<a href=\\\"http://www.stanford.edu/~bthomas/vamp/vampecology.htm\\\">Vampire\r\nEcology</a> on carrying capacity of Sunnydale. (funny for non-Buffy fans)\r\n\r\n</p>\r\n<p>\r\nFollowing on last weeks <a href=\\\"http://laughingmeme.org/archives/000232.html#facetted\\\">links on facetted classification</a>, mark has a great intro to <a href=\\\"http://diveintomark.org/archives/2002/12/03.html#this_is_xfml\\\">XFML, a format for representing facetted data</a>.\r\n</p>"
---

[The Guardian](http://film.guardian.co.uk/lordoftherings/news/0,11016,852217,00.html) on the rumor that [Ahmed Best](:http://us.imdb.com/Name?Best,+Ahmed") will be leading the Uruks

> What with the dark skin, broad faces and dreadlocks, it’s a wonder Tolkien didn’t give his baddies a natural sense of rhythm, says John Yatt

[Short fiction on social software](http://www.salon.com/books/feature/2002/11/28/literary/print.html), **this week only**, skim the parts on strong AI.

> Here was a true Bakhtinian carnival landscape whose sole interest lay in keeping itself in perpetual motion. The code for the alpha version of DIALOGOS was still rough, unstable, and far from the finished product that Bart and his team envisioned. But Bart asked if I’d like to help road test it. I wasn’t doing anything but working on a novel. I said I’d be happy to.

### Towards a Modern Ecology

[Oreilly](http://www.oreillynet.com/pub/a/oreilly/cprog/news/albatross_1202.html)on computers for albatross.   
[Vampire Ecology](http://www.stanford.edu/~bthomas/vamp/vampecology.htm) on carrying capacity of Sunnydale. (funny for non-Buffy fans) Following on last weeks [links on facetted classification](http://laughingmeme.org/archives/000232.html#facetted), mark has a great intro to [XFML, a format for representing facetted data](http://diveintomark.org/archives/2002/12/03.html#this_is_xfml).