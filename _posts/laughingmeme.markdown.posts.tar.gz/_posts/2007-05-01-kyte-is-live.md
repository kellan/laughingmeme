---
id: 3634
title: 'kyte is live!'
date: '2007-05-01T10:48:24+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/05/01/kyte-is-live/'
permalink: /2007/05/01/kyte-is-live/
categories:
    - Aside
    - mobile
    - Uncategorized
tags:
    - family
    - kyte
---

This is the product of Thumbjive acquisition 6 months ago — \[NYTimes article\](http://www.nytimes.com/2007/04/30/technology/30social.html) doesn’t mention similarity to Radar is because the same person built it. Congrats Joseph!