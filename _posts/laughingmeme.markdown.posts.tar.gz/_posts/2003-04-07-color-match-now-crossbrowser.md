---
id: 1350
title: 'Color match, now crossbrowser'
date: '2003-04-07T14:08:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1350'
permalink: /2003/04/07/color-match-now-crossbrowser/
typo_id:
    - '1348'
mt_id:
    - '607'
link_related:
    - 'http://traumwind.tierpfad.de/blog/trw_colormatch.html'
raw_content:
    - 'for those of us who are aesthetically challenged'
categories:
    - Aside
---

for those of us who are aesthetically challenged