---
id: 3055
title: 'Margot: &#8220;i am naming my first female child Dolor Sitamet&#8221;'
date: '2005-10-26T00:10:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3055'
permalink: /2005/10/26/margot-i-am-naming-my-first-female-child-dolor-sitamet/
typo_id:
    - '3053'
mt_id:
    - ''
link_related:
    - 'http://catsarebetter.resist.ca/?p=80'
raw_content:
    - 'The fact that that sounds like an excellent idea is probably a sign I shouldn\''t be having kids. (also a touch [goth](http://www.answers.com/dolor))'
categories:
    - Aside
tags:
    - kids
    - life
    - naming
    - quotable
    - st
---

The fact that that sounds like an excellent idea is probably a sign I shouldn’t be having kids. (also a touch \[goth\](http://www.answers.com/dolor))