---
id: 2079
title: 'Upcoming.org to iCal'
date: '2004-02-19T00:03:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2079'
permalink: /2004/02/19/upcomingorg-to-ical/
typo_id:
    - '2077'
mt_id:
    - '1751'
link_related:
    - 'http://george.hotelling.net/90percent/geekery/upcomingorg_to_ical.php'
raw_content:
    - 'Converts Upcoming\''s RSS feed to a .ics file.'
categories:
    - Aside
tags:
    - calendaring
    - ical
    - upcoming
---

Converts Upcoming’s RSS feed to a .ics file.