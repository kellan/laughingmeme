---
id: 2701
title: 'More calendar stuff'
date: '2004-12-09T03:10:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2701'
permalink: /2004/12/09/more-calendar-stuff/
typo_id:
    - '2699'
mt_id:
    - '2626'
link_related:
    - 'http://www.sauria.com/blog/2004/12/08#1165'
raw_content:
    - 'keywords: icalendar, udell, caldav, dasl, python.  to blog.'
categories:
    - Aside
tags:
    - caldav
    - calendaring
    - ical
    - python
    - toread
    - webdav
---

keywords: icalendar, udell, caldav, dasl, python. to blog.