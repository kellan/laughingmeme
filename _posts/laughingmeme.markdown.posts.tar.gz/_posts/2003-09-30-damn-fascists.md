---
id: 1756
title: 'Damn fascists.'
date: '2003-09-30T01:48:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1756'
permalink: /2003/09/30/damn-fascists/
typo_id:
    - '1754'
mt_id:
    - '1262'
link_related:
    - 'http://aaronland.info/weblog/archive/5248'
raw_content:
    - 'Trains they could do, but who said anything about pottery...'
categories:
    - Aside
---

Trains they could do, but who said anything about pottery…