---
id: 3313
title: 'JavaScript-based apps can be served up from the S3 domain as files stored via S3'
date: '2006-04-04T10:02:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3313'
permalink: /2006/04/04/javascript-based-apps-can-be-served-up-from-the-s3-domain-as-files-stored-via-s3/
typo_id:
    - '3312'
mt_id:
    - ''
link_related:
    - 'http://decafbad.com/blog/2006/04/03/javascript-apps-with-readwrite-access-to-s3'
raw_content:
    - 'Adds up to JavaScript apps hosted on S3 with AJAX-based read/write access to S3 itself.'
categories:
    - Aside
tags:
    - ajax
    - amazon
    - distributed
    - s3
    - webapps
---

Adds up to JavaScript apps hosted on S3 with AJAX-based read/write access to S3 itself.