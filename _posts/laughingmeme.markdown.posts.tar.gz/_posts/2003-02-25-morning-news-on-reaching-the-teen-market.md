---
id: 1257
title: 'Morning News:  On reaching the teen market'
date: '2003-02-25T15:54:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1257'
permalink: /2003/02/25/morning-news-on-reaching-the-teen-market/
typo_id:
    - '1255'
mt_id:
    - '457'
link_related:
    - 'http://www.themorningnews.org/archives/stories/behind_the_scenes_cool_2b_real.shtml'
raw_content:
    - 'Dow tries to reach 10yr old Indians with chemistry-positive message'
categories:
    - Aside
---

Dow tries to reach 10yr old Indians with chemistry-positive message