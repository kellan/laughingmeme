---
id: 3412
title: 'I want a Cork&#8217;d, but for cheese'
date: '2006-07-30T13:37:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3412'
permalink: /2006/07/30/i-want-a-corkd-but-for-cheese/
typo_id:
    - '3411'
mt_id:
    - ''
link_related:
    - 'http://corkd.com/'
raw_content:
    - 'Call it Curdl\''d'
categories:
    - Aside
tags:
    - cheese
    - food
    - lazyweb
    - social
    - web2.0
---

Call it Curdl’d