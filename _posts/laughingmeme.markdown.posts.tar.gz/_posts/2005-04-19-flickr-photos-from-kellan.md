---
id: 2920
title: 'Flickr: Photos from Kellan'
date: '2005-04-19T12:10:17+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2920'
permalink: /2005/04/19/flickr-photos-from-kellan/
typo_id:
    - '2918'
mt_id:
    - '2945'
link_related:
    - 'http://flickr.com/photos/kellan'
raw_content:
    - 'Great (new) price, great service.  I\''ll still be fixing my own gallery, but until then...'
categories:
    - Aside
tags:
    - flickr
    - kellan
    - me
    - photos
---

Great (new) price, great service. I’ll still be fixing my own gallery, but until then…