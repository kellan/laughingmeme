---
id: 1630
title: 'Something worth watching on Fox?'
date: '2003-08-03T10:41:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1630'
permalink: /2003/08/03/something-worth-watching-on-fox/
typo_id:
    - '1628'
mt_id:
    - '1044'
link_related:
    - 'http://2hrlunch.typepad.com/bloggo/2003/08/old_and_sly.html'
raw_content:
    - 'Apparently Fox interviewed Chuck D.  How did that happen?'
categories:
    - Aside
---

Apparently Fox interviewed Chuck D. How did that happen?