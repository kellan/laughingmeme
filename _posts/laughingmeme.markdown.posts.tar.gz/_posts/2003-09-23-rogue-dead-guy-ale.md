---
id: 1741
title: 'Rogue: Dead Guy Ale'
date: '2003-09-23T23:48:43+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1741'
permalink: /2003/09/23/rogue-dead-guy-ale/
typo_id:
    - '1739'
mt_id:
    - '1234'
link_related:
    - 'http://www.rogue.com/brews.html#deadguy'
raw_content:
    - 'Rich, sweet, malty, not too heavy, not too hoppy.  On sale at Trader Joe\''s.  I think I\''ll have another.'
categories:
    - Aside
---

Rich, sweet, malty, not too heavy, not too hoppy. On sale at Trader Joe’s. I think I’ll have another.