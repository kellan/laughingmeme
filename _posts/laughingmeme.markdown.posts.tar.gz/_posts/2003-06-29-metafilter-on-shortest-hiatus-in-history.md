---
id: 1564
title: 'Metafilter on shortest hiatus in history'
date: '2003-06-29T23:34:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1564'
permalink: /2003/06/29/metafilter-on-shortest-hiatus-in-history/
typo_id:
    - '1562'
mt_id:
    - '932'
link_related:
    - 'http://www.metafilter.com/mefi/26701'
raw_content:
    - 'Scripting News is taking a break. If only!'
categories:
    - Aside
---

Scripting News is taking a break. If only!