---
id: 1272
title: 'biella&#8217;s gone native :)'
date: '2003-03-02T18:52:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1272'
permalink: /2003/03/02/biellas-gone-native/
typo_id:
    - '1270'
mt_id:
    - '483'
link_related:
    - 'http://www.healthhacker.com/satoroams/archives/000210.html#000210'
raw_content:
    - 'Sato Roams: My Dream IRC channel'
categories:
    - Aside
---

Sato Roams: My Dream IRC channel