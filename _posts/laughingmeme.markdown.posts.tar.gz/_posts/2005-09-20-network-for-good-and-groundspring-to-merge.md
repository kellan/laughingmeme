---
id: 3024
title: 'Network for Good and Groundspring to Merge'
date: '2005-09-20T13:04:09+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3024'
permalink: /2005/09/20/network-for-good-and-groundspring-to-merge/
typo_id:
    - '3022'
mt_id:
    - '3111'
link_related:
    - 'http://news.yahoo.com/news?tmpl=story&u=/usnw/20050920/pl_usnw/network_for_good_and_groundspring_to_merge__leading_nonprofit_providers_of_internet_tools_consolidate102_xml'
raw_content:
    - 'First public announcement I\''ve seen'
categories:
    - Aside
tags:
    - groundspring
    - nptech
    - st
---

First public announcement I’ve seen