---
id: 1434
title: 'TextCat Language Guesser'
date: '2003-05-10T10:24:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1434'
permalink: /2003/05/10/textcat-language-guesser/
typo_id:
    - '1432'
mt_id:
    - '734'
link_related:
    - 'http://traumwind.de/blog/?detail=2003-05-10_00-02'
raw_content:
    - 'Identify 69 languages, including Basque, using Perl'
categories:
    - Aside
---

Identify 69 languages, including Basque, using Perl