---
id: 1456
title: 'Simon shows how to use CSS to replace traditional methods'
date: '2003-05-19T19:22:24+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1456'
permalink: /2003/05/19/simon-shows-how-to-use-css-to-replace-traditional-methods/
typo_id:
    - '1454'
mt_id:
    - '769'
link_related:
    - 'http://simon.incutio.com/archive/2003/05/19/scriptingWithCSS'
raw_content:
    - 'this practical approach really makes CSS more accessible'
categories:
    - Aside
---

this practical approach really makes CSS more accessible