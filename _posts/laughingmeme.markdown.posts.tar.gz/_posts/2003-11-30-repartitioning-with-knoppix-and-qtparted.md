---
id: 1896
title: 'Repartitioning with Knoppix and QtParted'
date: '2003-11-30T12:29:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1896'
permalink: /2003/11/30/repartitioning-with-knoppix-and-qtparted/
typo_id:
    - '1894'
mt_id:
    - '1482'
link_related:
    - 'http://simon.incutio.com/archive/2003/11/30/repartitioning'
raw_content:
    - 'An alternative to using Partion Magic for resizing FAT32, and NTFS. Knoppix gets cooler and cooler.'
categories:
    - Aside
---

An alternative to using Partion Magic for resizing FAT32, and NTFS. Knoppix gets cooler and cooler.