---
id: 2755
title: 'Think like Gramsci, talk like Debs'
date: '2005-01-11T11:38:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2755'
permalink: /2005/01/11/think-like-gramsci-talk-like-debs/
typo_id:
    - '2753'
mt_id:
    - '2702'
link_related:
    - 'http://kenmacleod.blogspot.com/2004_11_01_kenmacleod_archive.html#110003483936259215'
raw_content:
    - 'Ken MacLeod on \''framing\'', and a left/progressive real politick'
categories:
    - Aside
tags:
    - macleod
    - politics
    - propaganda
    - theory
    - tips
---

Ken MacLeod on ‘framing’, and a left/progressive real politick