---
id: 3466
title: 'The Future of White Male Apps'
date: '2006-09-12T22:07:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3466'
permalink: /2006/09/12/the-future-of-white-male-apps/
typo_id:
    - '3465'
mt_id:
    - ''
link_related:
    - 'http://mikemonteiro.vox.com/library/post/the-future-of-white-apps.html'
raw_content:
    - 'It is an [embarrassment](http://www.carsonworkshops.com/summit/).'
categories:
    - Aside
tags:
    - culture
    - sf
    - web
    - web2.0
---

It is an \[embarrassment\](http://www.carsonworkshops.com/summit/).