---
id: 313
title: 'Coalition of the Willing'
date: '2003-02-11T12:01:48+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=313'
permalink: /2003/02/11/coalition-of-the-willing/
typo_id:
    - '311'
mt_id:
    - '387'
link_related:
    - ''
raw_content:
    - "<p>\r\nIs anyone else creeped out by the phrase \\\"Coalition of the Willing\\\"?  Its just ominous, and euphemistic, its sounds like the name of some cult grown to global tyranny in a post-apocalyptic SF stories, or the worst abuses from the Stalin era.  Maybe a bit Orwellian.  Brrrrrrrrr.  Sends shivers down my spine.\r\n</p>\r\n<p>\r\n<a href=\\\"http://misnomer.dru.ca\\\">Dru</a> has a much more rationale response, <a href=\\\"http://misnomer.dru.ca/2003/02/11/a_coalition_of_the_willing.html\\\">please explain your use of the word, willing</a>.\r\n</p>\r\n<p>\r\nupdate:  on a related note, see the Guardian\\'s <a href=\\\"http://www.guardian.co.uk/Iraq/Story/0,2763,917864,00.html\\\">What can Eritrea possibly do to help the US in Iraq?</a>\r\n</p>"
---

Is anyone else creeped out by the phrase “Coalition of the Willing”? Its just ominous, and euphemistic, its sounds like the name of some cult grown to global tyranny in a post-apocalyptic SF stories, or the worst abuses from the Stalin era. Maybe a bit Orwellian. Brrrrrrrrr. Sends shivers down my spine.

[Dru](http://misnomer.dru.ca) has a much more rationale response, [please explain your use of the word, willing](http://misnomer.dru.ca/2003/02/11/a_coalition_of_the_willing.html).

update: on a related note, see the Guardian’s [What can Eritrea possibly do to help the US in Iraq?](http://www.guardian.co.uk/Iraq/Story/0,2763,917864,00.html)