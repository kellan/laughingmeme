---
id: 1977
title: 'this entry is [ ] emailable [x] written at 3am'
date: '2004-01-03T14:38:43+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1977'
permalink: /2004/01/03/this-entry-is-emailable-x-written-at-3am/
typo_id:
    - '1975'
mt_id:
    - '1597'
link_related:
    - 'http://www.benhammersley.com/dparchives/007959.html'
raw_content:
    - 'this would be a useful convention to adopt in my circles.'
categories:
    - Aside
---

this would be a useful convention to adopt in my circles.