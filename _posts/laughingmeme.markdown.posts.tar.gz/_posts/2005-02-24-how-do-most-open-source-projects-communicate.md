---
id: 2834
title: 'How do (most) open source projects communicate'
date: '2005-02-24T08:58:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2834'
permalink: /2005/02/24/how-do-most-open-source-projects-communicate/
typo_id:
    - '2832'
mt_id:
    - '2810'
link_related:
    - 'http://www.inittab.de/blog/2005/02/13#20050213_how-do-os-projects-communicate'
raw_content:
    - 'Great diagram on the paucity of options'
categories:
    - Aside
tags:
    - collaboration
    - communication
    - nptech
    - opensource
---

Great diagram on the paucity of options