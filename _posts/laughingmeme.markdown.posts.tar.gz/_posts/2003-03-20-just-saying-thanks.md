---
id: 365
title: 'Just Saying Thanks'
date: '2003-03-20T06:49:58+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=365'
permalink: /2003/03/20/just-saying-thanks/
typo_id:
    - '363'
mt_id:
    - '539'
link_related:
    - ''
raw_content:
    - "<p>\r\nBBC: <a href=\\\"http://news.bbc.co.uk/2/hi/business/2867619.stm\\\">US offers Israel billions [more] in aid</a>\r\n</p>\r\n<p>\r\nPresumably by way of saying thanks for killing off that pesky Evergreen student?\r\n</p>"
---

BBC: [US offers Israel billions \[more\] in aid](http://news.bbc.co.uk/2/hi/business/2867619.stm)

Presumably by way of saying thanks for killing off that pesky Evergreen student?