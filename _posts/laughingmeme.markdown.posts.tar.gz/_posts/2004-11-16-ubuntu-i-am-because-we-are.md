---
id: 2648
title: 'Ubuntu: &#8220;I am because we are&#8221;'
date: '2004-11-16T15:18:30+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2648'
permalink: /2004/11/16/ubuntu-i-am-because-we-are/
typo_id:
    - '2646'
mt_id:
    - '2554'
link_related:
    - 'http://informage.net/archives/000135.html'
raw_content:
    - 'On the word and the distribution'
categories:
    - Aside
tags:
    - debian
    - ubuntu
---

On the word and the distribution