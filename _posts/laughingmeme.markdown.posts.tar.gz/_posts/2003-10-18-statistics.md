---
id: 1793
title: Statistics
date: '2003-10-18T13:49:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1793'
permalink: /2003/10/18/statistics/
typo_id:
    - '1791'
mt_id:
    - '1328'
link_related:
    - 'http://usefulinc.com/edd/blog/2003/10/18#16:44'
raw_content:
    - 'Edd is assailed by guilt.'
categories:
    - Aside
---

Edd is assailed by guilt.