---
id: 2676
title: 'Home made &#8216;Lord of the Rings&#8217; Monopoly'
date: '2004-12-03T21:52:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2676'
permalink: /2004/12/03/home-made-lord-of-the-rings-monopoly/
typo_id:
    - '2674'
mt_id:
    - '2591'
link_related:
    - 'http://www.flickr.com/photos/seian/1782134/'
raw_content:
    - 'Much nicer then the commercial version.  And nice use of Flickr'
categories:
    - Aside
tags:
    - boardgames
    - diy
    - lotr
    - monopoly
    - tolkien
---

Much nicer then the commercial version. And nice use of Flickr