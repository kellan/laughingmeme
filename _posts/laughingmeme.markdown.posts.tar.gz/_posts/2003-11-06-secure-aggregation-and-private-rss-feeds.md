---
id: 1820
title: 'Secure aggregation, and private RSS feeds'
date: '2003-11-06T02:14:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1820'
permalink: /2003/11/06/secure-aggregation-and-private-rss-feeds/
typo_id:
    - '1818'
mt_id:
    - '1376'
link_related:
    - 'http://labs.silverorange.com/archives/2003/july/privaterss'
raw_content:
    - 'A partial list of RSS aggregators which support SSL/HTTPAuth'
categories:
    - Aside
tags:
    - privaterss
    - rss
---

A partial list of RSS aggregators which support SSL/HTTPAuth