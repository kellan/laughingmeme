---
id: 1597
title: 'Why is this site orange?'
date: '2003-07-13T13:15:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1597'
permalink: /2003/07/13/why-is-this-site-orange/
typo_id:
    - '1595'
mt_id:
    - '980'
link_related:
    - 'http://search.cpan.org/orange.html'
raw_content:
    - 'Bloody London.pm hoodlums.  Not that the turquoise was great'
categories:
    - Aside
---

Bloody London.pm hoodlums. Not that the turquoise was great