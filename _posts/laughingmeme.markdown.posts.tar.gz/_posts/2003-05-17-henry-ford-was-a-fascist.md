---
id: 1451
title: 'Henry Ford Was A Fascist'
date: '2003-05-17T21:55:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1451'
permalink: /2003/05/17/henry-ford-was-a-fascist/
typo_id:
    - '1449'
mt_id:
    - '761'
link_related:
    - 'http://members.aol.com/drovics/fordl.htm'
raw_content:
    - 'I think I heard my first cover of David Rovics today on Thayer St.'
categories:
    - Aside
---

I think I heard my first cover of David Rovics today on Thayer St.