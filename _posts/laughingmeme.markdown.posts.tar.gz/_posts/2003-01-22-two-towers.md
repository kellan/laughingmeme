---
id: 281
title: 'Two Towers?'
date: '2003-01-22T07:27:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=281'
permalink: /2003/01/22/two-towers/
typo_id:
    - '279'
mt_id:
    - '288'
link_related:
    - ''
raw_content:
    - "<p>\r\nAccording to Allconsuming, and Google, <a\r\nhref=\\\"http://alex.golub.name/log/\\\">Golublog</a> is a friend of mine.  Not sure\r\nwho they are, but I like, <a\r\nhref=\\\"http://alex.golub.name/log/archives/2003_01.html#000177\\\">Thought\r\nExpirement</a>.\r\n\r\n<blockquote><em>\r\n...the question is all the more pressing in light of the Two Towers, which was\r\nbasically a three hour long George Lucas smack down.\r\n</em>\r\n</blockquote>\r\n</p>\r\n<p>\r\nIt is part of a genre of Two Towers bait and switch blog entries (hixie\\'s <a\r\nhref=\\\"http://ln.hixie.ch/?start=1041031304&count=1\\\">Birthday Movie</a> being the\r\nother example) that I feel speak to a culture wide lowered expectation that Jackson\r\nis upsetting.\r\n</p>\r\n<p>\r\nWill now stop blogging obsessively, while waiting for client to call.  Wireless router is proving dangerous.\r\n</p>"
tags:
    - allconsuming
    - network
    - social
---

According to Allconsuming, and Google, [Golublog](http://alex.golub.name/log/) is a friend of mine. Not sure who they are, but I like, [Thought Expirement](http://alex.golub.name/log/archives/2003_01.html#000177).

> *…the question is all the more pressing in light of the Two Towers, which was basically a three hour long George Lucas smack down.*

It is part of a genre of Two Towers bait and switch blog entries (hixie’s [Birthday Movie](http://ln.hixie.ch/?start=1041031304&count=1) being the other example) that I feel speak to a culture wide lowered expectation that Jackson is upsetting.

Will now stop blogging obsessively, while waiting for client to call. Wireless router is proving dangerous.