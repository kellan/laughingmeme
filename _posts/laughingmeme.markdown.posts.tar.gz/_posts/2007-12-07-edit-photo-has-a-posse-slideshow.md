---
id: 3734
title: 'Edit Photo has a posse slideshow'
date: '2007-12-07T11:31:09+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/12/07/edit-photo-has-a-posse-slideshow/'
permalink: /2007/12/07/edit-photo-has-a-posse-slideshow/
link_related:
    - 'http://www.flickr.com/groups/edit/pool/show/'
categories:
    - Aside
    - Uncategorized
tags:
    - flickr
    - photos
    - picnick
---

Slideshow for the new Flickr group show casing the master pieces created with Flickr’s new “Edit Photo” feature. Best evar.