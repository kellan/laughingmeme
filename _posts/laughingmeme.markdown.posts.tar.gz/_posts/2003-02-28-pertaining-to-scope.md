---
id: 342
title: 'Pertaining to Scope'
date: '2003-02-28T08:34:36+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=342'
permalink: /2003/02/28/pertaining-to-scope/
typo_id:
    - '340'
mt_id:
    - '469'
link_related:
    - ''
raw_content:
    - '<a title=\"ioctl.org : calendaring : critique\" href=\"http://ioctl.org/jan/cal/critique\"><em>All life is calendaring.</em></a>'
---

[*All life is calendaring.*](http://ioctl.org/jan/cal/critique "ioctl.org : calendaring : critique")