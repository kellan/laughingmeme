---
id: 410
title: 'Gates Assassination'
date: '2003-04-24T16:12:52+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=410'
permalink: /2003/04/24/gates-assassination/
typo_id:
    - '408'
mt_id:
    - '658'
link_related:
    - ''
raw_content:
    - 'While checking this evenings movie times for the <a href=\"http://coolidge.org\">Coolidge Corner Cinema</a> I noticed that May 3rd they are showing a <a href=\"http://www.coolidge.org/s_events.html#nothing\">documentary</a> on <a href=\"http://www.garcettireport.org/\">assassination of Bill Gates</a>.  Somehow I feel like I should have heard about this.'
---

While checking this evenings movie times for the [Coolidge Corner Cinema](http://coolidge.org) I noticed that May 3rd they are showing a [documentary](http://www.coolidge.org/s_events.html#nothing) on [assassination of Bill Gates](http://www.garcettireport.org/). Somehow I feel like I should have heard about this.