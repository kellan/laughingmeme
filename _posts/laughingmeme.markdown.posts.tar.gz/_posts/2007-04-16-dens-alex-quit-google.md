---
id: 3619
title: 'dens + alex quit google.'
date: '2007-04-16T00:12:24+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/04/16/dens-alex-quit-google/'
permalink: /2007/04/16/dens-alex-quit-google/
link_related:
    - 'http://flickr.com/photos/dpstyles/460987802/'
categories:
    - Aside
    - Uncategorized
tags:
    - corporation
    - dodgeball
    - google
    - twitter
---

Google’s track record on acquisition is atrocious. Big companies need to expect to pour resources into tiny acquisition, or whats the point. (I’m looking at you Yahoo!)