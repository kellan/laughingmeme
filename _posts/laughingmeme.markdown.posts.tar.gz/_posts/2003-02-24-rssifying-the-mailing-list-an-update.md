---
id: 336
title: 'RSSifying the Mailing List, an update'
date: '2003-02-24T19:39:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=336'
permalink: /2003/02/24/rssifying-the-mailing-list-an-update/
typo_id:
    - '334'
mt_id:
    - '450'
link_related:
    - ''
raw_content:
    - "<p>\r\nDan Brickley just mentioned a patch to Mailman for producing RSS feeds for a list.  While not the ideal feed described in my <a href=\\\"http://laughingmeme.org/archives/000234.html\\\">extended rant on the subject</a>, its an incremental improvement, and much welcome.\r\n<ul>\r\n<li><a href=\\\"http://lists.w3.org/Archives/Public/www-rdf-interest/2003Feb/0047.html\\\">Dan\\'s email</a></li>\r\n<li><a href=\\\"https://sourceforge.net/tracker/index.php?func=detail&aid=657951&group_id=103&atid=300103\\\">Mailman RFE</a></li>\r\n<li><a href=\\\"https://sourceforge.net/tracker/download.php?group_id=103&atid=300103&file_id=38155&aid=657951\\\">The patch</a></li>\r\n<li><a href=\\\"http://rdfweb.org/pipermail/rdfweb-dev/rss.xml\\\">An example feed</a>\r\n</p>"
tags:
    - collaboration
    - design
    - email
    - mailinglists
    - rss
---

Dan Brickley just mentioned a patch to Mailman for producing RSS feeds for a list. While not the ideal feed described in my [extended rant on the subject](http://laughingmeme.org/archives/000234.html), its an incremental improvement, and much welcome.

- [Dan’s email](http://lists.w3.org/Archives/Public/www-rdf-interest/2003Feb/0047.html)
- [Mailman RFE](https://sourceforge.net/tracker/index.php?func=detail&aid=657951&group_id=103&atid=300103)
- [The patch](https://sourceforge.net/tracker/download.php?group_id=103&atid=300103&file_id=38155&aid=657951)
- [An example feed](http://rdfweb.org/pipermail/rdfweb-dev/rss.xml)