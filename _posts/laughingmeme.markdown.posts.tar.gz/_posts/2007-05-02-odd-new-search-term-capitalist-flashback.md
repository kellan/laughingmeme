---
id: 3635
title: 'Odd new search term: &#8220;capitalist flashback&#8221;'
date: '2007-05-02T13:28:14+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/05/02/odd-new-search-term-capitalist-flashback/'
permalink: /2007/05/02/odd-new-search-term-capitalist-flashback/
link_related:
    - 'http://www.google.com/search?q=%22capitalist+flashback%22'
categories:
    - Aside
    - Uncategorized
tags:
    - blog
    - capitalism
    - google
    - search
---

Over the last two weeks I’ve seen a slow, but steadily growing set of people finding \[a 4 year old blog post\](http://laughingmeme.org/2003/06/04/a-new-mac-laptop/) with the search term “capitalist flashback”. Odd.