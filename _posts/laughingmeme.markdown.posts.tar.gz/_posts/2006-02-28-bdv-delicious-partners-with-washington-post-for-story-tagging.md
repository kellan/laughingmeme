---
id: 3268
title: 'bdv: Del.icio.us partners with Washington Post for story tagging'
date: '2006-02-28T18:37:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3268'
permalink: /2006/02/28/bdv-delicious-partners-with-washington-post-for-story-tagging/
typo_id:
    - '3266'
mt_id:
    - ''
link_related:
    - 'http://hybernaut.com/del.icio.us-washington-post'
raw_content:
    - '\"This isn\''t just a clever use of Del.icio.us by a savvy member of the [corporate media]\".  WP is certainly my first choice on the rather short list of \"newspaper whom will be relevant in 20 years\".  I wonder if this is Y!\''s influence?'
categories:
    - Aside
tags:
    - corporate
    - del.icio.us
    - media
    - web2.0
    - yahoo
---

“This isn’t just a clever use of Del.icio.us by a savvy member of the \[corporate media\]”. WP is certainly my first choice on the rather short list of “newspaper whom will be relevant in 20 years”. I wonder if this is Y!’s influence?