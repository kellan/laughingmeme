---
id: 1807
title: '300 Games Every Game Developer Should Know'
date: '2003-10-28T22:41:46+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1807'
permalink: /2003/10/28/300-games-every-game-developer-should-know/
typo_id:
    - '1805'
mt_id:
    - '1355'
link_related:
    - 'http://costik.com/weblog/2003_10_01_blogchive.html#106720019248778019'
raw_content:
    - 'glad to see Rock-Paper-Scissors made the list.'
categories:
    - Aside
---

glad to see Rock-Paper-Scissors made the list.