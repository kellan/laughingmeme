---
id: 687
title: 'Washington Post and Data Poisoning'
date: '2003-12-19T12:19:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=687'
permalink: /2003/12/19/washington-post-and-data-poisoning/
typo_id:
    - '685'
mt_id:
    - '1560'
link_related:
    - ''
raw_content:
    - "<p>\nDo you read the <a href=\\\"http://www.washingtonpost.com/ac2/wp-dyn/IncrementalGatherServlet?node=admin/registration/incremental&destination=incremental&nextstep=gather&application=3-Point-nation&applicationURL=http://www.washingtonpost.com/\\\">Washington Post</a>?  If so I bet statistics dictate that you\\'re a 38 year old (born in 1965) resident of Oak Hill, Virginia (zip code 20171).  \n</p>\n<p>\nI know I personally have been counted as a pushing 40, female Virginian a dozen times or more.  \n</p>\n<p>\nWhich is by way of saying, isn\\'t that <a href=\\\"http://www.washingtonpost.com/ac2/wp-dyn/IncrementalGatherServlet?node=admin/registration/incremental&destination=incremental&nextstep=gather&application=3-Point-nation&applicationURL=http://www.washingtonpost.com/\\\">interstatial survey</a> that the Post runs lame?  And isn\\'t it nice of them to prompt you with convient, valid answers so you don\\'t have to make up your own?  I try, whenver possible, to always use the example answers to demographic questions.  The improbablye spike, as it climbs higher from the statistical noise, serves as a flag of protest increasingly hard to ignore.  It\\'s a civic duty to lie on marketing surveys.\n</p>"
---

Do you read the [Washington Post](http://www.washingtonpost.com/ac2/wp-dyn/IncrementalGatherServlet?node=admin/registration/incremental&destination=incremental&nextstep=gather&application=3-Point-nation&applicationURL=http://www.washingtonpost.com/)? If so I bet statistics dictate that you’re a 38 year old (born in 1965) resident of Oak Hill, Virginia (zip code 20171).

I know I personally have been counted as a pushing 40, female Virginian a dozen times or more.

Which is by way of saying, isn’t that [interstatial survey](http://www.washingtonpost.com/ac2/wp-dyn/IncrementalGatherServlet?node=admin/registration/incremental&destination=incremental&nextstep=gather&application=3-Point-nation&applicationURL=http://www.washingtonpost.com/) that the Post runs lame? And isn’t it nice of them to prompt you with convient, valid answers so you don’t have to make up your own? I try, whenver possible, to always use the example answers to demographic questions. The improbablye spike, as it climbs higher from the statistical noise, serves as a flag of protest increasingly hard to ignore. It’s a civic duty to lie on marketing surveys.