---
id: 1848
title: 'A life where TiVo has always existed'
date: '2003-11-12T15:50:04+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1848'
permalink: /2003/11/12/a-life-where-tivo-has-always-existed/
typo_id:
    - '1846'
mt_id:
    - '1414'
link_related:
    - 'http://www.kokogiak.com/gedankengang/default.asp#1111200389'
raw_content:
    - 'Fascinating look at a 3yrs old understanding of TV.'
categories:
    - Aside
tags:
    - kids
    - tv
---

Fascinating look at a 3yrs old understanding of TV.