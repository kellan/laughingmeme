---
id: 2006
title: 'RSS feed of recent world earthquakes'
date: '2004-01-16T13:40:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2006'
permalink: /2004/01/16/rss-feed-of-recent-world-earthquakes/
typo_id:
    - '2004'
mt_id:
    - '1641'
link_related:
    - 'http://earthquake.usgs.gov/recenteqsww/rss.html'
raw_content:
    - 'I\''d like to be able to subscribe by fault line.'
categories:
    - Aside
---

I’d like to be able to subscribe by fault line.