---
id: 1565
title: 'Irony will be lavender'
date: '2003-06-30T15:39:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1565'
permalink: /2003/06/30/irony-will-be-lavender/
typo_id:
    - '1563'
mt_id:
    - '934'
link_related:
    - 'http://www.dollarshort.org/archives/000897.html'
raw_content:
    - 'As the Register once famously promised'
categories:
    - Aside
---

As the Register once famously promised