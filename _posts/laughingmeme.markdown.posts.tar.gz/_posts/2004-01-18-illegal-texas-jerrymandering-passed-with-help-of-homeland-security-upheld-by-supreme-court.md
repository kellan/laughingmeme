---
id: 2011
title: 'Illegal Texas jerrymandering, passed with help of Homeland Security, upheld by Supreme Court.'
date: '2004-01-18T16:14:41+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2011'
permalink: /2004/01/18/illegal-texas-jerrymandering-passed-with-help-of-homeland-security-upheld-by-supreme-court/
typo_id:
    - '2009'
mt_id:
    - '1651'
link_related:
    - 'http://www.nytimes.com/2004/01/17/national/17TEXA.html'
raw_content:
    - 'DeLay\''s rounding up of rivals at gun point gets national sanction.'
categories:
    - Aside
---

DeLay’s rounding up of rivals at gun point gets national sanction.