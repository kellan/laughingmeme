---
id: 977
title: 'Boston RSS'
date: '2004-12-12T13:25:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=977'
permalink: /2004/12/12/boston-rss/
typo_id:
    - '975'
mt_id:
    - '2635'
link_related:
    - ''
raw_content:
    - "<p>\r\nStarting to collect a <a href=\\\"http://del.icio.us/kellan/boston+rss\\\">list of RSS feeds for Boston</a> (similar to a set I put together for Seattle, but never published)\r\n\r\n<ul>\r\n<li><a href=\\\"http://del.icio.us/rss/tag/boston\\\">http://del.icio.us/tag/boston</a> of course.</li>\r\n<li>also <a href=\\\"http://www.upcoming.org/syndicate/metro/10\\\">Upcoming.org: Boston</a></li>\r\n</ul>\r\n\r\nThats all I have so far, but suggestions are welcome.\r\n</p>\r\n<p>\r\nIdeally I\\'d like to find a resource like <a href=\\\"http://scottstuff.net/\\\">Scott\\'s</a> <a href=\\\"http://scottstuff.net/books/events\\\">Seattle Book Events calendar</a>, might have to make that one.\r\n</p>"
tags:
    - books
    - boston
    - del.icio.us
    - rss
    - seattle
    - upcoming
---

Starting to collect a [list of RSS feeds for Boston](http://del.icio.us/kellan/boston+rss) (similar to a set I put together for Seattle, but never published)

- [http://del.icio.us/tag/boston](http://del.icio.us/rss/tag/boston) of course.
- also [Upcoming.org: Boston](http://www.upcoming.org/syndicate/metro/10)

Thats all I have so far, but suggestions are welcome. Ideally I’d like to find a resource like [Scott’s](http://scottstuff.net/) [Seattle Book Events calendar](http://scottstuff.net/books/events), might have to make that one.