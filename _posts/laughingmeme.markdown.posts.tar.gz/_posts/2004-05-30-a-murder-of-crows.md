---
id: 833
title: 'A Murder of Crows'
date: '2004-05-30T18:12:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=833'
permalink: /2004/05/30/a-murder-of-crows/
typo_id:
    - '831'
mt_id:
    - '2083'
link_related:
    - ''
raw_content:
    - "I am having a seriously  <cite>Dark is Rising</cite> weekend.  \n\nYesterday I had 3 crows follow me 5 blocks, 2 behind, 1 ahead, as if bracketing me, cawing constantly.  This morning I woke up to a hideously loud cawing, only to look out my window directly into the eye of a crow not 12 inches away. (I admit I yelped)  And this evening I just got back to find 12 crows sitting on my porch.  \n\nI\\'m looking forward to getting out of town for a couple of days."
tags:
    - cooper
---

I am having a seriously <cite>Dark is Rising</cite> weekend.

Yesterday I had 3 crows follow me 5 blocks, 2 behind, 1 ahead, as if bracketing me, cawing constantly. This morning I woke up to a hideously loud cawing, only to look out my window directly into the eye of a crow not 12 inches away. (I admit I yelped) And this evening I just got back to find 12 crows sitting on my porch.

I’m looking forward to getting out of town for a couple of days.