---
id: 2626
title: 'misnomer: Credibility: rough notes'
date: '2004-11-10T16:35:24+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2626'
permalink: /2004/11/10/misnomer-credibility-rough-notes/
typo_id:
    - '2624'
mt_id:
    - '2527'
link_related:
    - 'http://misnomer.dru.ca/2004/11/credibility_rough_notes.html'
raw_content:
    - 'we had a whole mini-conference in SubEthaEdit.'
categories:
    - Aside
tags:
    - collaboration
    - credibility
    - media
---

we had a whole mini-conference in SubEthaEdit.