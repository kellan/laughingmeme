---
id: 3498
title: 'Valleyspeak: &#8220;ugc initiative&#8221;'
date: '2006-10-10T12:46:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3498'
permalink: /2006/10/10/valleyspeak-ugc-initiative/
typo_id:
    - '3497'
mt_id:
    - ''
link_related:
    - 'http://www.google.com/search?q=ugc initiative'
raw_content:
    - 'a phrase I hoped I would never hear'
categories:
    - Aside
tags:
    - buzzword
    - community
    - valleyspeak
---

a phrase I hoped I would never hear