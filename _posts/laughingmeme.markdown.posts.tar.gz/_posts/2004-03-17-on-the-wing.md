---
id: 769
title: 'On the Wing'
date: '2004-03-17T13:01:17+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=769'
permalink: /2004/03/17/on-the-wing/
typo_id:
    - '767'
mt_id:
    - '1853'
link_related:
    - ''
raw_content:
    - "<p>\nI want to thank <a href=\\\"http://www.nogwa.com/\\\">Gavin</a> for producing a new badge <img src=\\\"http://magpierss.sourceforge.net/magpierss-badge.png\\\" alt=\\\"a magpie in flight\\\" /> for <a href=\\\"http://magpierss.sf.net\\\">Magpie</a>.  \n\n</p>\n<p>\nAlso I realize that previous banner <img src=\\\"http://magpierss.sourceforge.net/magpie-banner.gif\\\"> I had got lost in the HTML shuffle. \n\n (which might have been a good thing given my Photoshop skills). \n\nAlso the stark  <img src=\\\"http://magpierss.sourceforge.net/black_grey_magpie_news.gif\\\">\n</p>\n<p>\nYou are under no compulsion to display any of these, only if you want to.  And lastly, Sourceforge says Magpie broke the 100,000 page views, and 11,000 downloads about a month ago.\n</p>"
tags:
    - magpie
---

I want to thank [Gavin](http://www.nogwa.com/) for producing a new badge ![a magpie in flight](http://magpierss.sourceforge.net/magpierss-badge.png) for [Magpie](http://magpierss.sf.net).

Also I realize that previous banner ![](http://magpierss.sourceforge.net/magpie-banner.gif) I had got lost in the HTML shuffle.

(which might have been a good thing given my Photoshop skills).

Also the stark ![](http://magpierss.sourceforge.net/black_grey_magpie_news.gif)

You are under no compulsion to display any of these, only if you want to. And lastly, Sourceforge says Magpie broke the 100,000 page views, and 11,000 downloads about a month ago.