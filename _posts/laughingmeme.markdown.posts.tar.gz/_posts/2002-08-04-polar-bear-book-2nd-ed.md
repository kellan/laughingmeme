---
id: 108
title: 'Polar Bear Book, 2nd ed.'
date: '2002-08-04T23:38:19+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=108'
permalink: /2002/08/04/polar-bear-book-2nd-ed/
typo_id:
    - '106'
mt_id:
    - '116'
link_related:
    - ''
raw_content:
    - "<p>\r\nO\\'Reilly\\'s <a href=\\\"http://www.oreilly.com/catalog/infotecture2/\\\">Information Architecture</a> book was one of the most important books I read, back in the early days of the web.   Not only was it important in shaping my ideas about information architecture, but it also helped me see the web in its continium; that it had not sprung fully formed like Athena from TBL\\'s head, and that academe had important things to tell us about this new medium.(that last one was powerful medicine for a recent college drop out, founding a dotcom in rural Massachusetts)\r\n</p>\r\n<p>\r\nAnd the 2nd edition is out!  \r\n</p>\r\n<p>\r\nAdd that to a 2nd of <a href=\\\"http://www.oreilly.com/catalog/regex2/\\\">Friedl\\'s wise old owl book</a> and its starts to feel like xmas.\r\n</p>"
---

O’Reilly’s [Information Architecture](http://www.oreilly.com/catalog/infotecture2/) book was one of the most important books I read, back in the early days of the web. Not only was it important in shaping my ideas about information architecture, but it also helped me see the web in its continium; that it had not sprung fully formed like Athena from TBL’s head, and that academe had important things to tell us about this new medium.(that last one was powerful medicine for a recent college drop out, founding a dotcom in rural Massachusetts)

And the 2nd edition is out!

Add that to a 2nd of [Friedl’s wise old owl book](http://www.oreilly.com/catalog/regex2/) and its starts to feel like xmas.