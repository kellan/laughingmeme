---
id: 2743
title: 'OS X Tip:  quit or hide applications from app switcher'
date: '2005-01-05T13:55:05+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2743'
permalink: /2005/01/05/os-x-tip-quit-or-hide-applications-from-app-switcher/
typo_id:
    - '2741'
mt_id:
    - '2685'
link_related:
    - 'http://www.apple.com/pro/tips/index.html'
raw_content:
    - 'Very nice.'
categories:
    - Aside
tags:
    - apple
    - osx
    - tip
---

Very nice.