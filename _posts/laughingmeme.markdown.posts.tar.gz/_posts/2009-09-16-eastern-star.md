---
id: 4278
title: 'Eastern Star'
date: '2009-09-16T09:04:14+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4278'
permalink: /2009/09/16/eastern-star/
categories:
    - Uncategorized
tags:
    - flying
    - long
    - 'long twitter'
    - overhead
    - travel
    - writing
---

On a flight reading [Paul Theroux’s](http://www.paultheroux.com/) [Ghost Train](http://www.amazon.com/Ghost-Train-Eastern-Star-Railway/dp/0618418873), a meditations on traveling and writing, and travel writing. The braying voice of an over-confident founder echoes around the too small spaces of the plane, pitching his social publishing platform to his seat mate; built on \[Rails\](http://rubyonrails.org/) in India, *“we’re great for travel books, anything you can make a template for.”*

I don’t think Paul would approve.