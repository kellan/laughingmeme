---
id: 2143
title: '&#8220;Not in Our Name&#8221; is using protest.net'
date: '2004-03-17T14:34:12+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2143'
permalink: /2004/03/17/not-in-our-name-is-using-protestnet/
typo_id:
    - '2141'
mt_id:
    - '1851'
link_related:
    - 'http://www.anarchogeek.com/archives/000339.html'
raw_content:
    - ''
categories:
    - Aside
tags:
    - activism
    - calendar
    - perl
    - protest.net
---

