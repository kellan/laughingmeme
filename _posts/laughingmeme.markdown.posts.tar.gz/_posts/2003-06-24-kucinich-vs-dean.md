---
id: 1554
title: 'Kucinich vs. Dean'
date: '2003-06-24T14:53:27+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1554'
permalink: /2003/06/24/kucinich-vs-dean/
typo_id:
    - '1552'
mt_id:
    - '913'
link_related:
    - 'http://www.bobharris.com/kucinichdean.html'
raw_content:
    - 'I need to get out of this country'
categories:
    - Aside
---

I need to get out of this country