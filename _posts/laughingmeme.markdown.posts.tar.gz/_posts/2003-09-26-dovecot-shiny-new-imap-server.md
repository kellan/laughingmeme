---
id: 1746
title: 'Dovecot &#8211; shiny new IMAP server'
date: '2003-09-26T15:33:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1746'
permalink: /2003/09/26/dovecot-shiny-new-imap-server/
typo_id:
    - '1744'
mt_id:
    - '1247'
link_related:
    - 'http://dovecot.procontrol.fi/'
raw_content:
    - 'Because uw-imap sucks, and courier is bear with lousy documentation.'
categories:
    - Aside
---

Because uw-imap sucks, and courier is bear with lousy documentation.