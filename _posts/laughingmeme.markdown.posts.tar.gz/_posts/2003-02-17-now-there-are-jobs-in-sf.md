---
id: 323
title: 'Now there are jobs in SF!?!?!'
date: '2003-02-17T19:18:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=323'
permalink: /2003/02/17/now-there-are-jobs-in-sf/
typo_id:
    - '321'
mt_id:
    - '413'
link_related:
    - ''
raw_content:
    - "<p>\r\nI should stop posting, and go do something, but it was a weird long day, and I\\'m kind of trapped inside.  But can I tell you how frustrating this is?  Jasmine and I were in San Francisco for a year, and there was nothing remotely resembling work available, now since I moved back east (what 2 months ago?) there have been 3 dream opportunities, and numerous other possiblities, including taking over for a friend at a prominent community site who gave his notice this week.  Grrrrrrrrrrrrrrrrrrr.\r\n</p>\r\n<p>\r\nIn the mean time there is nothing out here.\r\n</p>"
tags:
    - jobs
    - sanfran
---

I should stop posting, and go do something, but it was a weird long day, and I’m kind of trapped inside. But can I tell you how frustrating this is? Jasmine and I were in San Francisco for a year, and there was nothing remotely resembling work available, now since I moved back east (what 2 months ago?) there have been 3 dream opportunities, and numerous other possiblities, including taking over for a friend at a prominent community site who gave his notice this week. Grrrrrrrrrrrrrrrrrrr.

In the mean time there is nothing out here.