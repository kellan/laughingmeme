---
id: 2838
title: 'Hiding the Agenda: on how to run highly interactive events.'
date: '2005-02-24T10:01:28+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2838'
permalink: /2005/02/24/hiding-the-agenda-on-how-to-run-highly-interactive-events/
typo_id:
    - '2836'
mt_id:
    - '2814'
link_related:
    - 'http://www.eekim.com/blog/2005/02/23#hidingagendas'
raw_content:
    - 'Gunner is amazing, and Eugene is doing the best thinking anywhere about these issues.  Together.... fucking deadly.'
categories:
    - Aside
tags:
    - aspiration
    - collaboration
    - nptech
    - participation
---

Gunner is amazing, and Eugene is doing the best thinking anywhere about these issues. Together…. fucking deadly.