---
id: 1442
title: 'puzzle.py, a puzzle solving framework'
date: '2003-05-13T09:40:35+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1442'
permalink: /2003/05/13/puzzlepy-a-puzzle-solving-framework/
typo_id:
    - '1440'
mt_id:
    - '744'
link_related:
    - 'http://users.rcn.com/python/download/puzzle.py'
raw_content:
    - elegant.
categories:
    - Aside
---

elegant.