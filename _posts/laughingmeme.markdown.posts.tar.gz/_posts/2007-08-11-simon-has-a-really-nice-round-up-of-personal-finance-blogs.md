---
id: 3690
title: 'Simon has a really nice round up of personal finance blogs'
date: '2007-08-11T13:01:50+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/08/11/simon-has-a-really-nice-round-up-of-personal-finance-blogs/'
permalink: /2007/08/11/simon-has-a-really-nice-round-up-of-personal-finance-blogs/
link_related:
    - 'http://hitherto.net/2007/08/10/finance-clarifications/'
categories:
    - Aside
    - Uncategorized
tags:
    - money
---

Similarly looking the gaping maws of 30 in the face, and noticing a desire to understand $$ a bit more.