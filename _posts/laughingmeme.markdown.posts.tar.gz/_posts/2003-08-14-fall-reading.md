---
id: 1654
title: 'Fall Reading'
date: '2003-08-14T11:14:23+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1654'
permalink: /2003/08/14/fall-reading/
typo_id:
    - '1652'
mt_id:
    - '1082'
link_related:
    - 'http://www.felbers.net/mt/archives/001618.html'
raw_content:
    - 'Coming this fall to a quality bookseller near you'
categories:
    - Aside
---

Coming this fall to a quality bookseller near you