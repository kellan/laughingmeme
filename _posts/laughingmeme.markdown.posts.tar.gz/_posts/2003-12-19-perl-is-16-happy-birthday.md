---
id: 1953
title: 'Perl is 16 &#8211; Happy Birthday'
date: '2003-12-19T04:33:08+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1953'
permalink: /2003/12/19/perl-is-16-happy-birthday/
typo_id:
    - '1951'
mt_id:
    - '1557'
link_related:
    - 'http://use.perl.org/article.pl?sid=03/12/18/1411200&mode=nested&tid=1'
raw_content:
    - 'Scripting languages are a fad'
categories:
    - Aside
---

Scripting languages are a fad