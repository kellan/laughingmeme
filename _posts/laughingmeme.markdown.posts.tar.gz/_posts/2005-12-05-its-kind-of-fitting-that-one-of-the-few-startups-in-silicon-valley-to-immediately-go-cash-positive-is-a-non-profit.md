---
id: 3141
title: '&#8220;it&#8217;s kind of fitting that one of the few startups in silicon valley to immediately go cash positive is a non-profit;&#8221;'
date: '2005-12-05T17:12:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3141'
permalink: /2005/12/05/its-kind-of-fitting-that-one-of-the-few-startups-in-silicon-valley-to-immediately-go-cash-positive-is-a-non-profit/
typo_id:
    - '3139'
mt_id:
    - ''
link_related:
    - 'http://markpincus.typepad.com/markpincus/2005/05/firefox_foxy_ca.html'
raw_content:
    - 'Firefox is making $30mil off of its Google search box.  (old news I guess, but first I\''ve heard it.)'
categories:
    - Aside
tags:
    - firefox
    - funding
    - google
    - money
    - mozilla
    - nptech
    - opensource
---

Firefox is making $30mil off of its Google search box. (old news I guess, but first I’ve heard it.)