---
id: 1362
title: 'America: a country where ridiculous proportions of the population believe they were created by god, abducted by aliens, and attacked by Iraq'
date: '2003-04-15T10:01:48+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1362'
permalink: /2003/04/15/america-a-country-where-ridiculous-proportions-of-the-population-believe-they-were-created-by-god-abducted-by-aliens-and-attacked-by-iraq/
typo_id:
    - '1360'
mt_id:
    - '629'
link_related:
    - 'http://kenmacleod.blogspot.com/2003_03_23_kenmacleod_archive.html'
raw_content:
    - 'In other news, Ken MacLeod has a blog!'
categories:
    - Aside
---

In other news, Ken MacLeod has a blog!