---
id: 2539
title: 'Meet little baby Valid'
date: '2004-09-17T12:45:14+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2539'
permalink: /2004/09/17/meet-little-baby-valid/
typo_id:
    - '2537'
mt_id:
    - '2395'
link_related:
    - 'http://www.readwriteweb.com/archives/002246.php'
raw_content:
    - 'Suggested baby names for bloggers'
categories:
    - Aside
tags:
    - baby
    - blogs
---

Suggested baby names for bloggers