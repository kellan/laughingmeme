---
id: 2874
title: 'tonx has just about the best job in the world.'
date: '2005-03-21T14:45:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2874'
permalink: /2005/03/21/tonx-has-just-about-the-best-job-in-the-world/
typo_id:
    - '2872'
mt_id:
    - '2869'
link_related:
    - 'http://tonx.org/index.php/archives/i-love-my-job/'
raw_content:
    - 'for the love of coffee'
categories:
    - Aside
tags:
    - coffee
    - seattle
    - tonx
---

for the love of coffee