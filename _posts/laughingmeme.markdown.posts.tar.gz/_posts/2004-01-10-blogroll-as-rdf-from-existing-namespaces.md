---
id: 1993
title: 'BlogRoll as RDF from existing namespaces'
date: '2004-01-10T15:57:55+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1993'
permalink: /2004/01/10/blogroll-as-rdf-from-existing-namespaces/
typo_id:
    - '1991'
mt_id:
    - '1623'
link_related:
    - 'http://usefulinc.com/edd/notes/RDFBlogRoll'
raw_content:
    - 'instead of the current de facto standard of repurposing a poorly specified outline format. (via TomH)'
categories:
    - Aside
---

instead of the current de facto standard of repurposing a poorly specified outline format. (via TomH)