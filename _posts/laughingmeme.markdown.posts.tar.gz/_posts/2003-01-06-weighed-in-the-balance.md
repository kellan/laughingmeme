---
id: 263
title: 'Weighed in the Balance&#8230;'
date: '2003-01-06T14:03:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=263'
permalink: /2003/01/06/weighed-in-the-balance/
typo_id:
    - '261'
mt_id:
    - '271'
link_related:
    - ''
raw_content:
    - "I stand, poised at the moment of indescision, <a href=\\\"http://allconsuming.net/item.cgi?isbn=0553091395\\\"><cite>\nFields of Greens:  New Vegetarian Recipes from the Greens Restaurant</cite></a> <b>-or-</b> \n<a href=\\\"http://allconsuming.net/item.cgi?isbn=0816614024\\\"><cite>A Thousand Plateaus: Capitalism and Schizophrenia</cite></a>.  A book rests in each hand, weighing like the scales of justice, \\\"What will I need/want over the next few months?\\\"  \n\nMy backpack looks up at me, plaintively, \\\"Not another book...please.\\\"   \n\nI\\'m stuck.  The clock is ticking.  Do I really need the Greens\\' pie crust recipe?  Am I really going to re-read <cite>1000 Plateaus</cite>?  I flip through the Greens\\' cookbook remembering the pie crust takes over a day to make.  I put it down.  Pie season lies in the past, and distant future.   I pick up D&G, flip through it.  Will metaphors of rhizomatic growth and machinic assemblage keep my interest in the Providence winter?  I remember the book\\'s essential vagueness, and doubt it.  Elizabeth suggested reading D&G as poetry so I think I will leave both behind and borrow one of my mother\\'s (short) books of verse."
---

I stand, poised at the moment of indescision, [<cite>Fields of Greens: New Vegetarian Recipes from the Greens Restaurant</cite>](http://allconsuming.net/item.cgi?isbn=0553091395) **-or-** [<cite>A Thousand Plateaus: Capitalism and Schizophrenia</cite>](http://allconsuming.net/item.cgi?isbn=0816614024). A book rests in each hand, weighing like the scales of justice, “What will I need/want over the next few months?”

My backpack looks up at me, plaintively, “Not another book…please.”

I’m stuck. The clock is ticking. Do I really need the Greens’ pie crust recipe? Am I really going to re-read <cite>1000 Plateaus</cite>? I flip through the Greens’ cookbook remembering the pie crust takes over a day to make. I put it down. Pie season lies in the past, and distant future. I pick up D&amp;G, flip through it. Will metaphors of rhizomatic growth and machinic assemblage keep my interest in the Providence winter? I remember the book’s essential vagueness, and doubt it. Elizabeth suggested reading D&amp;G as poetry so I think I will leave both behind and borrow one of my mother’s (short) books of verse.