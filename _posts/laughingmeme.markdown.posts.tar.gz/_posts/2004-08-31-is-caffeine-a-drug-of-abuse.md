---
id: 2500
title: 'Is caffeine a drug of abuse?'
date: '2004-08-31T03:18:16+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2500'
permalink: /2004/08/31/is-caffeine-a-drug-of-abuse/
typo_id:
    - '2498'
mt_id:
    - '2343'
link_related:
    - 'http://www.seattleweekly.com/features/0433/040818_news_drug_caffeine.php'
raw_content:
    - '200mg for a shot of espresso sounds high.'
categories:
    - Aside
tags:
    - caffeine
    - coffee
---

200mg for a shot of espresso sounds high.