---
id: 1913
title: 'Mac OS X and Linksys DNS Issues'
date: '2003-12-03T22:29:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1913'
permalink: /2003/12/03/mac-os-x-and-linksys-dns-issues/
typo_id:
    - '1911'
mt_id:
    - '1503'
link_related:
    - 'http://www.obzorg.org/archives/00000001.shtml'
raw_content:
    - 'the dns_send_query error is just one of several problems I\''m having with my Linksys router'
categories:
    - Aside
---

the dns*send*query error is just one of several problems I’m having with my Linksys router