---
id: 2581
title: 'Much of this discrepancy can be explained by increasing cell phone usage, which is distorting the results of phone polling.'
date: '2004-10-06T00:47:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2581'
permalink: /2004/10/06/much-of-this-discrepancy-can-be-explained-by-increasing-cell-phone-usage-which-is-distorting-the-results-of-phone-polling/
typo_id:
    - '2579'
mt_id:
    - '2457'
link_related:
    - 'http://wesnerm.blogs.com/net_undocumented/2004/10/election_analys.html'
raw_content:
    - 'it is illegal for pollsters to call cell phone numbers ... and there are major demographic differences between landline and cellphone users'
categories:
    - Aside
tags:
    - cellphone
    - culture
    - election
---

it is illegal for pollsters to call cell phone numbers … and there are major demographic differences between landline and cellphone users