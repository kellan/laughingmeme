---
id: 1075
title: 'The Browncoats Are Coming!'
date: '2005-04-27T07:10:25+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1075'
permalink: /2005/04/27/the-browncoats-are-coming/
typo_id:
    - '1073'
mt_id:
    - '2955'
link_related:
    - ''
raw_content:
    - "Walking through Copley Mall yesterday (don\\'t ask), the two impeccably dressed sales clerks standing at the door way of Benetton were deep in conversation, well one of them was passionately in conversation, and the other was trying to look interested, \\\"it\\'s cowboys in space... from the creator of Buffy... best TV ever...\\\", that kind of stuff.  Shibboleth to a fellow Fire Fly fan.  I smiled, and nodded, and immediately I was drawn into the conversation, \\\"the trailer is supposed to come out today, but it wasn\\'t out before I had to start my shift, what if its been postponed again.\\\"\n\nAs it just so happened, I had watched [said trailer](http://www.apple.com/trailers/universal/serenity/), and had a local cached copy.\n\nAnd I didn\\'t even get store credit or a gift certificate or anything. (not that I\\'m sure anything in Benetton would fit)\n\nI\\'m nervous, it can\\'t, practically by definition be as good as the TV show, and yet who wouldn\\'t want more Fire Fly, too pretty to die, and tragically cut short before the end of the first season.\n\nP.S. Anyone know what happened to [Shepherd Book](http://fireflyfans.net/thread.asp?b=2&t=5376#66178)?  No sign of him in the trailer."
tags:
    - firefly
    - tv
---

Walking through Copley Mall yesterday (don’t ask), the two impeccably dressed sales clerks standing at the door way of Benetton were deep in conversation, well one of them was passionately in conversation, and the other was trying to look interested, “it’s cowboys in space… from the creator of Buffy… best TV ever…”, that kind of stuff. Shibboleth to a fellow Fire Fly fan. I smiled, and nodded, and immediately I was drawn into the conversation, “the trailer is supposed to come out today, but it wasn’t out before I had to start my shift, what if its been postponed again.”

As it just so happened, I had watched \[said trailer\](http://www.apple.com/trailers/universal/serenity/), and had a local cached copy.

And I didn’t even get store credit or a gift certificate or anything. (not that I’m sure anything in Benetton would fit)

I’m nervous, it can’t, practically by definition be as good as the TV show, and yet who wouldn’t want more Fire Fly, too pretty to die, and tragically cut short before the end of the first season.

P.S. Anyone know what happened to \[Shepherd Book\](http://fireflyfans.net/thread.asp?b=2&amp;t=5376#66178)? No sign of him in the trailer.