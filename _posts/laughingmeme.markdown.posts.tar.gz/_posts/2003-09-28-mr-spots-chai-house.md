---
id: 604
title: 'Mr. Spot&#8217;s Chai House'
date: '2003-09-28T19:24:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=604'
permalink: /2003/09/28/mr-spots-chai-house/
typo_id:
    - '602'
mt_id:
    - '1249'
link_related:
    - ''
raw_content:
    - "<p>\n<a href=\\\"http://www.chaihouse.com/\\\">Mr. Spot\\'s Chai House</a>, a hippy inspired hang out spot (spevia, incense, Tibetan prayer flags, chai, people <em>still</em> talking about Burning Man) in Ballard, that manages to be clean, and comfortable.  Amazing tea selection, decent espresso drinks, incredible chai (you find <a href=\\\"http://www.chaihouse.com/chai.html\\\">their product</a> available at <a href=\\\"http://www.chaihouse.com/locations.html\\\">many Seattle coffee shops</a>), plentiful, if poorly distributed, power outlets.  Wireless (and wired) net connection is free, get the WEP key from sign above complimentary Mac.\n</p>\n<p>\nI recommend not coming on open mic night (Thursday) if you\\'re trying to get work done (note, they also start serving beer at some point in the evening), but a Ruby Tuesday Chai, with its double shot of lemon juice makes a great Sunday morning wake up alternative to caffeine.\n</p>"
---

[Mr. Spot’s Chai House](http://www.chaihouse.com/), a hippy inspired hang out spot (spevia, incense, Tibetan prayer flags, chai, people *still* talking about Burning Man) in Ballard, that manages to be clean, and comfortable. Amazing tea selection, decent espresso drinks, incredible chai (you find [their product](http://www.chaihouse.com/chai.html) available at [many Seattle coffee shops](http://www.chaihouse.com/locations.html)), plentiful, if poorly distributed, power outlets. Wireless (and wired) net connection is free, get the WEP key from sign above complimentary Mac.

I recommend not coming on open mic night (Thursday) if you’re trying to get work done (note, they also start serving beer at some point in the evening), but a Ruby Tuesday Chai, with its double shot of lemon juice makes a great Sunday morning wake up alternative to caffeine.