---
id: 1725
title: 'Lipsum.com &#8211; the ultimate in webservices'
date: '2003-09-16T13:44:43+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1725'
permalink: /2003/09/16/lipsumcom-the-ultimate-in-webservices/
typo_id:
    - '1723'
mt_id:
    - '1203'
link_related:
    - 'http://lipsum.com/'
raw_content:
    - 'Now with Perl module, can the TT2 plugin be far behind?'
categories:
    - Aside
---

Now with Perl module, can the TT2 plugin be far behind?