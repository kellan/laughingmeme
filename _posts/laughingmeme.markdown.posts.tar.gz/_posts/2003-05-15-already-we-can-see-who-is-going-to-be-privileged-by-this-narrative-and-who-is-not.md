---
id: 1447
title: '&#8220;Already we can see who is going to be privileged by this narrative and who is not.&#8221;'
date: '2003-05-15T18:35:01+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1447'
permalink: /2003/05/15/already-we-can-see-who-is-going-to-be-privileged-by-this-narrative-and-who-is-not/
typo_id:
    - '1445'
mt_id:
    - '752'
link_related:
    - 'http://www.mcsweeneys.net/2003/04/22fellowship.html'
raw_content:
    - 'Zinn & Chomsky on The Fellowship of the Ring'
categories:
    - Aside
---

Zinn &amp; Chomsky on The Fellowship of the Ring