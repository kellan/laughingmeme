---
id: 3256
title: 'MeasureMap goes to Google, which means Ruby at Google!'
date: '2006-02-14T18:07:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3256'
permalink: /2006/02/14/measuremap-goes-to-google-which-means-ruby-at-google/
typo_id:
    - '3254'
mt_id:
    - ''
link_related:
    - 'http://googleblog.blogspot.com/2006/02/here-comes-measure-map.html'
raw_content:
    - 'Beginning of a trend? (I\''d say this will fix the MeasureMap scalability probs, except G hasn\''t fixed the ones with Gurchin yet)'
categories:
    - Aside
tags:
    - google
    - measuremap
    - ruby
    - stats
---

Beginning of a trend? (I’d say this will fix the MeasureMap scalability probs, except G hasn’t fixed the ones with Gurchin yet)