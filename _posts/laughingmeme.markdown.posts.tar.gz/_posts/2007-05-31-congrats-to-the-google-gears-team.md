---
id: 3649
title: 'Congrats to the Google Gears team!'
date: '2007-05-31T08:40:35+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/05/31/congrats-to-the-google-gears-team/'
permalink: /2007/05/31/congrats-to-the-google-gears-team/
link_related:
    - 'http://gears.google.com/'
categories:
    - Aside
    - Uncategorized
tags:
    - ajax
    - gears
    - google
    - mozilla
    - sqlite
---

That must have been a long road — if you look around you can find traces of development leading back to 2005.