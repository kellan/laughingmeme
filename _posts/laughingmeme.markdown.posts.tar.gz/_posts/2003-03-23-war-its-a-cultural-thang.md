---
id: 1319
title: 'War, its a cultural thang'
date: '2003-03-23T18:57:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1319'
permalink: /2003/03/23/war-its-a-cultural-thang/
typo_id:
    - '1317'
mt_id:
    - '555'
link_related:
    - 'http://www.oreillynet.com/pub/wlg/2955'
raw_content:
    - 'Andy Oram:  How Bush made this his war'
categories:
    - Aside
---

Andy Oram: How Bush made this his war