---
id: 2511
title: 'Surrealist and other beautiful games'
date: '2004-09-05T12:36:13+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2511'
permalink: /2004/09/05/surrealist-and-other-beautiful-games/
typo_id:
    - '2509'
mt_id:
    - '2361'
link_related:
    - 'http://www.purselipsquarejaw.org/surrealist_games/index.php'
raw_content:
    - ''
categories:
    - Aside
tags:
    - games
---

