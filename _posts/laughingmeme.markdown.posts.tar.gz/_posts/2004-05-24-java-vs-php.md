---
id: 2286
title: 'Java vs. PHP'
date: '2004-05-24T12:36:48+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2286'
permalink: /2004/05/24/java-vs-php/
typo_id:
    - '2284'
mt_id:
    - '2054'
link_related:
    - 'http://rc3.org/cgi-bin/less.pl?arg=6262'
raw_content:
    - 'All languages suck.'
categories:
    - Aside
tags:
    - java
    - php
---

All languages suck.