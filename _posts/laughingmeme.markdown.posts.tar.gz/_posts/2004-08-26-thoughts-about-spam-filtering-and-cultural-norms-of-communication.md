---
id: 2490
title: 'Thoughts about spam filtering and cultural norms of communication'
date: '2004-08-26T17:51:21+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2490'
permalink: /2004/08/26/thoughts-about-spam-filtering-and-cultural-norms-of-communication/
typo_id:
    - '2488'
mt_id:
    - '2326'
link_related:
    - 'http://www.anarchogeek.com/archives/000426.html'
raw_content:
    - 'I\''ve also had false positives on the email from Uruguayans, which would make sense, they are mostly decedents of italian immigrants.'
categories:
    - Aside
tags:
    - communication
    - i18n
    - spam
---

I’ve also had false positives on the email from Uruguayans, which would make sense, they are mostly decedents of italian immigrants.