---
id: 3030
title: '&#8220;Bloop&#8221; is the name given to an underwater sound, first heard in 1997, of unknown, potentially biological, origins'
date: '2005-09-23T16:38:41+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3030'
permalink: /2005/09/23/bloop-is-the-name-given-to-an-underwater-sound-first-heard-in-1997-o-funknown-potentially-biological-origins/
typo_id:
    - '3028'
mt_id:
    - '3120'
link_related:
    - 'http://en.wikipedia.org/wiki/Bloop'
raw_content:
    - 'I **love** wikipedia'
categories:
    - Aside
tags:
    - biology
    - marine
    - st
    - wikipedia
---

I **love** wikipedia