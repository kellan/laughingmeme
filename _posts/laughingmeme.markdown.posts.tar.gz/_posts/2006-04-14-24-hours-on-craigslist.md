---
id: 3326
title: '24 hours on craigslist'
date: '2006-04-14T09:07:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3326'
permalink: /2006/04/14/24-hours-on-craigslist/
typo_id:
    - '3325'
mt_id:
    - ''
link_related:
    - 'http://24hoursoncraigslist.com/index.html'
raw_content:
    - 'Oddest premise for a movie ever?'
categories:
    - Aside
tags:
    - craigslist
    - film
    - movie
    - sf
---

Oddest premise for a movie ever?