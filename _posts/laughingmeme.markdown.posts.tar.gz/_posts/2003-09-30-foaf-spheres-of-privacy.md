---
id: 1759
title: 'FOAF Spheres of Privacy'
date: '2003-09-30T23:24:30+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1759'
permalink: /2003/09/30/foaf-spheres-of-privacy/
typo_id:
    - '1757'
mt_id:
    - '1268'
link_related:
    - 'http://www.stonecottage.com/josh/archives/000344.html'
raw_content:
    - 'Minimize the \''Here is my dossier; spam me, index me, and chain me to the wall\'' aspect of FOAF'
categories:
    - Aside
---

Minimize the ‘Here is my dossier; spam me, index me, and chain me to the wall’ aspect of FOAF