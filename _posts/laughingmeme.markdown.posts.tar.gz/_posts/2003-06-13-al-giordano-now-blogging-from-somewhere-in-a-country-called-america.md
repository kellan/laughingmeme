---
id: 1515
title: 'Al Giordano, now blogging from somewhere in a country called AmÃ©rica'
date: '2003-06-13T11:07:11+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1515'
permalink: /2003/06/13/al-giordano-now-blogging-from-somewhere-in-a-country-called-america/
typo_id:
    - '1513'
mt_id:
    - '854'
link_related:
    - 'http://www.bigleftoutside.com/'
raw_content:
    - 'Bringing it home after all this time'
categories:
    - Aside
---

Bringing it home after all this time