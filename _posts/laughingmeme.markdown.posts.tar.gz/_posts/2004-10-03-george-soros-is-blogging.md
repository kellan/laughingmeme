---
id: 2573
title: 'George Soros is blogging!'
date: '2004-10-03T12:35:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2573'
permalink: /2004/10/03/george-soros-is-blogging/
typo_id:
    - '2571'
mt_id:
    - '2446'
link_related:
    - 'http://georgesoros.com/index.cfm?Fuseaction=Home'
raw_content:
    - 'But with a ColdFusion based system?  Ugh.  Where is the OSI commitment to open source?'
categories:
    - Aside
tags:
    - blog
    - coldfusion
    - opensource
    - soros
---

But with a ColdFusion based system? Ugh. Where is the OSI commitment to open source?