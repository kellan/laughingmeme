---
id: 1219
title: 'Richard Dawkins: &#8220;Frankenfoods rock!&#8221;'
date: '2003-02-13T13:43:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1219'
permalink: /2003/02/13/richard-dawkins-frankenfoods-rock/
typo_id:
    - '1217'
mt_id:
    - '401'
link_related:
    - 'http://www.checkbiotech.org/root/index.cfm?fuseaction=news&doc_id=4575&start=1&control=173&page_start=1&page_nr=101&pg=1'
raw_content:
    - 'hoisted on the petard of metaphor as arguement fallacy'
categories:
    - Aside
---

hoisted on the petard of metaphor as arguement fallacy