---
id: 1609
title: 'Is that a wand in your pocket?'
date: '2003-07-19T16:06:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1609'
permalink: /2003/07/19/is-that-a-wand-in-your-pocket/
typo_id:
    - '1607'
mt_id:
    - '999'
link_related:
    - 'http://www.clockwork-harlequin.net/harry_potter/smut.html'
raw_content:
    - 'Sexual innuendo from Order of the Phoenix'
categories:
    - Aside
---

Sexual innuendo from Order of the Phoenix