---
id: 2273
title: 'Google solving the Gmail mailing list problem by reviving newsgroups?'
date: '2004-05-12T21:31:42+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2273'
permalink: /2004/05/12/google-solving-the-gmail-mailing-list-problem-by-reviving-newsgroups/
typo_id:
    - '2271'
mt_id:
    - '2035'
link_related:
    - 'http://groups-beta.google.com/'
raw_content:
    - 'new Google Groups (neÃ© DejaNews) interface encourages creating your own groups.'
categories:
    - Aside
tags:
    - collaboration
    - google
---

new Google Groups (neÃ© DejaNews) interface encourages creating your own groups.