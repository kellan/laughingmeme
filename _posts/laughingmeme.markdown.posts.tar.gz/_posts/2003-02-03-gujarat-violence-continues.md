---
id: 304
title: 'Gujarat Violence Continues'
date: '2003-02-03T19:04:19+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=304'
permalink: /2003/02/03/gujarat-violence-continues/
typo_id:
    - '302'
mt_id:
    - '354'
link_related:
    - ''
raw_content:
    - 'Dru continues to post timely updates <a href=\"http://misnomer.dru.ca/2003/02/03/gujarat.html\">on the other RSS</a>, perpetrators of the state sponsored terror against Muslims in the Indian state of Gujarat.'
---

Dru continues to post timely updates [on the other RSS](http://misnomer.dru.ca/2003/02/03/gujarat.html), perpetrators of the state sponsored terror against Muslims in the Indian state of Gujarat.