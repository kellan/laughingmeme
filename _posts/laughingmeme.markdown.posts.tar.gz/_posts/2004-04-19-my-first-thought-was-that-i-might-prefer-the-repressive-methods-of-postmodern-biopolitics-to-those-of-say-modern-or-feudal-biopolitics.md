---
id: 2220
title: '&#8220;My first thought was that I might prefer the repressive methods of postmodern biopolitics to those of, say, modern or feudal biopolitics.&#8221;'
date: '2004-04-19T18:56:16+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2220'
permalink: /2004/04/19/my-first-thought-was-that-i-might-prefer-the-repressive-methods-of-postmodern-biopolitics-to-those-of-say-modern-or-feudal-biopolitics/
typo_id:
    - '2218'
mt_id:
    - '1962'
link_related:
    - 'http://www.crookedtimber.org/archives/001718.html'
raw_content:
    - 'Who knows what it means, but I\''m so filing away for future use the phrase \''repressive methods of postmodern biopolitics\'''
categories:
    - Aside
tags:
    - quotable
---

Who knows what it means, but I’m so filing away for future use the phrase ‘repressive methods of postmodern biopolitics’