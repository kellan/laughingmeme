---
id: 1345
title: 'GeoInfo on the RdfWiki'
date: '2003-04-03T15:01:23+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1345'
permalink: /2003/04/03/geoinfo-on-the-rdfwiki/
typo_id:
    - '1343'
mt_id:
    - '599'
link_related:
    - 'http://esw.w3.org/topic/GeoInfo'
raw_content:
    - 'surveying the state of play'
categories:
    - Aside
---

surveying the state of play