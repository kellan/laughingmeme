---
id: 2656
title: 'Loving my new mini Obey Qee'
date: '2004-11-19T00:11:31+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2656'
permalink: /2004/11/19/loving-my-new-mini-obey-qee/
typo_id:
    - '2654'
mt_id:
    - '2563'
link_related:
    - 'http://www.kidrobot.com/gallery_detail.php?sku=6666'
raw_content:
    - 'Almost as much as my 3Zero doll'
categories:
    - Aside
tags:
    - toys
---

Almost as much as my 3Zero doll