---
id: 2738
title: 'Magpie now part of the WordPress core?'
date: '2005-01-02T14:47:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2738'
permalink: /2005/01/02/magpie-now-part-of-the-wordpress-core/
typo_id:
    - '2736'
mt_id:
    - '2676'
link_related:
    - 'http://cvs.sourceforge.net/viewcvs.py/cafelog/wordpress/wp-includes/rss-functions.php?rev=1.2&sortby=date&view=markup'
raw_content:
    - 'I wonder where that is going?'
categories:
    - Aside
tags:
    - magpie
    - rss
    - wordpress
---

I wonder where that is going?