---
id: 4230
title: '#2 Every Building with a Shoebox in it’s Basement'
date: '2009-04-17T07:00:00+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4230'
permalink: /2009/04/17/2-every-building-with-a-shoebox-in-it%e2%80%99s-basement/
link_related:
    - 'http://geobloggers.com/2009/04/17/2-every-building-with-a-shoebox-in-its-basement/'
categories:
    - Aside
tags:
    - data
    - flickr
    - 'fluffy clouds'
    - 'new cities'
    - photography
---

“Buildings could offer WiFi photo uploading service, in return for keeping the photos taken of them….… what if [Cloudgate](http://www.flickr.com/search/?q=cloudgate&l=cc&ct=6) were built with servers and wireless inside, right from the start, offering to consume the photos taken of it. You take a shot with a wireless enabled camera and it could store a copy for you. It’s building up a library of itself, in all seasons, in all weather. Meanwhile you, have a backup, findable by time and browsing, stored safely in the Cloud!”