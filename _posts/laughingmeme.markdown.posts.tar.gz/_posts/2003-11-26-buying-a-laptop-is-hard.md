---
id: 1893
title: 'Buying a laptop is hard?'
date: '2003-11-26T12:33:58+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1893'
permalink: /2003/11/26/buying-a-laptop-is-hard/
typo_id:
    - '1891'
mt_id:
    - '1479'
link_related:
    - 'http://tbray.org/ongoing/When/200x/2003/11/25/AppleIkea'
raw_content:
    - 'Funny, I walked into the San Jose Apple store, and just bought one.  And now I walk into the Apple store in Boston or Seattle for service.  Seems easy to me.'
categories:
    - Aside
tags:
    - boston
---

Funny, I walked into the San Jose Apple store, and just bought one. And now I walk into the Apple store in Boston or Seattle for service. Seems easy to me.