---
id: 160
title: 'A Pub/Sub Web?'
date: '2002-09-24T10:34:40+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=160'
permalink: /2002/09/24/a-pubsub-web/
typo_id:
    - '158'
mt_id:
    - '169'
link_related:
    - ''
raw_content:
    - "I\\'m seeing a few sites(\r\n<a href=\\\"http://diveintomark.org/archives/2002/09/23.html#now_heavily_medicated\\\">diveinto</a>,\r\n<a href=\\\"http://www.decafbad.com/news_archives/000292.phtml#000292\\\">decafbad</a>\r\n)\r\nlinking to <a href=\\\"http://www.hixie.ch/specs/pingback/pingback-1.0\\\">Pingback 1.0</a> this morning, which is supposed to fix the problems with <a href=\\\"http://www.moveabletype.org/trackback\\\">MT\\'s Trackback </a> system.  Don\\'t have time to look into it right now, must stay on task. (the Protest.net re-write is slowly, oh so slowly, gathering speed)  I am, however, struck, as always, by the amazing power of\r\n\r\n\r\n<a href=\\\"http://www.dreamsongs.com/WorseIsBetter.html\\\">WorseIsBetter</a>, and people\\'s insistence to bolt new functionality onto the sides of old protocols.  Wouldn\\'t it make more sense to build this sort of functionality on top of some sort of MOM?  Or at least a messaging framework like Jabber?  Nope, apparently not."
---

I’m seeing a few sites( [diveinto](http://diveintomark.org/archives/2002/09/23.html#now_heavily_medicated), [decafbad](http://www.decafbad.com/news_archives/000292.phtml#000292)) linking to [Pingback 1.0](http://www.hixie.ch/specs/pingback/pingback-1.0) this morning, which is supposed to fix the problems with [MT’s Trackback ](http://www.moveabletype.org/trackback) system. Don’t have time to look into it right now, must stay on task. (the Protest.net re-write is slowly, oh so slowly, gathering speed) I am, however, struck, as always, by the amazing power of

[WorseIsBetter](http://www.dreamsongs.com/WorseIsBetter.html), and people’s insistence to bolt new functionality onto the sides of old protocols. Wouldn’t it make more sense to build this sort of functionality on top of some sort of MOM? Or at least a messaging framework like Jabber? Nope, apparently not.