---
id: 2734
title: 'Interactive map of racial segregation in Boston'
date: '2005-01-01T17:05:31+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2734'
permalink: /2005/01/01/interactive-map-of-racial-segregation-in-boston/
typo_id:
    - '2732'
mt_id:
    - '2672'
link_related:
    - 'http://www.umich.edu/~lawrace/citymaps.htm/boston.htm'
raw_content:
    - ''
categories:
    - Aside
tags:
    - boston
    - race
---

