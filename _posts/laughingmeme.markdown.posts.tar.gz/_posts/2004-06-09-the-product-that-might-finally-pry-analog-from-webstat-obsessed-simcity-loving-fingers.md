---
id: 2316
title: 'The product that might finally pry analog from webstat-obsessed, SimCity-loving fingers?'
date: '2004-06-09T19:50:07+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2316'
permalink: /2004/06/09/the-product-that-might-finally-pry-analog-from-webstat-obsessed-simcity-loving-fingers/
typo_id:
    - '2314'
mt_id:
    - '2097'
link_related:
    - 'http://wired.com/news/technology/0,1282,63767,00.html?tw=wn_tophead_1'
raw_content:
    - 'Except its only for Windows'
categories:
    - Aside
---

Except its only for Windows