---
id: 2821
title: 'Haiku:  The stork brought three quarks'
date: '2005-02-15T15:38:47+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2821'
permalink: /2005/02/15/haiku-the-stork-brought-three-quarks/
typo_id:
    - '2819'
mt_id:
    - '2791'
link_related:
    - 'http://haiku.fuzrocks.com/discuss.php?id=3521'
raw_content:
    - 'up, down, strange, charmed, top, bottom...'
categories:
    - Aside
tags:
    - haiku
---

up, down, strange, charmed, top, bottom…