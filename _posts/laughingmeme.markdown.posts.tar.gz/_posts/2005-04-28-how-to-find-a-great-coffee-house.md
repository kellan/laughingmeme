---
id: 2929
title: 'How to Find a Great Coffee House'
date: '2005-04-28T11:11:52+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2929'
permalink: /2005/04/28/how-to-find-a-great-coffee-house/
typo_id:
    - '2927'
mt_id:
    - '2960'
link_related:
    - 'http://www.bloggle.com/coffee/2005/04/how-to-find-great-coffee-house.php'
raw_content:
    - 'Bloggle presents a short set of negative indicators for avoiding bad coffee'
categories:
    - Aside
tags:
    - cafe
    - coffee
    - coffeeshops
    - seattle
---

Bloggle presents a short set of negative indicators for avoiding bad coffee