---
id: 1484
title: 'Basic web colors for the Color Blind'
date: '2003-05-28T15:54:11+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1484'
permalink: /2003/05/28/basic-web-colors-for-the-color-blind/
typo_id:
    - '1482'
mt_id:
    - '807'
link_related:
    - 'http://www.toledo-bend.com/colorblind/'
raw_content:
    - 'Or otherwise color challenged [like me]'
categories:
    - Aside
---

Or otherwise color challenged \[like me\]