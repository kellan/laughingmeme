---
id: 2430
title: 'ExpressionEngine Plugin:  RSS/Atom parser'
date: '2004-08-03T13:36:41+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2430'
permalink: /2004/08/03/expressionengine-plugin-rssatom-parser/
typo_id:
    - '2428'
mt_id:
    - '2249'
link_related:
    - 'http://plugins.pmachine.com/index.php/browse/details/magpie/'
raw_content:
    - 'Magpie based'
categories:
    - Aside
tags:
    - magpie
---

Magpie based