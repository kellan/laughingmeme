---
id: 1393
title: 'Python Web Framework Shootout'
date: '2003-04-27T17:02:22+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1393'
permalink: /2003/04/27/python-web-framework-shootout/
typo_id:
    - '1391'
mt_id:
    - '676'
link_related:
    - 'http://colorstudy.com/web-framework/'
raw_content:
    - 'With real code samples, and good theory discussion'
categories:
    - Aside
---

With real code samples, and good theory discussion