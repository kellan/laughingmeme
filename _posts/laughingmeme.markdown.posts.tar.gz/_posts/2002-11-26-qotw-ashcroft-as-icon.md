---
id: 227
title: 'QOTW:  Ashcroft as Icon'
date: '2002-11-26T06:05:35+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=227'
permalink: /2002/11/26/qotw-ashcroft-as-icon/
typo_id:
    - '225'
mt_id:
    - '235'
link_related:
    - ''
raw_content:
    - "<a href=\\\"http://www.dashes.com/anil/index.php?archives/004092.php\\\">Anil Dash</a>:\n<blockquote>\nJohn Ashcroft is a visual icon representing \\\"we want to take your rights away\\\". I think they\\'re using him to represent the security options in future versions of Windows.\n</blockquote>\nAttached to a <a href=\\\"http://www.reuters.com/newsArticle.jhtml?type=topNews&storyID=1762254\\\">Secret Court OKs Broad Wiretap Powers</a>."
---

[Anil Dash](http://www.dashes.com/anil/index.php?archives/004092.php):

> John Ashcroft is a visual icon representing “we want to take your rights away”. I think they’re using him to represent the security options in future versions of Windows.

Attached to a [Secret Court OKs Broad Wiretap Powers](http://www.reuters.com/newsArticle.jhtml?type=topNews&storyID=1762254). 