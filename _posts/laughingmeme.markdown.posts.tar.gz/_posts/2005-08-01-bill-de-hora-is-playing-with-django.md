---
id: 2971
title: 'Bill de hora is playing with Django'
date: '2005-08-01T12:40:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2971'
permalink: /2005/08/01/bill-de-hora-is-playing-with-django/
typo_id:
    - '2969'
mt_id:
    - '3029'
link_related:
    - 'http://www.dehora.net/journal/2005/08/django_debugging_and_mvcp_frameworks.html'
raw_content:
    - 'I wonder if Django will get an RDF backend before Rails'
categories:
    - Aside
tags:
    - django
    - mvc
    - python
    - rails
    - rdf
    - ruby
    - semweb
---

I wonder if Django will get an RDF backend before Rails