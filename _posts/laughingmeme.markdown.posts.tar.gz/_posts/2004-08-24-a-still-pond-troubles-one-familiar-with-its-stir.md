---
id: 2486
title: 'a still pond troubles one familiar with its stir'
date: '2004-08-24T20:23:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2486'
permalink: /2004/08/24/a-still-pond-troubles-one-familiar-with-its-stir/
typo_id:
    - '2484'
mt_id:
    - '2321'
link_related:
    - 'http://spezzato.org/archives/000103.html'
raw_content:
    - 'ah! the koi are gone! (damn racoons)'
categories:
    - Aside
---

ah! the koi are gone! (damn racoons)