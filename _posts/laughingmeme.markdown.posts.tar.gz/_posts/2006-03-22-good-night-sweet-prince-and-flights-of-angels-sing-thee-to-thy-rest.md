---
id: 3301
title: 'Good night, sweet prince. And flights of angels sing thee to thy rest.'
date: '2006-03-22T10:51:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3301'
permalink: /2006/03/22/good-night-sweet-prince-and-flights-of-angels-sing-thee-to-thy-rest/
typo_id:
    - '3299'
mt_id:
    - ''
link_related:
    - 'http://sedesdraconis.livejournal.com/107932.html'
raw_content:
    - 'Bob Elliott, Shaman, Christian, Patriarch. born 1927.09.09, died 2006.03.21'
categories:
    - Aside
tags:
    - family
    - personal
---

Bob Elliott, Shaman, Christian, Patriarch. born 1927.09.09, died 2006.03.21