---
id: 2957
title: 'Bilbao from space'
date: '2005-06-27T11:08:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2957'
permalink: /2005/06/27/bilbao-from-space/
typo_id:
    - '2955'
mt_id:
    - '3010'
link_related:
    - 'http://www.googlesightseeing.com/2005/06/22/guggenheim-museum-bilbao/'
raw_content:
    - 'Google Sightseeing is amazing'
categories:
    - Aside
tags:
    - gehry
    - google
    - maps
    - photos
    - st
    - travel
---

Google Sightseeing is amazing