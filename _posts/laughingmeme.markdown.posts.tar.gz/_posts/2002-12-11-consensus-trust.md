---
id: 237
title: 'Consensus &#038; Trust'
date: '2002-12-11T07:19:09+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=237'
permalink: /2002/12/11/consensus-trust/
typo_id:
    - '235'
mt_id:
    - '245'
link_related:
    - ''
raw_content:
    - 'Zoe has posted her thesis, <a href=\"http://dc.indymedia.org/front.php3?article_id=42130&group=webcast\">A Critique of Consensus Process</a>, and Paul has posted <a href=\"http://www.mediageek.org/archives/001962.html#001962\">his response</a>.  Both excellent and worth reading.'
---

Zoe has posted her thesis, [A Critique of Consensus Process](http://dc.indymedia.org/front.php3?article_id=42130&group=webcast), and Paul has posted [his response](http://www.mediageek.org/archives/001962.html#001962). Both excellent and worth reading.