---
id: 25
title: 'I need to edit'
date: '2002-05-12T00:53:32+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=25'
permalink: /2002/05/12/i-need-to-edit/
typo_id:
    - '23'
mt_id:
    - '21'
link_related:
    - ''
raw_content:
    - "I edit my emails, I edit my letters, I sure as hell edit any article, essay, report, or assignment I write.  And I clearly need to start editting this blog.  I find myself saying in 2-3 long paragraphs what should be said in a few well sentences.  I think there is also something about this default MT template which is not as readable as it could be.  <a href=\\\"http://gus.protest.net\\\">Gus</a> claims to write a \\\"Strunk & White Friendly Blog\\\", but \nin my total failure to live up to such a sobriquet I can\\'t even claim the defense of style, \\\"I\\'m going for that accreted blog writing style, in which one layers paragraph on top of sentence, on top of list, hoping to capture some fragment of an idea, not planned, but evolved, gonzo blog writing, without any of the humor, allusions, drugs, imagery, metaphors, or interesting anecdotes implied therein.....\\\"\n<P>\nupdated 5 minutes later:<br>\nand I\\'m put to shame by <a href=\\\"http://leslie.harpold.com/\\\">Leslie Harpold</a> who <a href=\\\"http://leslie.harpold.com/presents/000026.html#000026\\\">notes that it took her 7 years to break down and write about writing</a>, alas I barely made it a month."
---

I edit my emails, I edit my letters, I sure as hell edit any article, essay, report, or assignment I write. And I clearly need to start editting this blog. I find myself saying in 2-3 long paragraphs what should be said in a few well sentences. I think there is also something about this default MT template which is not as readable as it could be. [Gus](http://gus.protest.net) claims to write a “Strunk &amp; White Friendly Blog”, but in my total failure to live up to such a sobriquet I can’t even claim the defense of style, “I’m going for that accreted blog writing style, in which one layers paragraph on top of sentence, on top of list, hoping to capture some fragment of an idea, not planned, but evolved, gonzo blog writing, without any of the humor, allusions, drugs, imagery, metaphors, or interesting anecdotes implied therein…..”

updated 5 minutes later:  
and I’m put to shame by [Leslie Harpold](http://leslie.harpold.com/) who [notes that it took her 7 years to break down and write about writing](http://leslie.harpold.com/presents/000026.html#000026), alas I barely made it a month.