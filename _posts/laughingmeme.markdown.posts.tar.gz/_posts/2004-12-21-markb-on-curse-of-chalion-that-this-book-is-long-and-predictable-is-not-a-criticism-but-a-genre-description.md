---
id: 2722
title: 'MarkB on Curse of Chalion, &#8220;that this book is long and predictable is not a criticism but a genre description.&#8221;'
date: '2004-12-21T12:20:16+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2722'
permalink: /2004/12/21/markb-on-curse-of-chalion-that-this-book-is-long-and-predictable-is-not-a-criticism-but-a-genre-description/
typo_id:
    - '2720'
mt_id:
    - '2658'
link_related:
    - 'http://markbernstein.org/Books19.html#The%20Curse%20Of%20Chalion'
raw_content:
    - 'Excellent notes on why I ambivalently love this book. (but its Spain, not Italy)'
categories:
    - Aside
tags:
    - books
    - bujold
    - quotable
---

Excellent notes on why I ambivalently love this book. (but its Spain, not Italy)