---
id: 549
title: 'Google Links'
date: '2003-08-07T08:48:34+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=549'
permalink: /2003/08/07/google-links/
typo_id:
    - '547'
mt_id:
    - '1061'
link_related:
    - ''
raw_content:
    - "<ul>\n<li>Rabble wants to knows why he is the <a href=\\\"http://www.anarchogeek.com/archives/000174.html\\\">top results for \\\"California Governors Recall\\\"</a>\n</li>\n<li>\nSteve thinks his <a href=\\\"http://minutillo.com/steve/weblog/2003/8/6/the-clearest-evidence-yet-that-google-is-busted\\\">ranking for \\\"feeds\\\"</a> is too high.\n</li>\n<li>\nJeremy thinks <a href=\\\"http://jeremy.zawodny.com/blog/archives/000911.html\\\">PageRank is still broken</a> (something he has written about before) based on his ranking for \\\"Schwarzenegger for governor\\\".\n</li>\n<li>\nPhil sticks to his position that Google is settling for <a href=\\\"\nhttp://philringnalda.com/blog/2003/08/google_does_have_a_problem_with_blogs.php\\\">the best it can find</a>.\n</li>\n</ul>"
---

- Rabble wants to knows why he is the [top results for “California Governors Recall”](http://www.anarchogeek.com/archives/000174.html)
- Steve thinks his [ranking for “feeds”](http://minutillo.com/steve/weblog/2003/8/6/the-clearest-evidence-yet-that-google-is-busted) is too high.
- Jeremy thinks [PageRank is still broken](http://jeremy.zawodny.com/blog/archives/000911.html) (something he has written about before) based on his ranking for “Schwarzenegger for governor”.
- Phil sticks to his position that Google is settling for [the best it can find](
    http://philringnalda.com/blog/2003/08/google_does_have_a_problem_with_blogs.php).