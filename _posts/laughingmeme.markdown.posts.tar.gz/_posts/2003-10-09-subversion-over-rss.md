---
id: 624
title: 'Subversion over RSS'
date: '2003-10-09T00:05:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=624'
permalink: /2003/10/09/subversion-over-rss/
typo_id:
    - '622'
mt_id:
    - '1304'
link_related:
    - ''
raw_content:
    - "<p>\r\nFrom the makers of Hydra, an eXSLT transformation that turns <a href=\\\"http://0x2a.no-ip.org/mt/archives/000044.html\\\">Subversion\\'s changelog into RSS</a>. (via <a href=\\\"http://ranchero.com/?comments=1&postid=833\\\">ranchero</a>)  I always said svn2rss was going to be more elegant then <a href=\\\"/cvs2rss\\\">cvs2rss</a>, but I never imagined it would be that unhackish.  Cleary the SVN folks are doing something right.\r\n</p>"
tags:
    - cvs2rss
    - rss
---

From the makers of Hydra, an eXSLT transformation that turns [Subversion’s changelog into RSS](http://0x2a.no-ip.org/mt/archives/000044.html). (via [ranchero](http://ranchero.com/?comments=1&postid=833)) I always said svn2rss was going to be more elegant then [cvs2rss](/cvs2rss), but I never imagined it would be that unhackish. Cleary the SVN folks are doing something right.