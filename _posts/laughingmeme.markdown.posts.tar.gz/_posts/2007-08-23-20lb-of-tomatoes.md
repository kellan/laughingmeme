---
id: 3700
title: '20lb of tomatoes'
date: '2007-08-23T02:48:36+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/08/23/20lb-of-tomatoes/'
permalink: /2007/08/23/20lb-of-tomatoes/
categories:
    - Uncategorized
tags:
    - food
    - personal
    - photo
    - tomato
---

[![](http://farm2.static.flickr.com/1135/1212281160_4b48314bb6.jpg)](http://www.flickr.com/photos/kellan/1212281160/ "photo sharing")

<span class="flickr-caption">[20lb of tomatoes](http://www.flickr.com/photos/kellan/1212281160/), originally uploaded by [kellan](http://www.flickr.com/people/kellan/).</span>