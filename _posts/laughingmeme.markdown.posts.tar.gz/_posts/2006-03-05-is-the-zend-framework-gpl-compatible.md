---
id: 3272
title: 'Is the Zend Framework GPL compatible?'
date: '2006-03-05T16:57:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3272'
permalink: /2006/03/05/is-the-zend-framework-gpl-compatible/
typo_id:
    - '3270'
mt_id:
    - ''
link_related:
    - 'http://blog.joshuaeichorn.com/archives/2006/03/05/zend-framework-license/'
raw_content:
    - 'Still in pre-release, but Joshua\''s initial research suggests no.'
categories:
    - Aside
tags:
    - gpl
    - opensource
    - php
---

Still in pre-release, but Joshua’s initial research suggests no.