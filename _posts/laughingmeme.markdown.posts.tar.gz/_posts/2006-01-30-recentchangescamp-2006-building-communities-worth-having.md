---
id: 3228
title: 'RecentChangesCamp 2006 &#8230; &#8220;Building communities worth having!&#8221;'
date: '2006-01-30T13:49:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3228'
permalink: /2006/01/30/recentchangescamp-2006-building-communities-worth-having/
typo_id:
    - '3226'
mt_id:
    - ''
link_related:
    - 'http://recentchangescamp.org/'
raw_content:
    - 'Love the slogan'
categories:
    - Aside
tags:
    - portland
    - unconference
    - wiki
---

Love the slogan