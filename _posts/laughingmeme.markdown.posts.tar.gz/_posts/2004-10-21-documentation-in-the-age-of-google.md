---
id: 938
title: 'Documentation in the Age of Google'
date: '2004-10-21T00:17:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=938'
permalink: /2004/10/21/documentation-in-the-age-of-google/
typo_id:
    - '936'
mt_id:
    - '2476'
link_related:
    - ''
raw_content:
    - "When I was in high school I put some work into my conscientious objector portfolio.  I let it slide after a few years when it became clear that <acronym=\\\"conscientious objector\\\">CO</acronym> status was probably going to remain a historical anomaly.\r\n\r\nHowever the BBC\\'s <a href=\\\"http://news.bbc.co.uk/2/hi/asia-pacific/3755154.stm\\\">\\\"Google saves journalist\\\"</a> story makes me think that perhaps the concept isn\\'t moot, but merely mutated like so much in this modern age.\r\n\r\n(alternate title:  \\\"You Shall Know Us by Our Pagerank\\\")"
tags:
    - google
    - identity
    - privacy
    - reputation
---

When I was in high school I put some work into my conscientious objector portfolio. I let it slide after a few years when it became clear that <acronym objector="">CO</acronym> status was probably going to remain a historical anomaly.

However the BBC’s [“Google saves journalist”](http://news.bbc.co.uk/2/hi/asia-pacific/3755154.stm) story makes me think that perhaps the concept isn’t moot, but merely mutated like so much in this modern age.

(alternate title: “You Shall Know Us by Our Pagerank”)