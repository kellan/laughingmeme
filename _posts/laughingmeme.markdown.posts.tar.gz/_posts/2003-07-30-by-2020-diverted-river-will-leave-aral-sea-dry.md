---
id: 1620
title: 'By 2020 diverted river will leave Aral sea dry'
date: '2003-07-30T08:47:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1620'
permalink: /2003/07/30/by-2020-diverted-river-will-leave-aral-sea-dry/
typo_id:
    - '1618'
mt_id:
    - '1024'
link_related:
    - 'http://www.ambiguous.org/archive.php3/2003/07/29#quinn2003729.3'
raw_content:
    - 'They make a desert and call it peace'
categories:
    - Aside
---

They make a desert and call it peace