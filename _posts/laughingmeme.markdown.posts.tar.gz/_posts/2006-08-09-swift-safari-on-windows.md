---
id: 3429
title: 'Swift: Safari on Windows'
date: '2006-08-09T18:55:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3429'
permalink: /2006/08/09/swift-safari-on-windows/
typo_id:
    - '3428'
mt_id:
    - ''
link_related:
    - 'http://factoryjoe.com/blog/2006/08/09/safari-on-windows/'
raw_content:
    - Sweet.
categories:
    - Aside
tags:
    - apple
    - opensource
    - safari
    - windows
---

Sweet.