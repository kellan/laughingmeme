---
id: 3116
title: 'A modest proposal from #rails-core'
date: '2005-11-17T20:10:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3116'
permalink: /2005/11/17/a-modest-proposal-from-rails-core/
typo_id:
    - '3114'
mt_id:
    - ''
link_related:
    - 'http://project.ioni.st/post/414#post-414'
raw_content:
    - 'after all we\''ve got our own versions of Array, and String!'
categories:
    - Aside
tags:
    - lisp
    - programming
    - rails
    - ruby
---

after all we’ve got our own versions of Array, and String!