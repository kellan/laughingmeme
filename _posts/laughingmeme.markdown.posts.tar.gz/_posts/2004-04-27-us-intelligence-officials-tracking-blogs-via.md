---
id: 2230
title: 'U.S. Intelligence officials tracking blogs</a> (<a href="http://waxy.org/links/">via'
date: '2004-04-27T16:31:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2230'
permalink: /2004/04/27/us-intelligence-officials-tracking-blogs-via/
typo_id:
    - '2228'
mt_id:
    - '1977'
link_related:
    - 'http://biz.yahoo.com/ibd/040427/tech_1.html'
raw_content:
    - 'Next time we want to track a meme we\''ll just file a FOIA request.'
categories:
    - Aside
tags:
    - blogs
    - spooks
---

Next time we want to track a meme we’ll just file a FOIA request.