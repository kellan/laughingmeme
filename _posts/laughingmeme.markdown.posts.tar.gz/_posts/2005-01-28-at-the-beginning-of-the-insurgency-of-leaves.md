---
id: 2790
title: '&#8220;at the beginning of the insurgency of leaves&#8221;'
date: '2005-01-28T18:58:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2790'
permalink: /2005/01/28/at-the-beginning-of-the-insurgency-of-leaves/
typo_id:
    - '2788'
mt_id:
    - '2751'
link_related:
    - 'http://www.hyperorg.com/backissues/joho-jan28-05.html#leaves'
raw_content:
    - 'If you\''ve been following the conversation nothing new here except the most beautiful bon mot I\''ve encountered in months, \''the insurgency of leaves\'''
categories:
    - Aside
tags:
    - decentralization
    - quotable
    - tags
---

If you’ve been following the conversation nothing new here except the most beautiful bon mot I’ve encountered in months, ‘the insurgency of leaves’