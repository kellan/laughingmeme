---
id: 3776
title: 'Amazon Developer Connection: Why S3 Failed'
date: '2008-02-19T10:09:43+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2008/02/19/amazon-developer-connection-why-s3-failed/'
permalink: /2008/02/19/amazon-developer-connection-why-s3-failed/
link_related:
    - 'http://developer.amazonwebservices.com/connect/message.jspa?messageID=79978#79978'
categories:
    - Aside
    - Uncategorized
tags:
    - amazon
    - aws
    - communication
    - 'fluffy clouds'
    - s3
    - transparency
---

The authentication cluster was overloaded, and improperly monitored. Complex systems are like that, never know where the problems will arise. Good clear communication, but it should have been on the \[AWS blog\](http://aws.typepad.com).