---
id: 3005
title: 'Q: What&#8217;s the difference between Iraq and Vietnam?'
date: '2005-09-01T19:27:07+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3005'
permalink: /2005/09/01/q-whats-the-difference-between-iraq-and-vietnam/
typo_id:
    - '3003'
mt_id:
    - '3079'
link_related:
    - 'http://www.hyperorg.com/blogger/mtarchive/004395.html'
raw_content:
    - 'A: Bush knew how to get out of Vietnam.'
categories:
    - Aside
tags:
    - bush
    - funny
    - humor
    - iraq
    - joke
    - politics
    - vietnam
---

A: Bush knew how to get out of Vietnam.