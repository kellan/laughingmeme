---
id: 4518
title: 'Wikimedia has a users RPE of 30mil'
date: '2010-02-16T17:43:49+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4518'
permalink: /2010/02/16/wikimedia-claims-a-users-rpe-of-30mil/
link_related:
    - 'http://strategy.wikimedia.org/wiki/Technology/en#Analysis'
categories:
    - Aside
tags:
    - programming
    - rpe
    - scale
---

“Wikimedia Foundation currently employs 14 technical people (not all of whom are developers). At 400 million readers/month (as of February 2010), that’s about 1 developer per 30 million users. Accounting for open source developers probably doesn’t change that ratio by an order of magnitude.” (not exactly apples to apples, but still interesting)