---
id: 4899
title: '&#8220;Sorry!  We did something wrong.&#8221; &#8211; Twitter, on suspending my account.'
date: '2011-06-02T14:44:23+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2011/06/02/sorry-we-did-something-wrong-twitter-on-suspending-my-account/'
permalink: /2011/06/02/sorry-we-did-something-wrong-twitter-on-suspending-my-account/
categories:
    - Uncategorized
---

[![](http://farm6.static.flickr.com/5228/5791093751_f0316710e1.jpg)](http://www.flickr.com/photos/kellan/5791093751/ "photo sharing")

Yes, you did. But I’ll mostly forgive it when you un-suspend my account.

For the record, I was attempting to re-follow \[Albert Wenger\](http://continuations.com/) (that subscription seemingly having been lost somewhere along the way) when they suspend my account. Apparently that was suspicious.

Wondering if I’ve got the lowest account number to be suspended or is this a common thing?

Note to self: we need to get back to working on decentralized communication technologies.

**update:** I’m back! Dunstan \[also got suspend\](http://twitter.com/#!/dunstan/status/76443358490402816), which makes it seem likely it was a bug affecting low numbered accounts.