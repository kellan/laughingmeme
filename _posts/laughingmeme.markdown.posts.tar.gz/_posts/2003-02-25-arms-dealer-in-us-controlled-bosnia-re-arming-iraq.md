---
id: 1252
title: 'Arms dealer in US controlled Bosnia re-arming Iraq?'
date: '2003-02-25T10:29:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1252'
permalink: /2003/02/25/arms-dealer-in-us-controlled-bosnia-re-arming-iraq/
typo_id:
    - '1250'
mt_id:
    - '452'
link_related:
    - 'http://talkingpointsmemo.com/feb0304.html#022403900pm'
raw_content:
    - 'Marash plays it without irony, heavy handed and hawk, but reading between the lines is so much more fun.'
categories:
    - Aside
---

Marash plays it without irony, heavy handed and hawk, but reading between the lines is so much more fun.