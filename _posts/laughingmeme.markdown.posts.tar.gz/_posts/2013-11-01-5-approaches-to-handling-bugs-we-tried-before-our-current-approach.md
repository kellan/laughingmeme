---
id: 5266
title: '5 Approaches to Handling Bugs We Tried Before Our Current Approach'
date: '2013-11-01T14:37:43+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=5266'
permalink: /2013/11/01/5-approaches-to-handling-bugs-we-tried-before-our-current-approach/
categories:
    - Uncategorized
---

- don’t write bugs
- once you write a piece of code you own it forever and your top priority is fixing the bugs in it
- assign teams to own every section of the site, allow them to make sure no unapproved changes happen to those areas
- have a bug fixing team
- delete all code over a year old, switch to a new language, rewrite it