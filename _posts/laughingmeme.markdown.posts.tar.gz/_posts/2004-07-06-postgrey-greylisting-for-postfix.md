---
id: 2367
title: 'postgrey: &#8216;greylisting&#8217; for postfix'
date: '2004-07-06T10:25:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2367'
permalink: /2004/07/06/postgrey-greylisting-for-postfix/
typo_id:
    - '2365'
mt_id:
    - '2164'
link_related:
    - 'http://www.sauria.com/blog/2004/07/05#1004'
raw_content:
    - 'Return transient errors to high volume mail sources.  Ted has a graph + Debian init script.'
categories:
    - Aside
tags:
    - debian
    - email
    - mail
    - postfix
    - spam
---

Return transient errors to high volume mail sources. Ted has a graph + Debian init script.