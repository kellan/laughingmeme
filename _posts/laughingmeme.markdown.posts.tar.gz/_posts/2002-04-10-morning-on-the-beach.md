---
id: 3
title: 'Morning on the beach'
date: '2002-04-10T16:56:26+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3'
permalink: /2002/04/10/morning-on-the-beach/
typo_id:
    - '1'
mt_id:
    - '2'
link_related:
    - ''
raw_content:
    - "I\\'m back at my parents house for the week, while I try to figure out what happens next.\nAfter 6 months in the fog of San Francisco, it is glorious in Santa Cruz.\nWe must have had a storm last night, as  millions of man-o-wars have washed up on\nSeacliffe beach.   Quarter sized, paper thin translucent jellies with half-circle\nsails, now in a thick dried out line along the beach like so much disposed\nsaran wrap. (or codoms) And big piles of kelp from the bottom of the bay,\nand 2 giant jellyfish, 14 inches across, and the waves were a blue-green\nwith the sun shining through them, like the bits of glass of you find\ntossed up on the sand."
tags:
    - santacruz
---

I’m back at my parents house for the week, while I try to figure out what happens next. After 6 months in the fog of San Francisco, it is glorious in Santa Cruz. We must have had a storm last night, as millions of man-o-wars have washed up on Seacliffe beach. Quarter sized, paper thin translucent jellies with half-circle sails, now in a thick dried out line along the beach like so much disposed saran wrap. (or codoms) And big piles of kelp from the bottom of the bay, and 2 giant jellyfish, 14 inches across, and the waves were a blue-green with the sun shining through them, like the bits of glass of you find tossed up on the sand.