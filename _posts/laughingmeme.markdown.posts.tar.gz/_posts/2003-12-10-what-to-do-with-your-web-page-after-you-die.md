---
id: 1935
title: 'What to do with your web page after you die?'
date: '2003-12-10T15:10:50+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1935'
permalink: /2003/12/10/what-to-do-with-your-web-page-after-you-die/
typo_id:
    - '1933'
mt_id:
    - '1533'
link_related:
    - 'http://rc3.org/cgi-bin/less.pl?arg=5815'
raw_content:
    - 'Haven\''t thought about this much, but now I probably will at those odd in between times when thoughts wander to the morbid. Jee, thanks Rafe.'
categories:
    - Aside
---

Haven’t thought about this much, but now I probably will at those odd in between times when thoughts wander to the morbid. Jee, thanks Rafe.