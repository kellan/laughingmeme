---
id: 1376
title: 'Cable beats DSL in speed race'
date: '2003-04-24T10:55:22+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1376'
permalink: /2003/04/24/cable-beats-dsl-in-speed-race/
typo_id:
    - '1374'
mt_id:
    - '651'
link_related:
    - 'http://news.com.com/2100-1034-997831.html?tag=fd_ots'
raw_content:
    - 'My parents 56k dial up is faster then Verizon DSL in Boston.  No joke.'
categories:
    - Aside
tags:
    - boston
---

My parents 56k dial up is faster then Verizon DSL in Boston. No joke.