---
id: 3899
title: 'Leonard for Obama &#8217;08'
date: '2008-06-24T10:19:02+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=3899'
permalink: /2008/06/24/leonard-for-obama-08/
link_related:
    - 'http://randomfoo.net/blog/id/4187'
categories:
    - Aside
tags:
    - friends
    - lhl
    - nptech
    - obama
    - politics
    - tech
---

Congratulations to the Obama campaign, this is going to be awesome.