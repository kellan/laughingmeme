---
id: 2238
title: '1 year, 600 U.S. deaths, and uncounted Iraqi deaths since &#8220;Mission Accomplished&#8221;.'
date: '2004-05-01T04:10:57+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2238'
permalink: /2004/05/01/1-year-600-us-deaths-and-uncounted-iraqi-deaths-since-mission-accomplished/
typo_id:
    - '2236'
mt_id:
    - '1989'
link_related:
    - 'http://seattletimes.nwsource.com/html/nationworld/2001917522_bushiraq01.html'
raw_content:
    - 'So fly a banner, a stick a sock in your jump suit, and ignore the lack of any progressive towards a democractic society in Iraq.'
categories:
    - Aside
tags:
    - iraq
---

So fly a banner, a stick a sock in your jump suit, and ignore the lack of any progressive towards a democractic society in Iraq.