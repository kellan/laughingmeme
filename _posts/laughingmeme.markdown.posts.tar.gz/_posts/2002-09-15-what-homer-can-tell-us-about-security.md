---
id: 152
title: 'What Homer can tell us about Security'
date: '2002-09-15T17:04:52+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=152'
permalink: /2002/09/15/what-homer-can-tell-us-about-security/
typo_id:
    - '150'
mt_id:
    - '161'
link_related:
    - ''
raw_content:
    - "<blockquote>\r\nPolyphemus\\'s one eye is a single point of failure; when Odysseus pokes \r\nit out, he is much less able to defend himself.  Polyphemus\\'s alarm is \r\nignored because Odysseus said his name was Nobody, so he winds up \r\nshouting that nobody is trying to kill him (you\\'d think the other \r\nCyclopes would come see what\\'s going on, but maybe Polyphemus shouts \r\nrandom stupid things all the time, like an IDS).  Polyphemus finally \r\nhas to let the sheep out to graze -- it\\'s a mission-critical function \r\n-- and Odysseus and his men then escape by masquerading as legitimate \r\ntraffic (sheep). [via <a href=\\\"http://www.counterpane.com/crypto-gram.html\\\">Crypto-Gram</a>]\r\n\r\n</blockquote>"
tags:
    - security
---

> Polyphemus’s one eye is a single point of failure; when Odysseus pokes it out, he is much less able to defend himself. Polyphemus’s alarm is ignored because Odysseus said his name was Nobody, so he winds up shouting that nobody is trying to kill him (you’d think the other Cyclopes would come see what’s going on, but maybe Polyphemus shouts random stupid things all the time, like an IDS). Polyphemus finally has to let the sheep out to graze — it’s a mission-critical function — and Odysseus and his men then escape by masquerading as legitimate traffic (sheep). \[via [Crypto-Gram](http://www.counterpane.com/crypto-gram.html)\]