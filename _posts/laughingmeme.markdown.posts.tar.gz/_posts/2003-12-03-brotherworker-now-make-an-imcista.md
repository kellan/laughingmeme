---
id: 1911
title: 'Brotherworker now make an Imcista'
date: '2003-12-03T18:58:03+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1911'
permalink: /2003/12/03/brotherworker-now-make-an-imcista/
typo_id:
    - '1909'
mt_id:
    - '1500'
link_related:
    - 'http://kidrobot.com/detail.php?sku=MONY&#38;image=4'
raw_content:
    - 'Camera? check.  Cellphone? check.  Laptop? check.  Gasmask?  check.  Make sure to click \''more pictures\'''
categories:
    - Aside
---

Camera? check. Cellphone? check. Laptop? check. Gasmask? check. Make sure to click ‘more pictures’