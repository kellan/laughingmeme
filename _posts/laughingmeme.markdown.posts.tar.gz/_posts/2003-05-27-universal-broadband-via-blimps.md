---
id: 1482
title: 'Universal broadband via blimps?'
date: '2003-05-27T16:31:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1482'
permalink: /2003/05/27/universal-broadband-via-blimps/
typo_id:
    - '1480'
mt_id:
    - '804'
link_related:
    - 'http://news.bbc.co.uk/2/hi/technology/2932806.stm'
raw_content:
    - 'Death to copper!  [via benhammersly]'
categories:
    - Aside
---

Death to copper! \[via benhammersly\]