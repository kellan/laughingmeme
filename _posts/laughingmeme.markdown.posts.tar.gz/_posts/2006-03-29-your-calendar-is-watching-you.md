---
id: 3308
title: 'Your Calendar is Watching You'
date: '2006-03-29T14:32:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3308'
permalink: /2006/03/29/your-calendar-is-watching-you/
typo_id:
    - '3307'
mt_id:
    - ''
link_related:
    - 'http://30boxes.com/blog/index.php/2006/03/29/whats-the-weather/'
raw_content:
    - "Calendars are not interesting because they show us a grid of dates with things happening.  Calendars are interesting because more then our inbox, more then our todo lists, more then ourcontacts, more then our phones, they know things about us.  They fundamentally intersect the social and the geophysical.  If I\\'m attending an event (say [in Austin](http://laughingmeme.org/articles/2006/03/10/sxsw-back-on)) you have a powerful hint about when and where I am to a degree inaccessible to other facets of my digital support system.  \r\n\r\nAll of which is an overblown way of saying [30Boxes](http://30boxes.com) are smart, and seem to be the *only* people doing calendaring that [seem to get calendars](http://30boxes.com/blog/index.php/2006/03/29/whats-the-weather/), or the next rev. of the social web for that matter."
tags:
    - 30boxes
    - calendaring
    - personal
    - semweb
    - social
---

Calendars are not interesting because they show us a grid of dates with things happening. Calendars are interesting because more then our inbox, more then our todo lists, more then ourcontacts, more then our phones, they know things about us. They fundamentally intersect the social and the geophysical. If I’m attending an event (say \[in Austin\](http://laughingmeme.org/articles/2006/03/10/sxsw-back-on)) you have a powerful hint about when and where I am to a degree inaccessible to other facets of my digital support system.

All of which is an overblown way of saying \[30Boxes\](http://30boxes.com) are smart, and seem to be the *only* people doing calendaring that \[seem to get calendars\](http://30boxes.com/blog/index.php/2006/03/29/whats-the-weather/), or the next rev. of the social web for that matter.