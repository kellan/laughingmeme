---
id: 1787
title: 'Bush, 5-Year-Old Girl Begin &#8220;Moral Compass&#8221; Project'
date: '2003-10-16T01:13:33+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1787'
permalink: /2003/10/16/bush-5-year-old-girl-begin-moral-compass-project/
typo_id:
    - '1785'
mt_id:
    - '1320'
link_related:
    - 'http://www.rockonaspring.com/?page=soc-06'
raw_content:
    - 'Rockonaspring, site most desperately in need of an RSS feed?'
categories:
    - Aside
---

Rockonaspring, site most desperately in need of an RSS feed?