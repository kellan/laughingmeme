---
id: 3963
title: 'Google Will Eat Itself'
date: '2008-08-12T10:16:46+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=3963'
permalink: /2008/08/12/google-will-eat-itself/
link_related:
    - 'http://gwei.org/'
categories:
    - Aside
tags:
    - adsense
    - 'but is it art'
    - google
---

Now thats what I call topically relevant art.