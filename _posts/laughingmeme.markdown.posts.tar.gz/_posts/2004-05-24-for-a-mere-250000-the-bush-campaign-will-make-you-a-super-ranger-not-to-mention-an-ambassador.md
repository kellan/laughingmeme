---
id: 2291
title: 'For a mere $250,000 the Bush campaign will make you a Super Ranger (not to mention an ambassador)'
date: '2004-05-24T20:20:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2291'
permalink: /2004/05/24/for-a-mere-250000-the-bush-campaign-will-make-you-a-super-ranger-not-to-mention-an-ambassador/
typo_id:
    - '2289'
mt_id:
    - '2060'
link_related:
    - 'http://observer.guardian.co.uk/international/story/0,6903,1222706,00.html?=rss'
raw_content:
    - 'But how much to be a Power Ranger?'
categories:
    - Aside
tags:
    - gwbush
---

But how much to be a Power Ranger?