---
id: 1745
title: 'search.cpan.org: Acme::VerySign &#8211; make unused subroutines useful'
date: '2003-09-26T12:16:28+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1745'
permalink: /2003/09/26/searchcpanorg-acmeverysign-make-unused-subroutines-useful/
typo_id:
    - '1743'
mt_id:
    - '1245'
link_related:
    - 'http://search.cpan.org/dist/Acme-VerySign/lib/Acme/VerySign.pm'
raw_content:
    - 'try the new Perl \''codefinder\'' service.'
categories:
    - Aside
---

try the new Perl ‘codefinder’ service.