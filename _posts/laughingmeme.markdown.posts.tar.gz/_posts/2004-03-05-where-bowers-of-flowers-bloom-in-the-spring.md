---
id: 762
title: 'Where Bowers of Flowers Bloom in the Spring'
date: '2004-03-05T12:57:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=762'
permalink: /2004/03/05/where-bowers-of-flowers-bloom-in-the-spring/
typo_id:
    - '760'
mt_id:
    - '1818'
link_related:
    - ''
raw_content:
    - "You know things have gotten pretty bad when you find yourself looking forward to a week under the clear blue skies of warm and sunny San Francisco.\r\n\r\n<b>update:</b> turns out I wasn\\'t kidding.  Record setting heats.  In the 80s! (its still SF)"
tags:
    - sanfran
    - weather
---

You know things have gotten pretty bad when you find yourself looking forward to a week under the clear blue skies of warm and sunny San Francisco.

**update:** turns out I wasn’t kidding. Record setting heats. In the 80s! (its still SF)