---
id: 1114
title: 'Google Talk'
date: '2005-08-24T16:35:57+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1114'
permalink: /2005/08/24/google-talk/
typo_id:
    - '1112'
mt_id:
    - '3063'
link_related:
    - ''
raw_content:
    - "I\\'m sure the VOIP integration will be a long term interesting feature of [Google Talk](http://www.google.com/talk/), but today the transformative experience is that my contact list just tripled as the number of people whose Gmail address I know is several orders of magnitude larger then the set of people\\'s IM names.\n\nThat and the choice of Jabber means, a comparatively transparent experience of participating in the new system."
tags:
    - 0day
    - google
    - jabber
    - skype
---

I’m sure the VOIP integration will be a long term interesting feature of \[Google Talk\](http://www.google.com/talk/), but today the transformative experience is that my contact list just tripled as the number of people whose Gmail address I know is several orders of magnitude larger then the set of people’s IM names.

That and the choice of Jabber means, a comparatively transparent experience of participating in the new system.