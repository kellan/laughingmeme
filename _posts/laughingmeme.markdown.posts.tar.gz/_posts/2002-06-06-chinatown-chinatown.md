---
id: 45
title: 'Chinatown <-> Chinatown'
date: '2002-06-06T14:19:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=45'
permalink: /2002/06/06/chinatown-chinatown/
typo_id:
    - '43'
mt_id:
    - '41'
link_related:
    - ''
raw_content:
    - "I heard rumors when I lived in Boston, of a bus that ran from Boston\\'s Chinatown, to New York\\'s Chinatown, and back again.\r\n<p>\r\nUseful to be sure as I was (and am) dating a girl who lived in New York.  However I was doing that <a href=\\\"http://my.palm.com\\\">dotcom thang</a> and it always seemed \r\nsimpler to simply take Peter Pan (or once fly) then deal with figuring out something new.\r\n<p>\r\nNow, I\\'m back on the East Coast for a few weeks, needing to get to Boston, and here is what I\\'ve found.\r\n<ul>\r\n<li><a href=\\\"http://www.nyc24.com/issue02/story02/index.asp\\\">An article on a variety of ethnic bus/van services</a>\r\n<li><a href=\\\"http://hcs.harvard.edu/~gsc/guide/life_cb/travel.html#nyc\\\">A reccomendation from Harvard</a> to try Sunshire travel (now defunct)\r\n<li>And the option to <a href=\\\"http://www.ivymedia.com/bus/\\\">purchase said tickets online</a>\r\n</ul>\r\n\r\nIts appears that the bus departs about every hour and half, costs either $15 or $25, and in New York at least leaves from 97 Bowery St.\r\n<P>\r\nFurther updates tomorrow on the reality of the situation.\r\n<p>\r\n<b>UPDATE:</b>  It works great, though I admit to breaking down and taking Peter Pan on my most recent trip from NYC to Boston, as it was raining, and I was carrying a heavy bag, and Port Authority was significantly more convient then the Bowery. The Boston pickup/drop-off location is, however, very convient to the orange line Chinatown stop.  \r\n</p>\r\n<p>\r\nMore info at <a href=\\\"http://www.travelpackusa.com/bus-service.htm\\\">Travelpack USA Chinatown Bus website</a>.  Make sure to really look at the schedule, depending on the time of day, fares very from $10-$25 one way (still half of Peter Pan at its most expensive) and you might be on a full sized \\\"motor coach\\\" or one of those vans that the gypsy bus operators run over the George Washington Bridge. (the same ones Lift Line uses, if you\\'ve never commuted over the GWB)  But I would reccomend against buying the tickets online as the buses sometimes fill up.\r\n</p>"
tags:
    - boston
    - chinatown
    - nyc
    - tip
---

I heard rumors when I lived in Boston, of a bus that ran from Boston’s Chinatown, to New York’s Chinatown, and back again.

Useful to be sure as I was (and am) dating a girl who lived in New York. However I was doing that [dotcom thang](http://my.palm.com) and it always seemed simpler to simply take Peter Pan (or once fly) then deal with figuring out something new.

Now, I’m back on the East Coast for a few weeks, needing to get to Boston, and here is what I’ve found.

- [An article on a variety of ethnic bus/van services](http://www.nyc24.com/issue02/story02/index.asp)
- [A reccomendation from Harvard](http://hcs.harvard.edu/~gsc/guide/life_cb/travel.html#nyc) to try Sunshire travel (now defunct)
- And the option to [purchase said tickets online](http://www.ivymedia.com/bus/)

Its appears that the bus departs about every hour and half, costs either $15 or $25, and in New York at least leaves from 97 Bowery St.

Further updates tomorrow on the reality of the situation.

**UPDATE:** It works great, though I admit to breaking down and taking Peter Pan on my most recent trip from NYC to Boston, as it was raining, and I was carrying a heavy bag, and Port Authority was significantly more convient then the Bowery. The Boston pickup/drop-off location is, however, very convient to the orange line Chinatown stop.

More info at [Travelpack USA Chinatown Bus website](http://www.travelpackusa.com/bus-service.htm). Make sure to really look at the schedule, depending on the time of day, fares very from $10-$25 one way (still half of Peter Pan at its most expensive) and you might be on a full sized “motor coach” or one of those vans that the gypsy bus operators run over the George Washington Bridge. (the same ones Lift Line uses, if you’ve never commuted over the GWB) But I would reccomend against buying the tickets online as the buses sometimes fill up.