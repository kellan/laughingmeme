---
id: 3724
title: 'NYTimes: &#8220;a Greenlandic supermarket is stocking locally grown cauliflower, broccoli and cabbage this year for the first time.&#8221;'
date: '2007-10-28T09:55:34+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/10/28/nytimes-a-greenlandic-supermarket-is-stocking-locally-grown-cauliflower-broccoli-and-cabbage-this-year-for-the-first-time/'
permalink: /2007/10/28/nytimes-a-greenlandic-supermarket-is-stocking-locally-grown-cauliflower-broccoli-and-cabbage-this-year-for-the-first-time/
link_related:
    - 'http://www.nytimes.com/2007/10/28/world/europe/28greenland.html'
categories:
    - Aside
    - Uncategorized
tags:
    - 'climate change'
    - greenland
    - nytimes
---

Remember all those jokes about buying up cheap land in the far north quick before it warms up?