---
id: 529
title: 'A New Literate Programming?'
date: '2003-07-25T00:24:22+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=529'
permalink: /2003/07/25/a-new-literate-programming/
typo_id:
    - '527'
mt_id:
    - '1016'
link_related:
    - ''
raw_content:
    - 'Klog talks about having CVS checkins transformed into <a href=\"http://dijest.com/aka/2003/07/20.html#a2489\">a development blog</a>.  This is the same idea I was playing with when I created <a href=\"http://laughingmeme.org/cvs2rss/\">cvs2rss</a>, though I agree <a href=\"http://www.sauria.com/blog/2003/07/21#389\">with Ted</a>, it would better built on <a href=\"http://subversion.tigris.org/\">Subversion</a>.  Strangely enough by the time I had the RSS, I no longer wanted a blog.  However if it wasn\''t just a blog, but one of those blog/wiki hybrid things that allowed the cvs notes to form the kernel from which documentation grew, then that would be interesting.  Kevin also wants more information from his development project, but in the form of a <a href=\"http://www.peerfear.org/rss/permalink/2003/07/23/LuceneForSourceManagement/\">Lucene index</a> of his source code.  Neat.'
---

Klog talks about having CVS checkins transformed into [a development blog](http://dijest.com/aka/2003/07/20.html#a2489). This is the same idea I was playing with when I created [cvs2rss](http://laughingmeme.org/cvs2rss/), though I agree [with Ted](http://www.sauria.com/blog/2003/07/21#389), it would better built on [Subversion](http://subversion.tigris.org/). Strangely enough by the time I had the RSS, I no longer wanted a blog. However if it wasn’t just a blog, but one of those blog/wiki hybrid things that allowed the cvs notes to form the kernel from which documentation grew, then that would be interesting. Kevin also wants more information from his development project, but in the form of a [Lucene index](http://www.peerfear.org/rss/permalink/2003/07/23/LuceneForSourceManagement/) of his source code. Neat.