---
id: 3644
title: 'kev/null: Iminlikewithyou and Game Design in the Web'
date: '2007-05-28T14:29:36+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/05/28/kevnull-iminlikewithyou-and-game-design-in-the-web/'
permalink: /2007/05/28/kevnull-iminlikewithyou-and-game-design-in-the-web/
link_related:
    - 'http://kevnull.com/2007/05/iminlikewithyou-and-game-design-in-the-web.html'
categories:
    - Aside
    - Uncategorized
tags:
    - collaboration
    - 'game design'
    - iminlikewithyou
    - social
    - web
    - 'web 2.0'
---

I’ve reached the point where I enjoy more reading about sites then using them. Hmmm