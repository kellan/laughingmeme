---
id: 554
title: 'Brief Weather RSS (un)Update'
date: '2003-08-14T11:27:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=554'
permalink: /2003/08/14/brief-weather-rss-unupdate/
typo_id:
    - '552'
mt_id:
    - '1083'
link_related:
    - ''
raw_content:
    - "<p>\r\nStill doesn\\'t work with US cities, stop subscribing to those feeds.  All you\\'ll see is 2 month old data for Providence, RI.\r\n</p>\r\n<p>\r\nFeedback would be really helpful, for example, one of the most commonly requested feeds <a href=\\\"http://laughingmeme.org/weather-rss/united_kingdom/bristol.rss\\\">Bristol, UK</a> doesn\\'t work at all.  Your responsibility as beta-testers of an experimental tool is to tell me these things.\r\n</p>\r\n<p>\r\nThis has been a pre-coffee blogging session.\r\n</p>"
tags:
    - rss
    - weather
---

Still doesn’t work with US cities, stop subscribing to those feeds. All you’ll see is 2 month old data for Providence, RI.

Feedback would be really helpful, for example, one of the most commonly requested feeds [Bristol, UK](http://laughingmeme.org/weather-rss/united_kingdom/bristol.rss) doesn’t work at all. Your responsibility as beta-testers of an experimental tool is to tell me these things.

This has been a pre-coffee blogging session.