---
id: 12
title: 'Many talented'
date: '2002-04-26T12:07:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=12'
permalink: /2002/04/26/many-talented/
typo_id:
    - '10'
mt_id:
    - '11'
link_related:
    - ''
raw_content:
    - "<p>\r\n<a href=\\\"http://groups.google.com/groups?as_ugroup=comp.lang.python&as_uauthors=mark%20shuttleworth\\\">hack python</a>,\r\n<a href=\\\"http://news.bbc.co.uk/hi/english/world/africa/newsid_720000/720735.stm\\\">make money</a>,\r\n<a href=\\\"http://www.cnn.com/2002/TECH/space/04/27/space.docking/index.html\\\">fly to the ISS</a>  \r\n<p>\r\nAlso: <a href=\\\"http://m1.mny.co.za/422567C400479FB3/$All/C2256907002CDE5142256A56004BC9D5?OpenDocument\\\">get slammed for abandoning your country</a>"
tags:
    - python
    - space
---

[hack python](http://groups.google.com/groups?as_ugroup=comp.lang.python&as_uauthors=mark%20shuttleworth), [make money](http://news.bbc.co.uk/hi/english/world/africa/newsid_720000/720735.stm), [fly to the ISS](http://www.cnn.com/2002/TECH/space/04/27/space.docking/index.html)

Also: [get slammed for abandoning your country](http://m1.mny.co.za/422567C400479FB3/$All/C2256907002CDE5142256A56004BC9D5?OpenDocument)