---
id: 3356
title: 'Bush: &#8220;The best moment of my presidency was catching a perch on my lake&#8221;'
date: '2006-05-10T09:46:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3356'
permalink: /2006/05/10/bush-the-best-moment-of-my-presidency-was-catching-a-perch-on-my-lake/
typo_id:
    - '3355'
mt_id:
    - ''
link_related:
    - 'http://msnbc.msn.com/id/12683890/'
raw_content:
    - 'Like [Rafe](http://rc3.org) said, something the President and I can agree upon.  Make sure to [vote in the poll](http://msnbc.msn.com/id/12684392/)'
categories:
    - Aside
tags:
    - bush
    - politics
    - quotable
---

Like \[Rafe\](http://rc3.org) said, something the President and I can agree upon. Make sure to \[vote in the poll\](http://msnbc.msn.com/id/12684392/)