---
id: 203
title: 'Providence, Birthdays, Etc.'
date: '2002-11-12T18:52:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=203'
permalink: /2002/11/12/providence-birthdays-etc/
typo_id:
    - '201'
mt_id:
    - '218'
link_related:
    - ''
raw_content:
    - "<p>\r\nSorry to be so quiet.  Moved my transient life to Providence for a few days.  The public library has an open wireless access point, but I only stopped in briefly.  Seems like a tight community;  the same people we met over <a href=\\\"http://www.juliansprovidence.com/\\\">breakfast</a>(highly reccomended!), were at the \r\n<a href=\\\"http://www.as220.org/goulis/whitelec.html\\\">coffee shop</a> (very cool)  and the art opening, and the <a href=\\\"http://www.hrw.org/iff/2002/\\\">film festival</a>.  The leaves still had color.  The storm that tore across the rest of the country was content with merely drenching Providene, after a day of unseasonable warm.  Rolled down hills, and through leaves, and stood in the middle of a pond in Roger Williams park talking politics, and relationships with old friends.  \r\n</p>\r\n<p>\r\n<h3>Happy Armistice Day (belated)</h3>\r\nI\\'m 25 as of yesterday.  I can\\'t say it seems much different.  Perhaps the strangest expirence of all was talking with the <a href=\\\"http://www.fivecolleges.edu\\\">Five Colleges, Inc</a> today, and realizing that I\\'ve been working with these people, and writing calendar software for them since I was 20.\r\n</p>"
---

Sorry to be so quiet. Moved my transient life to Providence for a few days. The public library has an open wireless access point, but I only stopped in briefly. Seems like a tight community; the same people we met over [breakfast](http://www.juliansprovidence.com/)(highly reccomended!), were at the [coffee shop](http://www.as220.org/goulis/whitelec.html) (very cool) and the art opening, and the [film festival](http://www.hrw.org/iff/2002/). The leaves still had color. The storm that tore across the rest of the country was content with merely drenching Providene, after a day of unseasonable warm. Rolled down hills, and through leaves, and stood in the middle of a pond in Roger Williams park talking politics, and relationships with old friends.

### Happy Armistice Day (belated)

I’m 25 as of yesterday. I can’t say it seems much different. Perhaps the strangest expirence of all was talking with the [Five Colleges, Inc](http://www.fivecolleges.edu) today, and realizing that I’ve been working with these people, and writing calendar software for them since I was 20. 