---
id: 3164
title: 'TimBL: &#8220;So I am going to try this blog thing using blog tools.&#8221;'
date: '2005-12-15T07:37:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3164'
permalink: /2005/12/15/timbl-so-i-am-going-to-try-this-blog-thing-using-blog-tools/
typo_id:
    - '3162'
mt_id:
    - ''
link_related:
    - 'http://dig.csail.mit.edu/breadcrumbs/blog/4'
raw_content:
    - 'And written using PHP (Drupal) and such vs. Amaya/RDF'
categories:
    - Aside
tags:
    - blogging
    - drupal
    - timbl
    - w3c
---

And written using PHP (Drupal) and such vs. Amaya/RDF