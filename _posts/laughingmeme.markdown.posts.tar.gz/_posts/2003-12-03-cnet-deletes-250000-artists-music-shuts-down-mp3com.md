---
id: 1912
title: 'CNET deletes 250,000 artists music, shuts down MP3.com'
date: '2003-12-03T19:55:57+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1912'
permalink: /2003/12/03/cnet-deletes-250000-artists-music-shuts-down-mp3com/
typo_id:
    - '1910'
mt_id:
    - '1502'
link_related:
    - 'http://www.theregister.co.uk/content/6/34306.html'
raw_content:
    - 'As much as my history with mp3.com is ambivalent this is a tragedy.'
categories:
    - Aside
---

As much as my history with mp3.com is ambivalent this is a tragedy.