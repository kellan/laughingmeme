---
id: 2009
title: 'Iain &#8220;Spoon&#8221; Truskett passed away.'
date: '2004-01-18T15:33:02+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2009'
permalink: /2004/01/18/iain-spoon-truskett-passed-away/
typo_id:
    - '2007'
mt_id:
    - '1649'
link_related:
    - 'http://iain.truskett.id.au/'
raw_content:
    - 'A fellow Kwiki, and DateTime hacker, I was in the process of writing him an email when I found out.'
categories:
    - Aside
---

A fellow Kwiki, and DateTime hacker, I was in the process of writing him an email when I found out.