---
id: 2827
title: '43 Folders: Five fast email productivity tips'
date: '2005-02-16T10:12:27+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2827'
permalink: /2005/02/16/43-folders-five-fast-email-productivity-tips/
typo_id:
    - '2825'
mt_id:
    - '2797'
link_related:
    - 'http://www.43folders.com/2005/02/five_fast_email.html'
raw_content:
    - 'All good plus a decent PIM to get non-communication releated tasks out of the inbox.'
categories:
    - Aside
tags:
    - email
    - productivity
---

All good plus a decent PIM to get non-communication releated tasks out of the inbox.