---
id: 2159
title: 'Is there a better name then &#8220;agile&#8221; for languages like Python, Ruby, Perl, and Groovy?'
date: '2004-03-20T19:14:06+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2159'
permalink: /2004/03/20/is-there-a-better-name-then-agile-for-languages-like-python-ruby-perl-and-groovy/
typo_id:
    - '2157'
mt_id:
    - '1873'
link_related:
    - 'http://www.dehora.net/journal/archives/000403.html'
raw_content:
    - 'How about \''better\'' languages.'
categories:
    - Aside
tags:
    - agile
    - groovy
    - perl
    - python
    - ruby
---

How about ‘better’ languages.