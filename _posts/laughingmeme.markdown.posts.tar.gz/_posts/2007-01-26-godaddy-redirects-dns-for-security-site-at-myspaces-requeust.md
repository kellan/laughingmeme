---
id: 3566
title: 'GoDaddy redirects DNS for security site at MySpace&#8217;s requeust'
date: '2007-01-26T10:07:54+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/01/26/godaddy-redirects-dns-for-security-site-at-myspaces-requeust/'
permalink: /2007/01/26/godaddy-redirects-dns-for-security-site-at-myspaces-requeust/
link_related:
    - 'http://blog.wired.com/27bstroke6/2007/01/myspace_alleged.html'
categories:
    - Aside
    - Uncategorized
tags:
    - censorship
    - corporate
    - dns
    - godaddy
    - infrastructure
    - myspace
    - security
---

Like I’ve said \[before\](http://laughingmeme.org/category/godaddy), like you need another reason not to use GoDaddy, especially if you’re doing anything political or controversial in nature.