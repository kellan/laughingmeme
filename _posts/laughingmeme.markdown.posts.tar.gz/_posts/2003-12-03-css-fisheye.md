---
id: 1907
title: 'CSS Fisheye'
date: '2003-12-03T15:12:09+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1907'
permalink: /2003/12/03/css-fisheye/
typo_id:
    - '1905'
mt_id:
    - '1496'
link_related:
    - 'http://dannyayers.com/2003/10/fisheye.html'
raw_content:
    - 'File under \''Zoomable UIs for the web\'', or maybe \''not ready for prime time\'''
categories:
    - Aside
---

File under ‘Zoomable UIs for the web’, or maybe ‘not ready for prime time’