---
id: 1795
title: 'Given the choice, it&#8217;s better to be viewed as a foot soldier for Bush than a spokeswoman for al-Qaeda.'
date: '2003-10-21T16:18:46+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1795'
permalink: /2003/10/21/given-the-choice-its-better-to-be-viewed-as-a-foot-soldier-for-bush-than-a-spokeswoman-for-al-qaeda/
typo_id:
    - '1793'
mt_id:
    - '1334'
link_related:
    - 'http://www.usatoday.com/life/columnist/mediamix/2003-09-14-media-mix_x.htm'
raw_content:
    - 'Fox explains what they mean by \''Fair and Balanced\'''
categories:
    - Aside
---

Fox explains what they mean by ‘Fair and Balanced’