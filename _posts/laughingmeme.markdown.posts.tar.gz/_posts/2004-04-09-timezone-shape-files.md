---
id: 2198
title: 'timezone shape files'
date: '2004-04-09T09:20:31+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2198'
permalink: /2004/04/09/timezone-shape-files/
typo_id:
    - '2196'
mt_id:
    - '1934'
link_related:
    - 'http://fri.sfasu.edu/data/geographic/world/shape/'
raw_content:
    - 'also continents, rivers, and gobs and gobs over GIS data'
categories:
    - Aside
tags:
    - gis
---

also continents, rivers, and gobs and gobs over GIS data