---
id: 879
title: 'Deschutes Unfortunate Politics'
date: '2004-08-08T15:34:51+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=879'
permalink: /2004/08/08/deschutes-unfortunate-politics/
typo_id:
    - '877'
mt_id:
    - '2273'
link_related:
    - ''
raw_content:
    - "Heard recently that Oregon brewery <a href=\\\"http://www.deschutesbrewery.com/\\\">Deschutes</a> (of the excellent Mirror Pond) is also a major supporter of Bush.  Disappointing, but not terribly surprising.  \n\nWhat is cool is that , at least in Portland, local microbrewers have seen a major upsurge in demand as bars, and restaurants switch to more palatable options.  \n\nPolitics only works if its local and personal.  Also mobilizing bartenders is a high value proposition."
---

Heard recently that Oregon brewery [Deschutes](http://www.deschutesbrewery.com/) (of the excellent Mirror Pond) is also a major supporter of Bush. Disappointing, but not terribly surprising.

What is cool is that , at least in Portland, local microbrewers have seen a major upsurge in demand as bars, and restaurants switch to more palatable options.

Politics only works if its local and personal. Also mobilizing bartenders is a high value proposition.