---
id: 1675
title: 'A few recommended N. Seattle coffee shops'
date: '2003-08-23T17:43:38+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1675'
permalink: /2003/08/23/a-few-recommended-n-seattle-coffee-shops/
typo_id:
    - '1673'
mt_id:
    - '1128'
link_related:
    - 'http://www.jeffcarlson.com/coffeehouses.html'
raw_content:
    - 'with the caveat that Torrefazione is Starbucks.'
categories:
    - Aside
---

with the caveat that Torrefazione is Starbucks.