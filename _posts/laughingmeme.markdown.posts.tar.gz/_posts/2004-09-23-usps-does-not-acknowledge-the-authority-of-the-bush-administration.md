---
id: 2551
title: '&#8216;USPS does not acknowledge the authority of the Bush administration.&#8217;'
date: '2004-09-23T16:44:15+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2551'
permalink: /2004/09/23/usps-does-not-acknowledge-the-authority-of-the-bush-administration/
typo_id:
    - '2549'
mt_id:
    - '2416'
link_related:
    - 'http://www.boingboing.net/2004/09/23/funny_post_office_la.html'
raw_content:
    - 'Yeh culture jamming.'
categories:
    - Aside
---

Yeh culture jamming.