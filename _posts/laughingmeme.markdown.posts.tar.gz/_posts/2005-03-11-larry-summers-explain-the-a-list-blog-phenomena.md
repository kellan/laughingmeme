---
id: 2860
title: 'Larry Summers explain the &#8220;A-list&#8221; blog phenomena'
date: '2005-03-11T18:03:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2860'
permalink: /2005/03/11/larry-summers-explain-the-a-list-blog-phenomena/
typo_id:
    - '2858'
mt_id:
    - '2845'
link_related:
    - 'http://weblog.burningbird.net/archives/2005/03/07/wherearethewomenofweblogging/'
raw_content:
    - 'Why honey, itâ€™s because the male brain is wired for linking!'
categories:
    - Aside
tags:
    - blogging
    - gender
    - harvard
    - larrysummers
---

Why honey, itâ€™s because the male brain is wired for linking!