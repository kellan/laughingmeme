---
id: 3442
title: 'gaping void:  i&#8217;m not bitter or twisted &#8211;'
date: '2006-08-17T03:17:00+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3442'
permalink: /2006/08/17/gaping-void-im-not-bitter-or-twisted/
typo_id:
    - '3441'
mt_id:
    - ''
link_related:
    - 'http://www.gapingvoid.com/Moveable_Type/archives/003183.html'
raw_content:
    - 'i\''ve taken my medication'
categories:
    - Aside
---

i’ve taken my medication