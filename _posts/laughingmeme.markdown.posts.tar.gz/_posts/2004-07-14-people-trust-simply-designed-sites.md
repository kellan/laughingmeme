---
id: 2388
title: 'People trust simply designed sites.'
date: '2004-07-14T14:30:31+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2388'
permalink: /2004/07/14/people-trust-simply-designed-sites/
typo_id:
    - '2386'
mt_id:
    - '2190'
link_related:
    - 'http://slate.msn.com/id/2103823/'
raw_content:
    - 'Which is at the heart of the \''undesign\'' renaissance.'
categories:
    - Aside
tags:
    - design
---

Which is at the heart of the ‘undesign’ renaissance.