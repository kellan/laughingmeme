---
id: 3572
title: 'Ever have experiences that are too complicated to Twitter?'
date: '2007-02-02T22:47:36+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/02/02/ever-have-experiences-that-are-too-complicated-to-twitter/'
permalink: /2007/02/02/ever-have-experiences-that-are-too-complicated-to-twitter/
link_related:
    - 'http://twitter.com/ev/statuses/5205403'
categories:
    - Aside
    - Uncategorized
tags:
    - twitter
---

If only there were some other self-expression tool designed for greater verbosity.