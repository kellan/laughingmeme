---
id: 1853
title: 'Click Maps &#8211; rapid prototyping with Visio'
date: '2003-11-14T00:56:29+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1853'
permalink: /2003/11/14/click-maps-rapid-prototyping-with-visio/
typo_id:
    - '1851'
mt_id:
    - '1421'
link_related:
    - 'http://byandlarge.net/scuttlebutt/archives/000080.html'
raw_content:
    - 'Aren\''t we supposed to be using UML for this?'
categories:
    - Aside
---

Aren’t we supposed to be using UML for this?