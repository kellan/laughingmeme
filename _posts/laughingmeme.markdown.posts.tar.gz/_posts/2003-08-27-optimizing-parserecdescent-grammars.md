---
id: 1685
title: 'Optimizing Parse::RecDescent grammars'
date: '2003-08-27T00:53:53+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1685'
permalink: /2003/08/27/optimizing-parserecdescent-grammars/
typo_id:
    - '1683'
mt_id:
    - '1143'
link_related:
    - 'http://www.sidhe.org/~dan/blog/archives/000235.html'
raw_content:
    - 'I keep looking for P::RD shaped nails, but I haven\''t found any yet'
categories:
    - Aside
---

I keep looking for P::RD shaped nails, but I haven’t found any yet