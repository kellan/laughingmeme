---
id: 1573
title: 'TeledyN: Echos of RSS'
date: '2003-07-02T01:44:17+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1573'
permalink: /2003/07/02/teledyn-echos-of-rss/
typo_id:
    - '1571'
mt_id:
    - '945'
link_related:
    - 'http://www.teledyn.com/mt/archives/001055.html'
raw_content:
    - 'some of the same ideas we were kicking around with open editing'
categories:
    - Aside
---

some of the same ideas we were kicking around with open editing