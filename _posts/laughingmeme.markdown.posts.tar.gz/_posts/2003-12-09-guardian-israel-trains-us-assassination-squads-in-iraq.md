---
id: 1933
title: 'Guardian:  Israel trains US assassination squads in Iraq'
date: '2003-12-09T18:04:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1933'
permalink: /2003/12/09/guardian-israel-trains-us-assassination-squads-in-iraq/
typo_id:
    - '1931'
mt_id:
    - '1529'
link_related:
    - 'http://www.guardian.co.uk/Iraq/Story/0,2763,1102940,00.html?=rss'
raw_content:
    - 'IDF has sent urban warfare specialists to Fort Bragg'
categories:
    - Aside
---

IDF has sent urban warfare specialists to Fort Bragg