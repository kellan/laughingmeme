---
id: 3027
title: 'Chameleon: an icon set from SimpleBits that changes color'
date: '2005-09-21T12:35:01+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3027'
permalink: /2005/09/21/chameleon-an-icon-set-from-simplebits-that-changes-color/
typo_id:
    - '3025'
mt_id:
    - '3114'
link_related:
    - 'http://chameleon.simplebits.com/'
raw_content:
    - 'I love Dan\''s icons, but this is too cool.  One of these days I\''m going to find an excuse to actually buy a set.'
categories:
    - Aside
tags:
    - color
---

I love Dan’s icons, but this is too cool. One of these days I’m going to find an excuse to actually buy a set.