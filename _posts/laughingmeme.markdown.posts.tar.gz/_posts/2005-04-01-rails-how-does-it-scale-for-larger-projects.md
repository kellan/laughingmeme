---
id: 2895
title: 'Rails, how does it scale for larger projects'
date: '2005-04-01T07:30:59+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2895'
permalink: /2005/04/01/rails-how-does-it-scale-for-larger-projects/
typo_id:
    - '2893'
mt_id:
    - '2899'
link_related:
    - 'http://www.anarchogeek.com/archives/000514.html'
raw_content:
    - 'I\''ve never really done Ruby, Rails, or TDD, but several hours after getting Odeo SVN access I\''m checking in my first battery of tests, not to mention code.'
categories:
    - Aside
tags:
    - odeo
    - rails
    - ruby
---

I’ve never really done Ruby, Rails, or TDD, but several hours after getting Odeo SVN access I’m checking in my first battery of tests, not to mention code.