---
id: 3610
title: 'whump.com: Ekranoplan!'
date: '2007-04-02T09:35:20+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/2007/04/02/whumpcom-ekranoplan/'
permalink: /2007/04/02/whumpcom-ekranoplan/
link_related:
    - 'http://www.whump.com/moreLikeThis/2007/04/01/ekranoplan/'
categories:
    - Aside
    - Uncategorized
tags:
    - 'cold war'
    - gmaps
    - stross
---

“Holy smokes, the Soviets really did build the ekranoplan Charlie Stross described in Missile Gap. You can see one in dry dock on Google.”