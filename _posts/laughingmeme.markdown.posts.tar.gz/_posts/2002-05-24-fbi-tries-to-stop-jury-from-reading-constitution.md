---
id: 35
title: 'FBI Tries to Stop Jury from Reading Constitution'
date: '2002-05-24T11:30:02+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=35'
permalink: /2002/05/24/fbi-tries-to-stop-jury-from-reading-constitution/
typo_id:
    - '33'
mt_id:
    - '31'
link_related:
    - ''
raw_content:
    - 'Speaking of constituions, <a href=\"http://sf.indymedia.org/news/2002/05/128617.php\">FBI Tries to Stop Jury from Reading Constitution</a>.  Probably because they couldn\''t find the paragraph that stated carbombing someone is an acceptable substitute for due process of law.'
---

Speaking of constituions, [FBI Tries to Stop Jury from Reading Constitution](http://sf.indymedia.org/news/2002/05/128617.php). Probably because they couldn’t find the paragraph that stated carbombing someone is an acceptable substitute for due process of law.