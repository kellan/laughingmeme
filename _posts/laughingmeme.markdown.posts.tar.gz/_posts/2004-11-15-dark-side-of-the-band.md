---
id: 2637
title: 'Dark Side of the Band'
date: '2004-11-15T13:44:49+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2637'
permalink: /2004/11/15/dark-side-of-the-band/
typo_id:
    - '2635'
mt_id:
    - '2542'
link_related:
    - 'http://www.wired.com/news/technology/0,1282,65698-2,00.html?tw=wn_story_page_next1'
raw_content:
    - 'I\''ve always found this real life \''Pattern Recognition\'' story fascinating in a \''A Colder War\'' kind of way.'
categories:
    - Aside
tags:
    - coldwar
    - radio
    - sf
---

I’ve always found this real life ‘Pattern Recognition’ story fascinating in a ‘A Colder War’ kind of way.