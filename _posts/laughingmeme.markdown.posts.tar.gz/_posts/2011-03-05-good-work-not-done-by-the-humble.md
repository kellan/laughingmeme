---
id: 4810
title: 'Good work, not done by the humble'
date: '2011-03-05T10:38:12+00:00'
author: Kellan
layout: post
guid: 'http://laughingmeme.org/?p=4810'
permalink: /2011/03/05/good-work-not-done-by-the-humble/
categories:
    - Uncategorized
tags:
    - quotable
---

> *“Good work is not done by ‘humble’ men. It is one of the first duties of a professor, for example, in any subject, to exaggerate a little both the importance of his subject and his own importance in it. A man who is always asking ‘Is what I do worthwhile?’ and ‘Am I the right person to do it?’ will always be ineffective himself and a discouragement to others. He must shut his eyes a little and think a little more of his subject and himself than they deserve. This is not too difficult: it is harder not to make his subject and himself ridiculous by shutting his eyes too tightly.”* – \[G. H. Hardy\](http://www.aaronsw.com/weblog/nonapology)