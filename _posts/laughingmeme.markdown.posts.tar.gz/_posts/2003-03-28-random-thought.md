---
id: 381
title: 'Random Thought'
date: '2003-03-28T07:44:56+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=381'
permalink: /2003/03/28/random-thought/
typo_id:
    - '379'
mt_id:
    - '580'
link_related:
    - ''
raw_content:
    - '6 months ago I consistently couldn\''t spell assassin, now I can.  Not sure thats progress.'
---

6 months ago I consistently couldn’t spell assassin, now I can. Not sure thats progress.