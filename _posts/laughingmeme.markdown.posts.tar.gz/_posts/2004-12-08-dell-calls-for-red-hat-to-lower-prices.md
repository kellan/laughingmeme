---
id: 2696
title: 'Dell Calls For Red Hat To Lower Prices'
date: '2004-12-08T00:26:39+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2696'
permalink: /2004/12/08/dell-calls-for-red-hat-to-lower-prices/
typo_id:
    - '2694'
mt_id:
    - '2618'
link_related:
    - 'http://linux.slashdot.org/article.pl?sid=04/12/08/0146206&tid=110'
raw_content:
    - 'I recently came face to face with RHEL and was *shocked* at the cost + out of dateness.'
categories:
    - Aside
tags:
    - corporation
    - debian
    - linux
    - redhat
---

I recently came face to face with RHEL and was *shocked* at the cost + out of dateness.