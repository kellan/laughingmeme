---
id: 988
title: 'When the &#8216;Other&#8217; is a Technology'
date: '2005-01-03T09:16:45+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=988'
permalink: /2005/01/03/when-the-other-is-a-technology/
typo_id:
    - '986'
mt_id:
    - '2680'
link_related:
    - ''
raw_content:
    - 'Rafe is having a <a href=\"http://rc3.org/cgi-bin/less.pl?arg=6685\">bad MySQL day</a>.  There should be a word/phrase for that sense of frustration compounded with a certain helpless desperation that so quickly ferments into anger, rage, and sometimes blind hatred.  I know that feeling well (see <a href=\"http://laughingmeme.org/archives/002277.html#002277\">Subversion, blargh</a>), and I think it accounts for some of my most unbalanced moments from the last few years.  Its something we\''re going to need to address as computing devices become more ubiquitous. (though I think <b>this</b> particularly manifestation is limited to software engineers)'
---

Rafe is having a [bad MySQL day](http://rc3.org/cgi-bin/less.pl?arg=6685). There should be a word/phrase for that sense of frustration compounded with a certain helpless desperation that so quickly ferments into anger, rage, and sometimes blind hatred. I know that feeling well (see [Subversion, blargh](http://laughingmeme.org/archives/002277.html#002277)), and I think it accounts for some of my most unbalanced moments from the last few years. Its something we’re going to need to address as computing devices become more ubiquitous. (though I think **this** particularly manifestation is limited to software engineers)