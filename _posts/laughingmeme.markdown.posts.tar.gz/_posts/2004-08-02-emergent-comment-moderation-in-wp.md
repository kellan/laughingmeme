---
id: 2429
title: 'emergent comment moderation in WP'
date: '2004-08-02T21:26:37+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=2429'
permalink: /2004/08/02/emergent-comment-moderation-in-wp/
typo_id:
    - '2427'
mt_id:
    - '2248'
link_related:
    - 'http://mookitty.co.uk/devblog/archives/2004/06/22/kittens-friendly-comments-10/'
raw_content:
    - 'as the amount of info we all deal with explodes emergence is going to be a key factor'
categories:
    - Aside
tags:
    - collaboration
    - wordpress
---

as the amount of info we all deal with explodes emergence is going to be a key factor