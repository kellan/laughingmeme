---
id: 1432
title: 'I gave them tools that they love and use. They hate me for it.'
date: '2003-05-10T09:51:08+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=1432'
permalink: /2003/05/10/i-gave-them-tools-that-they-love-and-use-they-hate-me-for-it/
typo_id:
    - '1430'
mt_id:
    - '731'
link_related:
    - 'http://scriptingnews.userland.com/2003/05/07#When:1:34:27AM'
raw_content:
    - 'Dave Winer:  Don\''t hate me because I\''m beautiful'
categories:
    - Aside
---

Dave Winer: Don’t hate me because I’m beautiful