---
id: 3037
title: 'Stop me if heard this one'
date: '2005-09-29T18:31:30+00:00'
author: Kellan
layout: post
guid: 'http://lm.quxx.info/?p=3037'
permalink: /2005/09/29/stop-me-if-heard-this-one/
typo_id:
    - '3035'
mt_id:
    - '3130'
link_related:
    - 'http://www.simplefuture.org/?p=469'
raw_content:
    - 'Donald Rumsfeld is giving the president his daily briefing....'
categories:
    - Aside
tags:
    - bush
    - funny
    - st
---

Donald Rumsfeld is giving the president his daily briefing….